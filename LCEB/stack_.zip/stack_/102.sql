SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score > -1
  AND p.OwnerUserId NOT IN (22200, 9791, 1112997, 1278798, 765394)
ORDER BY p.Score DESC;
