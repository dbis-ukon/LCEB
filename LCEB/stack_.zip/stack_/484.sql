SELECT u.DisplayName, b.Name AS BadgeName, p.Title
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
  AND (b.Name LIKE '%%' OR b.Name LIKE '%%' OR b.Name NOT LIKE ''%%'')
  AND (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
  AND u.Reputation >= 1
  AND b.Class IN (3)
  AND p.Score > 0
  AND p.PostTypeId = 1;
