SELECT
    p.Id,
    p.Title,
    u.DisplayName,
    COUNT(c.Id) AS comment_count,
    COUNT(b.Id) AS badge_count
FROM Posts p
JOIN Users u
  ON p.OwnerUserId = u.Id
JOIN Comments c
  ON c.PostId = p.Id
JOIN Badges b
  ON b.UserId = u.Id
WHERE (
        p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title NOT LIKE ''%%''
      )
  AND (
        u.DisplayName LIKE '%%'
        OR u.DisplayName LIKE '%%'
        OR u.DisplayName NOT LIKE ''%%''
      )
  AND (
        b.Name LIKE '%%'
        OR b.Name LIKE '%%'
        OR b.Name NOT LIKE ''%%''
      )
  AND p.PostTypeId = 1
  AND p.Score >= 2
  AND p.ViewCount > 156
  AND p.AnswerCount >= 1
  AND u.Reputation >= 11
GROUP BY
    p.Id,
    p.Title,
    u.DisplayName
HAVING COUNT(c.Id) >= 2
   AND COUNT(b.Id) >= 1;
