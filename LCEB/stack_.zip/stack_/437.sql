SELECT Id, Title, Score FROM Posts WHERE Title LIKE '%index%' AND FavoriteCount >= 0 ORDER BY Score ASC;
