SELECT
    t.TagName,
    p.Title,
    p.ViewCount,
    p.Score
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
WHERE
    (t.TagName LIKE '%%' OR t.TagName LIKE '%%' OR t.TagName NOT LIKE ''%%'')
    AND (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND t.Count BETWEEN 36 AND 1538
    AND t.IsModeratorOnly = FALSE
    AND p.ViewCount >= 843
    AND p.Score >= -2;
