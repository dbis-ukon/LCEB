SELECT p.Id, p.Title, u.DisplayName,
       t.TagName, b.Name AS BadgeName,
       related.Title AS RelatedTitle,
       COUNT(DISTINCT v.Id) AS RelatedVoteCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.ExcerptPostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN PostLinks pl ON pl.RelatedPostId = p.Id
JOIN Posts related ON related.Id = pl.PostId
JOIN Votes v ON v.PostId = related.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Name LIKE '%%'
  AND related.Title LIKE '%%'
  AND pl.LinkTypeId IN (3, 1)
  AND vt.Id IN (5, 1, 2, 7, 4)
  AND related.CreationDate >= '2014-12-04 18:45:13.057000'
GROUP BY p.Id, p.Title, u.DisplayName, t.TagName,
         b.Name, related.Title
HAVING COUNT(DISTINCT v.Id) >= 2
ORDER BY RelatedVoteCount DESC;
