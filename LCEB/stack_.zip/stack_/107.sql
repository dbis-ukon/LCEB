SELECT b.Id, b.Name, b.Class, u.DisplayName, u.Reputation
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name LIKE '%%'
  AND b.Class <> 3
  AND u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Date BETWEEN '2015-01-01' AND '2022-12-31'
  AND b.TagBased = false
  AND u.Reputation > 11
  AND u.DownVotes < 2
ORDER BY b.Date DESC;
