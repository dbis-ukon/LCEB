SELECT u.DisplayName, p.Title, v.VoteTypeId, ph.Comment
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND v.VoteTypeId IN (15, 3, 2, 10)
  AND ph.PostHistoryTypeId IN (3, 1, 2, 13, 5)
  AND p.Score > 0;
