SELECT p.Id, p.Title, u.DisplayName, b.Name AS badge_name
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND b.TagBased = false
  AND p.PostTypeId = 1
  AND p.ViewCount > 105
ORDER BY p.ViewCount DESC
LIMIT 30;
