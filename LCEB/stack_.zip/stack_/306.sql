SELECT
    p.Id,
    p.Title,
    c.Text,
    p.CommentCount
FROM Posts p
JOIN Comments c ON c.PostId = p.Id
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (c.Text LIKE '%%' OR c.Text LIKE '%%' OR c.Text NOT LIKE ''%%'')
    AND p.PostTypeId = 1
    AND p.ClosedDate IS NULL
    AND p.CommentCount >= 7
    AND c.CreationDate >= p.CreationDate;
