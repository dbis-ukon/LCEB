SELECT
    p.Id,
    p.Title,
    p.Score,
    p.ViewCount,
    p.AnswerCount,
    u.DisplayName,
    u.Reputation
FROM Posts p
JOIN Users u
    ON p.OwnerUserId = u.Id
WHERE (
        p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title NOT LIKE ''%%''
      )
  AND (
        u.DisplayName LIKE '%%'
        OR u.DisplayName LIKE '%%'
        OR u.DisplayName NOT LIKE ''%%''
      )
  AND p.PostTypeId = 1
  AND p.ClosedDate IS NULL
  AND p.Score BETWEEN 1 AND 5
  AND p.ViewCount > 44
  AND p.AnswerCount >= 3
  AND u.LastAccessDate >= '2017-08-07 19:59:18.173000'
  AND u.Views >= 0
ORDER BY p.ViewCount DESC
LIMIT 25;
