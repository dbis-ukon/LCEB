SELECT t.Id, t.TagName, t.Count
FROM Tags t
WHERE t.TagName LIKE '%%'
  AND t.IsModeratorOnly IS NOT TRUE
  AND t.Count > 44
  AND t.ExcerptPostId IN (1718291, 137096, 1930350, 1421704, 4416122)
ORDER BY t.Count DESC;
