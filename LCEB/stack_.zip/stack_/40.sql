SELECT p.Id, p.Title, u.DisplayName, p.Score, p.FavoriteCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
WHERE p.Title LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score BETWEEN 0 AND 2
  AND p.FavoriteCount > 0
  AND p.LastEditDate IS NOT NULL
ORDER BY p.FavoriteCount DESC;
