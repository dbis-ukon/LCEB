SELECT Id, Title
FROM Posts
WHERE (Title LIKE 'How to%' OR Title LIKE '%tutorial%') AND Title NOT LIKE '%index%'
  AND PostTypeId = 1 AND CreationDate >= '2015-01-01' AND LastEditDate IS NOT NULL AND ParentId IS NULL AND AcceptedAnswerId IS NOT NULL
  AND Id IN (SELECT Id FROM Posts ORDER BY Score DESC LIMIT (SELECT COUNT(*)/5 FROM Posts));
