SELECT p.Id, p.Title, u.DisplayName, p.Score
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.Score > 2
  AND p.ViewCount > 124
  AND u.Reputation > 1
ORDER BY p.Score DESC;
