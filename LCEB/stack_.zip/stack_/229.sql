SELECT p.Id, p.Title, u.DisplayName,
       vt.Name AS VoteType, v.BountyAmount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Votes v ON v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND vt.Id IN (7, 15, 3, 11, 16)
  AND v.CreationDate >= '2024-03-14 00:00:00'
  AND p.Score > 1
ORDER BY v.CreationDate DESC;
