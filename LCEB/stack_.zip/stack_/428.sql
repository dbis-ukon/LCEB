SELECT p.Id, p.Title, p.ViewCount, p.Score, p.FavoriteCount
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score > 0
  AND p.ClosedDate IS NULL
ORDER BY p.ViewCount DESC
LIMIT 20;
