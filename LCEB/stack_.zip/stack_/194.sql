SELECT p.Title, v1.CreationDate AS UpvoteDate, v2.CreationDate AS DownvoteDate
FROM Votes v1
JOIN Votes v2 ON v1.PostId = v2.PostId AND v1.VoteTypeId = 2 AND v2.VoteTypeId = 3 AND v1.CreationDate < v2.CreationDate
JOIN Posts p ON p.Id = v1.PostId
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score < 0
  AND p.ViewCount > 76
  AND p.AnswerCount > 1
  AND p.ClosedDate IS NULL
ORDER BY v2.CreationDate DESC;
