SELECT p.Title, u1.DisplayName AS Editor1, u2.DisplayName AS Editor2
FROM PostHistory ph1
JOIN PostHistory ph2 ON ph1.PostId = ph2.PostId AND ph1.UserId <> ph2.UserId
JOIN Users u1 ON ph1.UserId = u1.Id
JOIN Users u2 ON ph2.UserId = u2.Id
JOIN Posts p ON p.Id = ph1.PostId
WHERE p.Title LIKE '%%'
  AND u1.DisplayName LIKE '%%'
  AND ph1.CreationDate >= '2019-05-16 22:39:53.223000';
