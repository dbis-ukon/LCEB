SELECT p1.Title AS PostA, p2.Title AS PostB
FROM PostLinks pl1
JOIN PostLinks pl2 ON pl1.PostId = pl2.RelatedPostId AND pl1.RelatedPostId = pl2.PostId
JOIN Posts p1 ON p1.Id = pl1.PostId
JOIN Posts p2 ON p2.Id = pl1.RelatedPostId
WHERE p1.Title LIKE '%%'
  AND p2.Title NOT LIKE ''%%''
  AND pl1.CreationDate >= '2022-07-03 10:52:02.273000';
