SELECT p.Title, u.DisplayName, u.Location
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE (u.DisplayName LIKE '%%' OR u.Location LIKE '%%')
  AND (b.Name LIKE '%%')
  AND u.DownVotes < 0
  AND p.Score > 0
  AND p.PostTypeId = 2
ORDER BY p.Score DESC;
