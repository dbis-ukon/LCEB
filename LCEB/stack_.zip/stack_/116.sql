SELECT p1.Id AS post_a, p1.Title AS title_a, p2.Id AS post_b, p2.Title AS title_b, pl.CreationDate AS linked_on
FROM Posts p1
JOIN PostLinks pl ON pl.PostId = p1.Id
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
WHERE p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND pl.LinkTypeId = 1
  AND p1.PostTypeId = 1
  AND p2.PostTypeId = 1;
