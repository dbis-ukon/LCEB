SELECT p.Id, p.Title, u.DisplayName, pt.Name AS PostType,
       p.CreationDate
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND pt.Id IN (1, 6, 2, 3, 5)
  AND p.CreationDate >= '2014-04-25 22:50:29.453000'
  AND p.Score > -1
  AND u.LastAccessDate >= '2022-02-03 14:07:06.480000'
ORDER BY p.CreationDate DESC;
