SELECT u.Id, u.DisplayName, b.Name AS BadgeName, p.Title
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE u.DisplayName NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND p.Title LIKE '%%'
   AND b.Name LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.CommentCount >= 0
  AND c.Score >= 1
  AND b.TagBased = false
  AND p.ClosedDate IS NULL
  AND c.CreationDate >= '2013-11-17 00:49:46.983000';
