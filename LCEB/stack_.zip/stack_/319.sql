SELECT u.Id, u.DisplayName, u.Reputation
FROM Users u
WHERE u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND u.Reputation > 13
  AND u.Id IN (699022, 1370589, 1400898, 1008086, 1258126)
ORDER BY u.Reputation DESC;
