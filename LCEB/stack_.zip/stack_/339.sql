SELECT p1.Title AS PostA, p2.Title AS PostB, u1.DisplayName AS OwnerA, u2.DisplayName AS OwnerB
FROM Posts p1
JOIN Posts p2 ON p1.OwnerUserId = p2.OwnerUserId AND p1.Id <> p2.Id
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
WHERE p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND u1.DisplayName LIKE '%%';
