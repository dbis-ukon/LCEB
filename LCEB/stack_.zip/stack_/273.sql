SELECT
    Id,
    TagName,
    Count
FROM Tags
WHERE (TagName LIKE '%script%' OR TagName LIKE '%web%')
  AND TagName NOT LIKE '%git%'
  AND Count < 50000
  AND IsModeratorOnly IS NOT TRUE
  AND IsRequired IS NOT TRUE
  AND ExcerptPostId IS NOT NULL
ORDER BY Count DESC
FETCH FIRST 20 ROWS WITH TIES;
