SELECT p1.Title AS Question, p2.Title AS Answer1, p3.Title AS Answer2, u1.DisplayName AS Asker, u2.DisplayName AS Answerer1, u3.DisplayName AS Answerer2
FROM Posts p1
JOIN Posts p2 ON p2.ParentId = p1.Id
JOIN Posts p3 ON p3.ParentId = p1.Id AND p3.Id <> p2.Id
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
JOIN Users u3 ON p3.OwnerUserId = u3.Id
WHERE (p1.Title LIKE '%%' OR p1.Title LIKE '%%') AND u2.DisplayName LIKE '%%' AND u3.DisplayName NOT LIKE ''%%'';
