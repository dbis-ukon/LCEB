SELECT u.DisplayName, COUNT(DISTINCT ph.PostId) AS posts_edited
FROM Posts p
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN Users u ON ph.UserId = u.Id
WHERE (p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
GROUP BY u.DisplayName
HAVING COUNT(DISTINCT ph.PostId) > 2;
