SELECT p.Id, p.Title, u.DisplayName, COUNT(DISTINCT c.Id) AS comments, COUNT(DISTINCT v.Id) AS upvotes
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND v.VoteTypeId = 16
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(DISTINCT v.Id) > 1;
