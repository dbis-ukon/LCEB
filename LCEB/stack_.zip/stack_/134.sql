SELECT p.Id, p.Title, u.DisplayName,
       u.Location, b.Name AS BadgeName,
       COUNT(DISTINCT ph.Id) AS HistoryCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN PostHistoryTypes pht ON pht.Id = ph.PostHistoryTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Name LIKE '%%'
  AND ph.CreationDate >= '2016-04-11 22:16:50.973000'
  AND pht.Id IN (50, 11, 12, 38, 20)
  AND p.Score >= 7
  AND u.Reputation > 11
GROUP BY p.Id, p.Title, u.DisplayName, u.Location, b.Name
HAVING COUNT(DISTINCT ph.Id) >= 2
ORDER BY HistoryCount DESC;
