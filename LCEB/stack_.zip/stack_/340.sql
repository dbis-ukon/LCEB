SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.ClosedDate IS NULL AND p.CreationDate >= '2021-06-25 08:14:04.717000'
  AND EXISTS (
      SELECT 1 FROM Badges b WHERE b.UserId = u.Id AND b.Class = 2
  );
