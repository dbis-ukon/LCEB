SELECT ph.PostId, ph.UserId, ph.CreationDate,
       p.Title, pht.Name AS HistoryType
FROM PostHistory ph
JOIN Posts p ON p.Id = ph.PostId
JOIN PostHistoryTypes pht ON pht.Id = ph.PostHistoryTypeId
WHERE p.Title LIKE '%%'
  AND ph.CreationDate >= '2021-08-18 08:53:23'
  AND ph.UserId IS NOT NULL
  AND ph.RevisionGUID IS NOT NULL
  AND pht.Id IN (19, 5, 6, 38, 18)
ORDER BY ph.CreationDate DESC;
