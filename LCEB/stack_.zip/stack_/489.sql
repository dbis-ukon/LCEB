SELECT DisplayName, COUNT(*) AS Cnt FROM Users WHERE DisplayName LIKE '%researcher%' AND Views BETWEEN 1 AND 1000000 AND UpVotes BETWEEN 0 AND 5000 GROUP BY DisplayName HAVING COUNT(*) >= 1;
