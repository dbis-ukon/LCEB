SELECT u.Id, u.DisplayName, u.Reputation
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND u.Reputation > 1
  AND u.LastAccessDate >= '2019-01-04 16:29:14.690000'
  AND EXISTS (
      SELECT 1 FROM Badges b WHERE b.UserId = u.Id AND b.Class = 3
  );
