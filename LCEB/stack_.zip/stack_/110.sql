SELECT u.DisplayName, b1.Name AS TagBadge1, b2.Name AS TagBadge2
FROM Badges b1
JOIN Badges b2 ON b1.UserId = b2.UserId AND b1.Name <> b2.Name AND b2.TagBased = true
JOIN Users u ON b1.UserId = u.Id
WHERE b1.Name LIKE '%%'
  AND b2.Name LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND b1.TagBased = true
  AND u.Reputation > 1
  AND u.Views > 0
  AND u.UpVotes >= 0
ORDER BY u.Reputation DESC;
