SELECT u.Id, u.DisplayName, u.Location
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND u.Reputation > 1;
