SELECT u.Id, u.DisplayName, p.Title, c.Text, v.VoteTypeId, ph.CreationDate
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE u.DisplayName NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND c.Score >= 0
  AND v.VoteTypeId = 3
  AND ph.CreationDate >= p.CreationDate;
