SELECT p.Id, p.Title, pt.Name AS PostType
FROM Posts p
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND pt.Name LIKE '%%'
  AND p.ClosedDate IS NULL AND p.CreationDate >= '2021-01-15 14:00:06.063000';
