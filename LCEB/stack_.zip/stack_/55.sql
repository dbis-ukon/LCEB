SELECT p1.Title AS Source, p2.Title AS Related, lt.Name AS LinkType, pl.CreationDate
FROM PostLinks pl
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
JOIN Posts p1 ON p1.Id = pl.PostId
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
WHERE p1.Title LIKE '%%' AND p2.Title LIKE '%%'
  AND lt.Name LIKE '%%'
  AND pl.CreationDate >= '2018-09-22 20:48:41.947000'
  AND p1.ViewCount > 119
  AND p2.Score >= 1;
