SELECT u.Id, u.DisplayName, u.Location, p.Title
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND pt.Id = 1;
