SELECT u.Id, u.DisplayName
FROM Users u
WHERE u.DisplayName NOT LIKE ''%%''
  AND EXISTS (
      SELECT 1 FROM Votes v JOIN Posts p ON p.Id = v.PostId
      WHERE v.UserId = u.Id AND p.Title LIKE '%%'
  );
