SELECT *
FROM Badges
WHERE Name LIKE '%Reviewer%'
  AND (Name NOT LIKE '%Test%' OR Name NOT LIKE '%Dummy%')
  AND Name LIKE '%Review%'
  AND Name NOT LIKE '%Deleted%'
  AND Class = 1
  AND TagBased = false;
