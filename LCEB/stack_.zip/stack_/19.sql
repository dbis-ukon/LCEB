SELECT
    Id,
    TagName
FROM Tags
WHERE (TagName LIKE '%%' OR TagName LIKE '%deprecated%')
  AND TagName NOT LIKE 'python'
  AND Count BETWEEN 1 AND 50000
  AND Count IN (10, 50, 100, 500)
  AND IsRequired IS NOT TRUE
EXCEPT
SELECT
    Id,
    TagName
FROM Tags
WHERE TagName LIKE '%script%';
