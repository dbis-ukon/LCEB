SELECT p.Id, p.Title, c.Text, c.Score
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE (p.Title NOT LIKE ''%%'' AND u.DisplayName LIKE '%%')
  AND p.Title LIKE '%%'
  AND c.Score < 1
  AND p.AnswerCount = 2
ORDER BY c.Score ASC;
