SELECT p.Id, p.Title, c.Text, c.Score
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE (p.Title NOT LIKE ''%%'' OR u.DisplayName LIKE '%%')
  AND c.Score < 2
  AND p.AnswerCount = 1
ORDER BY c.Score ASC
LIMIT 20;
