SELECT p.Id, p.Title, u.DisplayName, u.Location,
       b.Name AS BadgeName, t.TagName,
       related.Title AS RelatedTitle,
       COUNT(DISTINCT v.Id) AS VoteCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
JOIN Tags t ON t.WikiPostId = p.Id
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN Posts related ON related.Id = pl.RelatedPostId
JOIN Votes v ON v.PostId = related.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.TagName LIKE '%%'
  AND related.Title LIKE '%%'
  AND p.Score >= 2
  AND pl.LinkTypeId IN (1, 3)
  AND vt.Id IN (3, 7, 8, 2, 9)
  AND related.CreationDate >= '2024-05-20 20:50:20.033000'
GROUP BY p.Id, p.Title, u.DisplayName, u.Location,
         b.Name, t.TagName, related.Title
HAVING COUNT(DISTINCT v.Id) > 1
ORDER BY VoteCount DESC;
