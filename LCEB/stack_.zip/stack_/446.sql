SELECT UserId, Name, TagBased
FROM Badges
WHERE Name LIKE '%Teacher%'
  AND TagBased = false;
