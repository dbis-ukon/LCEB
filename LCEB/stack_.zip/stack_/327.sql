SELECT p1.Title AS Source, lt.Name AS LinkType, t.TagName, t.IsRequired, t.IsModeratorOnly
FROM PostLinks pl
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
JOIN Posts p1 ON p1.Id = pl.PostId
CROSS JOIN Tags t
WHERE p1.Tags LIKE '%%' AND lt.Name LIKE '%%'
  AND t.TagName LIKE '%%'
  AND p1.Title LIKE '%%'
  AND t.IsRequired IS NOT TRUE
  AND p1.AnswerCount > 2;
