SELECT p.Id, p.Title, u.DisplayName,
       t.TagName, wiki.Title AS WikiTitle,
       b.Name AS BadgeName, c.CreationDate AS CommentDate
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.ExcerptPostId = p.Id
JOIN Posts wiki ON wiki.Id = t.WikiPostId
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = wiki.Id
JOIN Users commenter ON commenter.Id = c.UserId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND wiki.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND commenter.DisplayName LIKE '%%'
  AND t.Count >= 2005
  AND c.CreationDate >= '2017-09-08 10:50:15.030000'
ORDER BY c.CreationDate DESC;
