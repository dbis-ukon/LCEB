SELECT Id, Name, Class FROM Badges WHERE Class = 3 AND Name NOT LIKE '%Enthusiast%' AND UserId > 100 AND UserId < 9000000 AND Date >= '2015-01-01' AND Date <= '2023-12-31' AND TagBased = false;
