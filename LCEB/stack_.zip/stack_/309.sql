SELECT Title, OwnerDisplayName, Score
FROM Posts
WHERE Title NOT LIKE '%homework%'
  AND PostTypeId = 1
  AND OwnerDisplayName IS NOT NULL
  AND Score > 25;
