SELECT p.Id, p.Title
FROM Posts p
WHERE (
        p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title NOT LIKE ''%%''
      )
  AND p.PostTypeId = 1
  AND p.Score >= 3
  AND p.ViewCount > 115
  AND NOT EXISTS (
      SELECT 1
      FROM Users u
      WHERE u.Id = p.OwnerUserId
        AND (
            u.DisplayName LIKE '%%'
            OR u.DisplayName LIKE '%%'
            OR u.DisplayName NOT LIKE ''%%''
        )
        AND u.Reputation > 1
  )
  AND EXISTS (
      SELECT 1
      FROM Comments c
      WHERE c.PostId = p.Id
        AND c.Score >= 1
        AND EXISTS (
            SELECT 1
            FROM Users cu
            WHERE cu.Id = c.UserId
              AND (
                  cu.DisplayName LIKE '%%'
                  OR cu.DisplayName LIKE '%%'
                  OR cu.DisplayName NOT LIKE ''%%''
              )
              AND cu.Reputation >= 181
        )
  );
