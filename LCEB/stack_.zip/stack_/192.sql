SELECT u.DisplayName, p.Title
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND EXISTS (
      SELECT 1 FROM Votes v JOIN Comments c ON c.PostId = v.PostId
      WHERE v.PostId = p.Id AND c.PostId = p.Id
  );
