SELECT p.Id, p.Title, u.DisplayName, b.Name
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.TagBased = false;
