SELECT u.Id, u.DisplayName
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND EXISTS (
      SELECT 1 FROM Posts p WHERE p.OwnerUserId = u.Id AND p.Title LIKE '%%'
        AND EXISTS (
            SELECT 1 FROM PostHistory ph WHERE ph.PostId = p.Id
              AND EXISTS (
                  SELECT 1 FROM Users eu WHERE eu.Id = ph.UserId AND eu.DisplayName LIKE '%%'
              )
        )
  );
