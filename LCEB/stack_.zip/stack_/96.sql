SELECT p1.Title, p2.Title
FROM Posts p1
JOIN PostLinks pl ON pl.PostId = p1.Id
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
WHERE p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND pl.LinkTypeId = 1
LIMIT 25;
