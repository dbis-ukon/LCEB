SELECT p.Id, p.Title, u.DisplayName, c.Score AS CommentScore,
       v.VoteTypeId, pt.Name AS PostType
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE '%%'
  AND c.Score > -1
  AND v.CreationDate >= '2013-05-20 00:00:00'
  AND pt.Id = 1
ORDER BY p.Score DESC;
