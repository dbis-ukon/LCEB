SELECT c.Id, c.PostId, c.Score, c.CreationDate, u.DisplayName
FROM Comments c
JOIN Users u ON u.Id = c.UserId
WHERE u.DisplayName LIKE '%%'
  AND c.Score >= 0
  AND c.CreationDate >= '2017-03-23 14:27:27.387000'
  AND u.Reputation > 1
  AND u.LastAccessDate >= '2020-12-09 23:01:45.350000'
ORDER BY c.Score DESC;
