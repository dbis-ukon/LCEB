SELECT p.Id, p.Title, p.Score, p.ViewCount
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score > (SELECT AVG(Score) FROM Posts WHERE PostTypeId = 1)
  AND p.ViewCount > (SELECT AVG(ViewCount) FROM Posts WHERE PostTypeId = 1)
ORDER BY p.Score DESC;
