SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName, t.TagName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
CROSS JOIN Tags t
JOIN Comments c ON c.PostId = p.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE p.Tags LIKE '%%' AND p.Title LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Class = 3 AND p.CommentCount >= 0 AND p.FavoriteCount > 1
ORDER BY p.CreationDate DESC;
