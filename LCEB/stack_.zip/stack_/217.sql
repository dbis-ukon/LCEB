SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName, COUNT(c.Id) AS comment_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
WHERE b.Name LIKE '%%'
  AND b.Name LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND p.AnswerCount >= 0
GROUP BY p.Id, p.Title, u.DisplayName, b.Name
HAVING COUNT(c.Id) > 2;
