SELECT p.Id, p.Title, p.Score, p.ViewCount, u.DisplayName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
WHERE p.Title LIKE '%%'
  AND p.Score BETWEEN 1 AND 1
  AND p.ViewCount > 57
  AND p.AnswerCount >= 1
  AND u.Reputation > 1
ORDER BY p.ViewCount DESC;
