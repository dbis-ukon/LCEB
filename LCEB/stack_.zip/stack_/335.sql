SELECT DATE_TRUNC('quarter', p.CreationDate) AS quarter, COUNT(*) AS cnt
FROM Posts p
WHERE p.Title LIKE '%%' AND p.Title LIKE '%%'
GROUP BY quarter
HAVING COUNT(*) > 5;
