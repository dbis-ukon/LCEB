SELECT u.DisplayName, COUNT(*) AS link_count
FROM Posts p1
JOIN PostLinks pl ON pl.PostId = p1.Id
JOIN Users u ON p1.OwnerUserId = u.Id
WHERE p1.Title LIKE '%%' AND u.Location LIKE '%%' AND u.Location LIKE '%%'
GROUP BY u.DisplayName
HAVING COUNT(*) > 1;
