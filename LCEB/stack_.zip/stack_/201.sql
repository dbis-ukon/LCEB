SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Score BETWEEN -1 AND 0
  AND p.AnswerCount >= 1
  AND p.ClosedDate IS NULL
ORDER BY p.Score DESC;
