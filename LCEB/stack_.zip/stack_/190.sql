SELECT p.Id, p.Title, p.AnswerCount, p.Score, p.ViewCount
FROM Posts p
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title LIKE '%%')
  AND p.PostTypeId = 1
  AND p.AnswerCount > -1
  AND p.Score > -1
  AND p.ClosedDate IS NULL
ORDER BY p.ViewCount DESC;
