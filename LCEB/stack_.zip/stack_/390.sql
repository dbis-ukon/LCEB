SELECT p.Id, p.Title
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.CreationDate >= '2022-02-22 23:50:17.723000' AND p.LastEditDate IS NOT NULL
  AND NOT EXISTS (
      SELECT 1 FROM PostLinks pl WHERE pl.PostId = p.Id
  );
