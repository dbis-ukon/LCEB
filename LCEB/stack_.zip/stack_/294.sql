SELECT p.Title, u.DisplayName, u.Location
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title NOT LIKE ''%%'' OR u.DisplayName LIKE '%%')
  AND u.UpVotes > -1
  AND p.AnswerCount >= 0
ORDER BY p.CreationDate DESC;
