SELECT p.Id AS ItemId, 'Post' AS SourceType, p.Title AS MatchedText
FROM Posts p
JOIN Users pu ON pu.Id = p.OwnerUserId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND p.Score > 1
  AND p.ViewCount > 125
  AND p.CreationDate >= '2023-09-27 19:49:33.287000'
  AND pu.Reputation > 1
  AND pt.Id IN (4, 3, 6, 5, 7)

UNION

SELECT c.Id AS ItemId, 'Comment' AS SourceType, u.DisplayName AS MatchedText
FROM Comments c
JOIN Users u ON u.Id = c.UserId
JOIN Posts p ON p.Id = c.PostId
WHERE u.DisplayName LIKE '%%'
  AND c.Score >= 0
  AND c.CreationDate >= '2020-07-02 21:49:35.230000'
  AND p.Score > 1
  AND u.Reputation >= 1;
