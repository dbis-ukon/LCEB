SELECT u.Id, u.DisplayName, p.Title, pt.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.DisplayName LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.Score >= 1;
