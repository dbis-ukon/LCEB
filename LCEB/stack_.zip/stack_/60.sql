SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Title LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Id IN (99954, 1808037, 4966740, 4920678, 821244)
ORDER BY p.Score DESC;
