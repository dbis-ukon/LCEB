SELECT p.*
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title NOT LIKE ''%%'' OR u.DisplayName LIKE '%%')
  AND p.ViewCount > 56
  AND u.Reputation > 1
ORDER BY p.CreationDate DESC;
