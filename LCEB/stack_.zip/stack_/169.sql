SELECT DISTINCT u.Id, u.DisplayName, u.Location, u.Reputation, COUNT(DISTINCT p.Id) AS relevant_posts
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Score > 0
  AND u.Reputation > 1
GROUP BY u.Id, u.DisplayName, u.Location, u.Reputation
HAVING COUNT(DISTINCT p.Id) >= 1;
