SELECT u.Id, p.Title, ph.Comment, v.VoteTypeId, pt.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.Location LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND ph.PostHistoryTypeId IN (3, 1, 5, 6, 2)
  AND v.VoteTypeId <> 2
  AND pt.Id = 1;
