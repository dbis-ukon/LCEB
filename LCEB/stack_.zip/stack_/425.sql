SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Score >= 4
  AND p.ViewCount BETWEEN 95 AND 112
  AND b.Class IN (3)
  AND pt.Id IN (3, 2, 1, 7, 4)
  AND u.Reputation > 21
ORDER BY b.Date DESC;
