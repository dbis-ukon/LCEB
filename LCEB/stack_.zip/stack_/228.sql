SELECT
    Id,
    TagName,
    FIRST_VALUE(TagName) OVER (
        PARTITION BY IsModeratorOnly
        ORDER BY Count DESC
    ) AS TopInGroup
FROM Tags
WHERE (TagName LIKE '%security%' OR TagName LIKE '%testing%')
  AND TagName NOT LIKE '%mobile%'
  AND IsRequired IS NOT TRUE
  AND Id BETWEEN 1 AND 999999
  AND Count > 10
  AND Count < 50000
  AND IsModeratorOnly IS NOT TRUE;
