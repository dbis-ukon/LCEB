SELECT *
FROM Users
WHERE (DisplayName LIKE '%Alex%' OR DisplayName LIKE '%Alexander%')
  AND Location NOT LIKE '%Unknown%'
  AND Location LIKE '%Canada%'
  AND Reputation >= 500
  AND UpVotes > 50;
