SELECT u.Id, u.DisplayName, u.Reputation
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND u.Reputation > 1
  AND NOT EXISTS (
      SELECT 1 FROM Badges b WHERE b.UserId = u.Id AND b.Class = 3
  )
ORDER BY u.Reputation DESC;
