SELECT p.Id, p.Title, c.Text, ph.Comment
FROM Posts p
JOIN Comments c ON c.PostId = p.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
  AND (c.Text LIKE '%%' OR c.Text LIKE '%%' OR c.Text NOT LIKE ''%%'')
  AND (ph.Comment LIKE '%%' OR ph.Comment LIKE '%%' OR ph.Comment NOT LIKE ''%%'')
  AND p.PostTypeId = 1
  AND p.Score >= 1
  AND c.Score >= 1
  AND ph.PostHistoryTypeId IN (3, 5, 2, 6, 24);
