SELECT u.DisplayName, b.Name, p.Title, v.VoteTypeId, c.Id
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Comments c ON c.PostId = p.Id
WHERE b.Name NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND v.VoteTypeId <> 2
  AND c.CreationDate > p.CreationDate;
