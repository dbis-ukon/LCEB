SELECT t.Id, t.TagName, p.Title,
       u.DisplayName, b.Name AS BadgeName,
       pt.Name AS PostType
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE t.TagName LIKE '%%'
  AND p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.Count BETWEEN 891 AND 1198
  AND t.WikiPostId IS NOT NULL
  AND t.IsModeratorOnly IS NOT TRUE
  AND p.ViewCount > 379
  AND p.ParentId IS NULL
  AND pt.Id = 6
ORDER BY t.Count DESC;
