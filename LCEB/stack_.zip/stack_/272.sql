SELECT Id, DisplayName, Location, Reputation
FROM Users
WHERE DisplayName LIKE 'John%'
  AND Location NOT LIKE '%USA%'
  AND Views > 500;
