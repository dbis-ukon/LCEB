SELECT t.TagName, t.Count, p.Title, u.DisplayName,
       b.Name AS BadgeName
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE t.TagName LIKE '%%'
  AND p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.Count BETWEEN 9 AND 36
  AND p.Score >= 0
  AND b.Date >= '2016-08-02 19:50:53.003000'
ORDER BY t.Count DESC;
