SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Score > (SELECT AVG(Score) FROM Posts)
  AND p.LastEditDate IS NOT NULL AND p.ParentId IS NULL;
