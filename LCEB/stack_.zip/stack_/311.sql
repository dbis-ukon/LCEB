SELECT b.Id, b.Name, u.DisplayName, 'TagBadge' AS BadgeKind
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name LIKE '%%'
  AND b.TagBased = false
  AND u.Reputation > 1
UNION
SELECT b.Id, b.Name, u.DisplayName, 'NamedBadge' AS BadgeKind
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name LIKE '%%'
  AND b.TagBased = false
  AND u.Reputation > 101
ORDER BY DisplayName;
