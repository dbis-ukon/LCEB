SELECT b.Id, b.Name
FROM Badges b
WHERE b.Name LIKE '%%'
  AND EXISTS (
      SELECT 1 FROM Posts p WHERE p.OwnerUserId = b.UserId AND p.Title LIKE '%%'
  );
