SELECT p.Title, crt.Name AS CloseReason, u.DisplayName
FROM PostHistory ph
JOIN Posts p ON p.Id = ph.PostId
JOIN Users u ON u.Id = ph.UserId
JOIN CloseReasonTypes crt ON crt.Id = CAST(ph.Comment AS integer)
WHERE ph.PostHistoryTypeId = 3
  AND p.Title LIKE '%%'
  AND crt.Name LIKE '%%';
