SELECT u.DisplayName, b1.Name AS Badge1, b2.Name AS Badge2
FROM Badges b1
JOIN Badges b2 ON b1.UserId = b2.UserId AND b1.Class = b2.Class AND b1.Name <> b2.Name
JOIN Users u ON b1.UserId = u.Id
WHERE b1.Name LIKE '%%'
  AND b2.Name LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND b1.Class = 3
  AND u.Reputation > 318
  AND u.Views > 0
  AND b1.TagBased = false
ORDER BY u.Reputation DESC;
