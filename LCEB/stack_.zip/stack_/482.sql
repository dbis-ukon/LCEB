SELECT p.Id, p.Title, vt.Name
FROM Posts p
JOIN Votes v ON v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND vt.Name = 'Close'
  AND p.Score > -4;
