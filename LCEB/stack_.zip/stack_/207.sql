SELECT t.Id, t.TagName, p.Title, u.DisplayName, b.Name
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE t.TagName NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Score >= 0;
