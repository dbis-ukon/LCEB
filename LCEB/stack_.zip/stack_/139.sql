SELECT t.Id, t.TagName,
       (SELECT p.Score FROM Posts p WHERE p.Id = t.ExcerptPostId) AS ExcerptScore
FROM Tags t
WHERE t.TagName LIKE '%%'
  AND t.TagName NOT LIKE ''%%''
  AND t.Count > 29861
ORDER BY ExcerptScore DESC;
