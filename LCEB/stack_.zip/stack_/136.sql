SELECT p.Id, p.Title, u.DisplayName, COUNT(c.Id) AS comment_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Posts answer ON answer.Id = p.AcceptedAnswerId
JOIN Users editor ON editor.Id = p.LastEditorUserId
WHERE p.Title LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.ViewCount BETWEEN 81 AND 128
  AND p.Score > 2
  AND u.DownVotes < 0
  AND u.AccountId IS NOT NULL
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(c.Id) > 2;
