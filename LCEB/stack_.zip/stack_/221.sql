SELECT u.Id, u.Location
FROM Users u
WHERE u.Location NOT LIKE ''%%''
  AND u.Reputation > 1
  AND u.CreationDate >= '2019-12-13 17:54:58.317000';
