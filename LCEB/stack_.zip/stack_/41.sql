SELECT p.Id, p.Title, u.DisplayName, b.Name
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Score > -1;
