SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Id IN (4355160, 3136066, 3462696, 208814, 2120350)
ORDER BY p.Score DESC;
