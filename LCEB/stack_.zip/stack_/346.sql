SELECT Id, UserId, Name, Date
FROM Badges
WHERE Name LIKE '%Nice%'
  AND Name NOT LIKE '%Answer%'
  AND Date >= '2019-01-01';
