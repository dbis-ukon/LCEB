SELECT p.Id, p.Title, u.DisplayName, COUNT(c.Id) AS comment_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN PostHistoryTypes pht ON pht.Id = ph.PostHistoryTypeId
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.CreationDate >= '2014-04-01 19:42:11.073000'
  AND p.LastEditDate IS NOT NULL
  AND u.Reputation > 1
  AND u.Views > 0
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(c.Id) > 4;
