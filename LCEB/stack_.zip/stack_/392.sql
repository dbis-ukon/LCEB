SELECT p.Id, p.Title, p2.Title AS related_title
FROM Posts p
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
WHERE p.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND pl.LinkTypeId = 1;
