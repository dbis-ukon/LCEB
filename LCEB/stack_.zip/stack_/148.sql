SELECT u.DisplayName, b.Name AS BadgeName, t.TagName, p.Title
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Tags t ON t.ExcerptPostId = p.Id
JOIN Votes v ON v.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.Count BETWEEN 97 AND 111
  AND v.VoteTypeId IN (2, 10, 1, 8, 3)
  AND v.CreationDate >= '2017-05-09 00:00:00'
  AND p.ViewCount > 811
  AND u.UpVotes > 0
  AND b.Class <= 3;
