SELECT u.Id, u.DisplayName, u.Location,
       p.Title, b.Name AS BadgeName,
       COUNT(DISTINCT c.Id) AS CommentCount,
       COUNT(DISTINCT v.Id) AS VoteCount
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
LEFT JOIN Comments c ON c.PostId = p.Id
LEFT JOIN Votes v ON v.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.CreationDate >= '2019-03-18 15:03:10.667000'
  AND u.Reputation BETWEEN 11 AND 593
  AND pt.Id = 1
GROUP BY u.Id, u.DisplayName, u.Location, p.Id, p.Title, b.Name
HAVING COUNT(DISTINCT c.Id) > 0
   AND COUNT(DISTINCT v.Id) >= 1
ORDER BY VoteCount DESC, CommentCount DESC;
