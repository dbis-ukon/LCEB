SELECT p.Id, p.Title, 'NewPost' AS ActivityType, p.CreationDate AS ActivityDate
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score >= 2
  AND p.CreationDate >= '2014-02-09 20:31:04'
UNION
SELECT p.Id, p.Title, 'Edited' AS ActivityType, ph.CreationDate AS ActivityDate
FROM PostHistory ph
JOIN Posts p ON p.Id = ph.PostId
WHERE p.Title LIKE '%%'
  AND ph.PostHistoryTypeId IN (1, 24, 2, 33, 3)
  AND ph.CreationDate >= '2012-12-10 12:03:49.650000'
ORDER BY ActivityDate DESC;
