SELECT * FROM Users WHERE DisplayName LIKE '%dev%' AND Reputation > 50;
