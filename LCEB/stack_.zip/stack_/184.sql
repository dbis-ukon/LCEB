SELECT b.Id, u.DisplayName, b.Date, u.Reputation
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name LIKE '%%'
  AND b.TagBased = false
  AND b.Class = 3
  AND b.Date >= '2014-08-25 16:41:11.593000'
  AND u.Reputation <= 1;
