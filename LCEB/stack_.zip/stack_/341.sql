SELECT Id, Name, Class FROM Badges WHERE Name LIKE '%Supporter%' AND UserId <> 0 AND Class IS NOT NULL;
