SELECT p.Id, p.Title, c.Score AS CommentScore,
       c.CreationDate, u.DisplayName
FROM Comments c
JOIN Posts p ON p.Id = c.PostId
JOIN Users u ON u.Id = c.UserId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND c.Score >= 0
  AND c.CreationDate >= '2020-05-24 11:01:09.567000'
  AND p.ClosedDate IS NULL
ORDER BY c.CreationDate DESC;
