SELECT u.Id, u.DisplayName, u.CreationDate
FROM Users u
WHERE u.Location NOT LIKE ''%%'' AND u.Location LIKE '%%' AND u.DisplayName NOT LIKE ''%%''
  AND u.CreationDate >= '2024-03-15 02:47:06.903000'
ORDER BY u.CreationDate
LIMIT 30;
