SELECT p.Id, p.Title, p.Score, p.ViewCount, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.ClosedDate IS NULL
  AND u.LastAccessDate >= '2013-05-07 22:04:31.137000'
ORDER BY p.ViewCount DESC
LIMIT 100;
