SELECT u.Id, u.DisplayName, p.Title, t.TagName, b.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Tags t ON p.Tags LIKE '%<' || t.TagName || '>%'
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND t.TagName NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND p.Score > 2
  AND p.AnswerCount >= 0
  AND p.FavoriteCount > 0
  AND u.Reputation > 1
  AND b.Class <= 3
  AND t.Count BETWEEN 288 AND 4415;
