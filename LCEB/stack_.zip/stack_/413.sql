SELECT u.Id, u.DisplayName, u.Location, b.Name, p.Title
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND b.Name NOT LIKE ''%%''
  AND p.Title LIKE '%%';
