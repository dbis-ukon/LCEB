SELECT t.Id, t.TagName, p.Title, u.DisplayName, pt.Name
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE t.TagName LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND pt.Id = 3;
