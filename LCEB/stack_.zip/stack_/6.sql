SELECT p1.Title AS OriginalTitle, p2.Title AS DuplicateTitle, u1.DisplayName AS OriginalOwner, u2.DisplayName AS DuplicateOwner
FROM Posts p1
JOIN PostLinks pl ON pl.PostId = p1.Id AND pl.LinkTypeId = 3
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
WHERE p1.Title LIKE '%%'
  AND p2.Title NOT LIKE ''%%''
  AND u1.DisplayName NOT LIKE ''%%'';
