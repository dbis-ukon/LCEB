SELECT u.Id, u.DisplayName, u.Location
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score >= 1
INTERSECT
SELECT u.Id, u.DisplayName, u.Location
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score >= 1;
