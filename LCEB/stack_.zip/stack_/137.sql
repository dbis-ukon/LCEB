SELECT p.Id, p.Title, u.DisplayName, COUNT(v.Id) AS vote_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Tags t ON t.WikiPostId = p.Id
WHERE (b.Name LIKE '%%' OR t.TagName LIKE '%%')
  AND u.DisplayName LIKE '%%'
  AND v.BountyAmount IS NOT NULL
  AND u.AccountId IS NOT NULL
  AND u.WebsiteUrl IS NOT NULL
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(v.Id) > 4;
