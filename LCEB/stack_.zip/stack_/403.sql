SELECT Id, DisplayName, Reputation, Views FROM Users WHERE DisplayName LIKE '%John%' AND Reputation BETWEEN 1 AND 500 AND Views BETWEEN 1 AND 5000;
