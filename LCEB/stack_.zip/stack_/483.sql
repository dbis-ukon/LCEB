SELECT Id, Title, Score,
       Score - AVG(Score) OVER () AS DeviationFromAvg
FROM Posts
WHERE (Title LIKE '%deprecated%' OR Title LIKE '%performance%') AND Title NOT LIKE '%bug%' AND Score < 10000 AND ViewCount > 10 AND ViewCount < 1000000 AND AnswerCount >= 0 AND CommentCount >= 0;
