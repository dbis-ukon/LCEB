SELECT b.Id, b.Name, u.Location, p.Title, pt.Name
FROM Badges b
JOIN Users u ON u.Id = b.UserId
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE b.Name LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND pt.Id = 1;
