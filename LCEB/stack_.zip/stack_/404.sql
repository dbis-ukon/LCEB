SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.ViewCount > 344 AND p.AnswerCount >= 2 AND b.Date >= '2020-02-15 22:40:06.613000'
ORDER BY b.Date DESC;
