SELECT t.Id, t.TagName, p.Title, u.Location, pt.Name
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE t.TagName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND pt.Id = 3;
