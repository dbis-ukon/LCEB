SELECT u.Id, u.DisplayName, u.Location
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND u.Reputation > 1
  AND u.Id NOT IN (668157, 1131919, 1295332, 269302, 102386)
ORDER BY u.Reputation DESC;
