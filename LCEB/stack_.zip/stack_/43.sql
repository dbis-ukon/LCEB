SELECT *
FROM Users
WHERE (Location LIKE '%California%' OR Location LIKE '%Texas%')
  AND DisplayName NOT LIKE '%test%'
  AND DisplayName LIKE '%John%'
  AND Reputation > 1000
  AND Views > 100;
