SELECT DISTINCT voter.DisplayName
FROM Posts p
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN Users editor ON ph.UserId = editor.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Users voter ON v.UserId = voter.Id
WHERE editor.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND voter.DisplayName NOT LIKE ''%%'';
