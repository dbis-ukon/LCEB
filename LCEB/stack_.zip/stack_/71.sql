SELECT t.TagName, t.Count
FROM Tags t
WHERE t.TagName LIKE '%%'
  AND t.IsModeratorOnly IS NOT TRUE
ORDER BY t.Count DESC;
