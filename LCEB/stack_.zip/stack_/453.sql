SELECT t.TagName, t.Count, p.Title, p.Score
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
WHERE t.TagName LIKE '%%' 
  AND t.TagName LIKE '%%'
  AND p.Title LIKE '%%'
  AND t.Count BETWEEN 23 AND 1013
  AND p.Score > -1
  AND p.CreationDate >= '2013-05-30 05:54:25.813000'
ORDER BY t.Count DESC;
