SELECT Id, UserId, Name, Date
FROM Badges
WHERE Name NOT LIKE '%Badge%'
  AND TagBased = false;
