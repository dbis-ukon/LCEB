SELECT Id, TagName, Count FROM Tags WHERE TagName LIKE 'python' AND IsModeratorOnly IS NOT TRUE;
