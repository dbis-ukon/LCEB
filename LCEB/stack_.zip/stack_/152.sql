SELECT p.Id, p.Title
FROM Posts p
WHERE (
        p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title NOT LIKE ''%%''
      )
  AND p.AnswerCount >= 2
  AND p.Score > 1
  AND p.ClosedDate IS NULL
  AND NOT EXISTS (
      SELECT 1
      FROM Users u
      WHERE u.Id = p.OwnerUserId
        AND (
            u.DisplayName LIKE '%%'
            OR u.DisplayName LIKE '%%'
            OR u.DisplayName NOT LIKE ''%%''
        )
        AND u.Views > 0
  )
  AND EXISTS (
      SELECT 1
      FROM Comments c
      WHERE c.PostId = p.Id
        AND c.Score > 0
        AND EXISTS (
            SELECT 1
            FROM Users cu
            WHERE cu.Id = c.UserId
              AND (
                  cu.DisplayName LIKE '%%'
                  OR cu.DisplayName LIKE '%%'
                  OR cu.DisplayName NOT LIKE ''%%''
              )
              AND cu.Reputation > 1
        )
  );
