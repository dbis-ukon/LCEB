SELECT p.Id, p.Title, u.DisplayName, p.Score, COUNT(v.Id) AS downvote_count, MAX(v.CreationDate) AS latest_downvote
FROM Posts p
JOIN Votes v ON v.PostId = p.Id
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND v.VoteTypeId = 2
  AND p.Score < 1
  AND p.ViewCount > 124
GROUP BY p.Id, p.Title, u.DisplayName, p.Score
HAVING COUNT(v.Id) > 3
ORDER BY downvote_count DESC;
