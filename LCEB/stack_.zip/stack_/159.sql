SELECT Id, DisplayName,
       EXISTS (SELECT 1 FROM Users b WHERE b.Location = Users.Location AND b.Id <> Users.Id) AS HasPeer
FROM Users
WHERE (DisplayName LIKE '%researcher%' OR DisplayName LIKE '%owner%') AND DisplayName NOT LIKE '%founder%' AND WebsiteUrl IS NOT NULL AND CreationDate >= '2012-01-01' AND LastAccessDate >= '2018-01-01' AND AboutMe IS NOT NULL AND Id > 0;
