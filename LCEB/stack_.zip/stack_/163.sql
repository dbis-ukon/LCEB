SELECT b.Id, b.Name, u.DisplayName, u.Location
FROM Badges b
JOIN Users u ON u.Id = b.UserId
WHERE b.Name LIKE '%%'
  AND u.Location NOT LIKE ''%%'';
