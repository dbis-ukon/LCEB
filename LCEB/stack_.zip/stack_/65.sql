SELECT p.Id, p.Title, p.CreationDate, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Tags t ON t.ExcerptPostId = p.Id OR t.WikiPostId = p.Id
WHERE (u.Location LIKE '%%' OR b.Name LIKE '%%')
  AND (t.TagName LIKE '%%')
  AND p.ClosedDate IS NULL
  AND u.Views > 6
  AND t.Count > 413
ORDER BY p.ViewCount DESC;
