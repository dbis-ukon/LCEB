SELECT p.Id, p.Title, u.Location, b.Name
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND b.Class = 2;
