SELECT u.Id, u.DisplayName, u.Location, b.Name
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Name NOT LIKE ''%%''
  AND p.Score > 0;
