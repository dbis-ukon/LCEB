SELECT
    p.Id,
    p.Title,
    p.Score,
    p.ViewCount,
    u.DisplayName,
    u.Views
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND p.PostTypeId = 1
    AND p.Score >= 6
    AND p.ViewCount >= 74
    AND u.Views >= 0
    AND u.Reputation >= 1
    AND p.ClosedDate IS NULL;
