SELECT IsModeratorOnly,
       COUNT(*) FILTER (WHERE TagName LIKE '%web%') * 1.0 / NULLIF(COUNT(*), 0) AS MatchRatio
FROM Tags
WHERE IsRequired IS NOT TRUE AND Id BETWEEN 1 AND 999999 AND Count > 10 AND Count < 50000 AND IsModeratorOnly IS NOT TRUE
GROUP BY IsModeratorOnly;
