SELECT p.Title, u1.DisplayName, u2.DisplayName
FROM PostHistory ph1
JOIN PostHistory ph2 ON ph1.PostId = ph2.PostId AND ph2.CreationDate > ph1.CreationDate
JOIN Users u1 ON ph1.UserId = u1.Id
JOIN Users u2 ON ph2.UserId = u2.Id
JOIN Posts p ON p.Id = ph1.PostId
WHERE p.Title LIKE '%%'
  AND u2.DisplayName NOT LIKE ''%%''
  AND ph1.CreationDate >= '2017-06-27 18:15:15.870000';
