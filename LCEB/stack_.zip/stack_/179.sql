SELECT p.Id AS ItemId, 'Post' AS SourceType, p.Title AS MatchedText
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.CreationDate >= '2015-01-31 19:13:03.863000' AND p.LastEditDate IS NOT NULL
UNION
SELECT c.Id AS ItemId, 'Comment' AS SourceType, u.DisplayName AS MatchedText
FROM Comments c
JOIN Users u ON u.Id = c.UserId
WHERE u.DisplayName LIKE '%%';
