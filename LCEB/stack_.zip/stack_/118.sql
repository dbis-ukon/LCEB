SELECT a.Id, a.DisplayName
FROM Users a
WHERE (a.DisplayName LIKE '%%' OR a.DisplayName LIKE '%%') AND a.DisplayName NOT LIKE ''%%''
  AND LastAccessDate >= '2018-01-01' AND AboutMe IS NOT NULL AND Id > 0 AND Reputation BETWEEN 50 AND 100000 AND Views BETWEEN 1 AND 1000000
  AND NOT EXISTS (SELECT 1 FROM Users b WHERE b.Location = a.Location AND b.Reputation < 121);
