SELECT p.Id, p.Title, u.DisplayName, u.Location, p.ViewCount, p.AnswerCount
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Score > 4
  AND p.ViewCount > 43
  AND p.AnswerCount > 1
  AND p.ClosedDate IS NULL;
