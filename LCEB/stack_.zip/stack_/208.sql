SELECT u.DisplayName, p.Title, c.Text, v.VoteTypeId, pt.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.DisplayName NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND c.Score > -1
  AND v.VoteTypeId = 2
  AND pt.Id = 1;
