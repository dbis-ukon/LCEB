SELECT p.Id, p.Title, u.DisplayName, p.Score
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score > (SELECT AVG(Score) FROM Posts WHERE PostTypeId = 1)
  AND p.ViewCount > 1185
  AND u.Reputation > 3
  AND p.AnswerCount > -1
ORDER BY p.Score DESC;
