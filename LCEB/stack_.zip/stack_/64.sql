SELECT u.Id, u.DisplayName
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND EXISTS (
      SELECT 1 FROM Posts p WHERE p.OwnerUserId = u.Id AND p.Title LIKE '%%'
        AND EXISTS (
            SELECT 1 FROM Comments c WHERE c.PostId = p.Id
              AND EXISTS (
                  SELECT 1 FROM Users cu WHERE cu.Id = c.UserId AND cu.DisplayName NOT LIKE ''%%''
              )
        )
  );
