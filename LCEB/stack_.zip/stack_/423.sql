SELECT p.Id, p.Title, p.Score, p.ViewCount
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title NOT LIKE ''%%'' OR u.DisplayName LIKE '%%')
  AND p.CommentCount > -1
  AND u.DownVotes < 0
ORDER BY p.CreationDate DESC;
