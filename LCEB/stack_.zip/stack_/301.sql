SELECT Id, TagName, Count
FROM Tags
WHERE (TagName LIKE '%orm%' OR TagName LIKE '%rest%') AND TagName NOT LIKE '%security%' AND ExcerptPostId IS NOT NULL AND WikiPostId IS NOT NULL AND Id > 0 AND Count <> 0 AND Count BETWEEN 1 AND 50000
ORDER BY
    CASE WHEN Count > 100 THEN 0 ELSE 1 END,
    Count DESC;
