SELECT p.Id, p.Title, p.CreationDate
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE (u.DisplayName LIKE '%%' OR u.Location LIKE '%%')
  AND p.FavoriteCount > 1
  AND u.Reputation BETWEEN 1 AND 1
ORDER BY p.Score DESC;
