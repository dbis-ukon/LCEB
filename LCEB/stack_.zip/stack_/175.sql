SELECT p.Id, p.Title, u.DisplayName, b.Name, c.Text
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND b.Class <> 2
  AND u.Location LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND c.Score >= 0
  AND b.Class <= 3
  AND p.Score > 1
  AND p.AnswerCount >= 1
  AND u.Reputation > 31
ORDER BY p.CreationDate DESC;
