SELECT b.Id, b.Name, u.DisplayName, p.Title
FROM Badges b
JOIN Users u ON u.Id = b.UserId
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE b.Name LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND p.Score > 1;
