SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName,
       pt.Name AS PostType, COUNT(DISTINCT c.Id) AS CommentCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
LEFT JOIN Comments c ON c.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Score >= 14
  AND p.CreationDate >= '2020-04-30 13:56:41.230000'
  AND b.Class IN (3)
  AND pt.Id IN (1, 7, 4, 3, 8)
GROUP BY p.Id, p.Title, u.DisplayName, b.Name, pt.Name
HAVING COUNT(DISTINCT c.Id) >= 1
ORDER BY CommentCount DESC;
