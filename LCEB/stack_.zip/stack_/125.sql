SELECT p.Id, p.Title, u.DisplayName, u.Reputation
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND p.Score > -1 AND p.ViewCount > 21 AND u.Reputation > 101 AND u.Views > 0
ORDER BY p.ViewCount DESC
LIMIT 25;
