SELECT p.Id, p.Title, pt.Name AS PostType
FROM Posts p
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND pt.Name LIKE '%%'
  AND p.Score > -1
  AND p.ViewCount > 61
  AND p.AnswerCount >= 1
  AND p.ClosedDate IS NULL;
