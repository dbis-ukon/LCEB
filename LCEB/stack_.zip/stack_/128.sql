SELECT u.Id, u.DisplayName, SUM(p.ViewCount) AS total_views
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.Location LIKE '%%'
  AND p.PostTypeId = 1
GROUP BY u.Id, u.DisplayName
HAVING SUM(p.ViewCount) > 10000;
