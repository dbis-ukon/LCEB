SELECT u.DisplayName, p1.Title AS TopicA, p2.Title AS TopicB
FROM Posts p1
JOIN Posts p2 ON p1.OwnerUserId = p2.OwnerUserId AND p1.Id <> p2.Id
JOIN Users u ON p1.OwnerUserId = u.Id
WHERE p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND p1.Score > 1
  AND p2.Score > 0
  AND u.Reputation > 159
  AND p1.PostTypeId = 1
  AND p2.PostTypeId = 1
ORDER BY u.Reputation DESC;
