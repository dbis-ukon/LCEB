SELECT p.Title, u.DisplayName, b.Name AS BadgeName
FROM Votes v1
JOIN Votes v2 ON v1.PostId = v2.PostId AND v1.UserId = v2.UserId AND v1.VoteTypeId <> v2.VoteTypeId
JOIN Users u ON v1.UserId = u.Id
JOIN Posts p ON p.Id = v1.PostId
JOIN Badges b ON b.UserId = u.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%') AND p.Title NOT LIKE ''%%'' AND u.DisplayName NOT LIKE ''%%'' AND b.Name LIKE '%%';
