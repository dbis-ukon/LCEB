SELECT t.Id, t.TagName, p.Title, u.Location
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
WHERE t.TagName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND p.Score > -1;
