SELECT p.Id, p.Title, u.DisplayName, t.TagName,
       b.Name AS BadgeName, c.Score AS CommentScore,
       commenter.Location AS CommenterLocation
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.ExcerptPostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Users commenter ON commenter.Id = c.UserId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Name LIKE '%%'
  AND commenter.Location LIKE '%%'
  AND c.Score >= 0
  AND t.Count > 39
  AND p.ClosedDate IS NULL
ORDER BY c.Score DESC;
