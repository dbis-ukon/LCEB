SELECT Id, DisplayName FROM Users WHERE DisplayName LIKE '%admin%' AND WebsiteUrl IS NOT NULL LIMIT 50;
