SELECT u.Location, COUNT(*) AS member_count, AVG(u.Reputation) AS avg_rep
FROM Users u
WHERE u.Location LIKE '%%'
  AND u.LastAccessDate >= '2018-11-28 19:29:44.007000' AND u.Reputation BETWEEN 1 AND 121
GROUP BY u.Location
HAVING COUNT(*) > 2;
