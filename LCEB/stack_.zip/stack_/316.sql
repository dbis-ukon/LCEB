SELECT
    p.Id,
    p.Title,
    ph.PostHistoryTypeId,
    u.DisplayName
FROM Posts p
JOIN PostHistory ph ON ph.PostId = p.Id
LEFT JOIN Users u ON u.Id = ph.UserId
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (ph.Comment LIKE '%%' OR ph.Comment LIKE '%%' OR ph.Comment NOT LIKE ''%%'')
    AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND ph.PostHistoryTypeId IN (2, 6, 1, 3, 5)
    AND p.PostTypeId = 1
    AND ph.CreationDate >= '2018-05-11 12:12:13.370000';
