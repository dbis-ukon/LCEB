SELECT b.Id, b.Name, u.DisplayName,
       (SELECT u2.CreationDate FROM Users u2 WHERE u2.Id = b.UserId) AS UserJoinDate
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND b.Class = 2
ORDER BY UserJoinDate DESC;
