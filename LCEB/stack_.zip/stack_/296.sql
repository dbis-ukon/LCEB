SELECT b.Name, b.Class, COUNT(*) AS award_count
FROM Badges b
WHERE (b.Name LIKE '%%' OR b.Name LIKE '%%')
  AND b.Class IN (3, 2)
  AND b.Date BETWEEN '2012-01-01' AND '2020-12-31'
GROUP BY b.Name, b.Class
ORDER BY award_count DESC;
