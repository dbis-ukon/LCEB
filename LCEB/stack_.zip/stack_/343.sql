SELECT p.Id, p.Title, u.Location, b.Name, pt.Name
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND b.Name LIKE '%%'
  AND pt.Id = 1;
