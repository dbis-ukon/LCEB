SELECT b.Id, b.Name, u.DisplayName, p.Title
FROM Badges b
JOIN Users u ON u.Id = b.UserId
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE b.Name NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.Score > 0;
