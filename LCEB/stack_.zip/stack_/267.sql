SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Id IN (741059, 490617, 846642, 1138510, 324147)
  AND u.DisplayName LIKE '%%';
