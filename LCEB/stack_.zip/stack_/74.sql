SELECT p1.Id AS QuestionId, p1.Title, u1.DisplayName AS Asker, u2.DisplayName AS Answerer, p2.Score AS AnswerScore
FROM Posts p1
JOIN Posts p2 ON p1.AcceptedAnswerId = p2.Id
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
WHERE p1.Title LIKE '%%'
  AND u1.DisplayName NOT LIKE ''%%''
  AND u2.DisplayName LIKE '%%'
  AND u2.Location LIKE '%%'
  AND p2.Score > 1
  AND p1.PostTypeId = 1
  AND u2.Reputation > 1669
  AND p1.ViewCount > 52
  AND p1.AnswerCount >= 2
ORDER BY p2.Score DESC;
