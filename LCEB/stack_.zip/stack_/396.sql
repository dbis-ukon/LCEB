SELECT a.Id, a.TagName,
       (SELECT MIN(b.TagName) FROM Tags b WHERE b.IsModeratorOnly = a.IsModeratorOnly) AS FirstAlphaInGroup
FROM Tags a
WHERE (a.TagName LIKE '%%' OR a.TagName LIKE '%%') AND a.TagName NOT LIKE ''%%''
  AND IsModeratorOnly IS NOT TRUE AND IsRequired IS NOT TRUE AND ExcerptPostId IS NOT NULL AND WikiPostId IS NOT NULL AND Id > 0;
