SELECT u.DisplayName, b1.Name AS GoldBadge, b2.Name AS SilverBadge
FROM Badges b1
JOIN Badges b2 ON b1.UserId = b2.UserId AND b1.Class = 1 AND b2.Class = 2
JOIN Users u ON b1.UserId = u.Id
WHERE b1.Name LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.CreationDate >= '2020-04-07 09:47:33.773000' AND u.LastAccessDate >= '2021-11-10 20:49:04.480000';
