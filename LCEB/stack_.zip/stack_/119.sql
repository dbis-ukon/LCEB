SELECT
    u.DisplayName,
    u.Location,
    b.Name,
    p.Title,
    p.Score
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE
    (u.Location LIKE '%%' OR u.Location LIKE '%%' OR u.Location NOT LIKE ''%%'')
    AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND (b.Name LIKE '%%' OR b.Name LIKE '%%' OR b.Name NOT LIKE ''%%'')
    AND (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND u.Location IS NOT NULL
    AND u.Reputation >= 1
    AND b.Class IN (3, 2)
    AND p.Score >= 2
    AND p.PostTypeId = 1;
