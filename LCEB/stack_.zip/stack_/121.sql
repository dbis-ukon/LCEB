SELECT p1.Title AS Source, p2.Title AS Related, lt.Name AS LinkType
FROM PostLinks pl
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
JOIN Posts p1 ON p1.Id = pl.PostId
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
WHERE p1.Title LIKE '%%'
  AND lt.Name LIKE '%%'
  AND pl.CreationDate >= '2017-12-05 19:06:55.190000';
