SELECT u.Id, u.DisplayName, u.Reputation, b.Name AS BadgeName,
       b.Date AS BadgeDate
FROM Users u
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND u.Reputation > 1
  AND b.Class = 3
  AND b.TagBased = FALSE
  AND b.Date >= '2018-02-28 12:18:51.553000'
ORDER BY b.Date DESC;
