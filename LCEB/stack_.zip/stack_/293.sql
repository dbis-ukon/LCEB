SELECT t.Id, t.TagName, p.Title, u.Location
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
JOIN Comments c ON c.PostId = p.Id
WHERE t.TagName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND p.Score >= 3
  AND t.Count > 1529
  AND t.IsRequired IS NOT TRUE
  AND p.ViewCount >= 66
  AND c.Score >= 0
  AND u.Reputation > 1
  AND pt.Id IN (5, 1, 8, 7, 4);
