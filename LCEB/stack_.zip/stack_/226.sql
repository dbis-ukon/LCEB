SELECT p.Title, pht.Name AS ChangeType, u.DisplayName AS Editor
FROM PostHistory ph
JOIN PostHistoryTypes pht ON pht.Id = ph.PostHistoryTypeId
JOIN Posts p ON p.Id = ph.PostId
JOIN Users u ON u.Id = ph.UserId
WHERE p.Title LIKE '%%'
  AND pht.Name LIKE '%%'
  AND u.WebsiteUrl IS NOT NULL AND u.CreationDate >= '2021-01-15 23:51:54.733000';
