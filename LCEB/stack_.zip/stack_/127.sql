SELECT p.Id, p.Title
FROM Posts p
CROSS JOIN Tags t
WHERE p.Tags LIKE '%%' AND p.Title LIKE '%%'
  AND (t.TagName LIKE '%%' OR t.TagName LIKE '%%')
  AND p.Score > 0
  AND p.Id IN (387128, 175676, 1235117, 2241715, 2535737);
