SELECT p.Id, p.Title, u.DisplayName,
       t.TagName, b.Name AS BadgeName,
       COUNT(DISTINCT v.Id) AS VoteCount,
       COUNT(DISTINCT c.Id) AS CommentCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.WikiPostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Comments c ON c.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Name LIKE '%%'
  AND vt.Id IN (14, 16, 12, 10, 7)
  AND v.CreationDate >= '2023-05-21 00:00:00'
  AND c.Score >= 0
  AND p.AnswerCount >= 0
  AND t.Count > 19
GROUP BY p.Id, p.Title, u.DisplayName, t.TagName, b.Name
HAVING COUNT(DISTINCT v.Id) >= 2
   AND COUNT(DISTINCT c.Id) >= 1
ORDER BY VoteCount DESC, CommentCount DESC;
