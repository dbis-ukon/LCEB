SELECT p.Id, p.Title, pl.RelatedPostId, u.DisplayName
FROM Posts p
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN Users u ON u.Id = p.OwnerUserId
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
  AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
  AND p.Score >= -1
  AND p.ViewCount > 1398
  AND u.Reputation >= 1;
