SELECT u.Location, p.Title, b.Name, ph.Comment, pt.Name, c.Score
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
JOIN Comments c ON c.PostId = p.Id
WHERE u.Location NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND ph.PostHistoryTypeId IN (4, 5, 2, 3, 1)
  AND pt.Id = 1
  AND c.Score > 0;
