SELECT p.Id, p.Title, u.DisplayName, t.TagName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.WikiPostId = p.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND p.Score >= 0
  AND p.FavoriteCount > 0
  AND t.Count BETWEEN 101 AND 148
  AND t.IsRequired IS TRUE
ORDER BY p.FavoriteCount DESC;
