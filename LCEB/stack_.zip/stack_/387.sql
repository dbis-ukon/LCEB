SELECT Id, DisplayName, Reputation FROM Users WHERE DisplayName LIKE '%senior%' AND AccountId IS NOT NULL ORDER BY Reputation ASC;
