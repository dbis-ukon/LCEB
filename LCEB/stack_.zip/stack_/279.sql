SELECT
    p.Id,
    p.Title,
    u.DisplayName,
    t.TagName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON p.Id = t.WikiPostId
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND (t.TagName LIKE '%%' OR t.TagName LIKE '%%' OR t.TagName NOT LIKE ''%%'')
    AND p.PostTypeId IN (1, 2)
    AND p.Score >= 6
    AND t.WikiPostId IS NOT NULL
    AND u.Reputation >= 103;
