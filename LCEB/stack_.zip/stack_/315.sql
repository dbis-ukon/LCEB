SELECT p1.Id AS QuestionId,
       p1.Title AS QuestionTitle,
       u1.DisplayName AS QuestionOwner,
       p2.Id AS AnswerId,
       p2.Title AS AnswerTitle,
       u2.DisplayName AS AnswerOwner,
       b.Name AS AnswerOwnerBadge,
       pt.Name AS AnswerPostType
FROM Posts p1
JOIN Posts p2 ON p2.ParentId = p1.Id
JOIN Users u1 ON u1.Id = p1.OwnerUserId
JOIN Users u2 ON u2.Id = p2.OwnerUserId
JOIN Badges b ON b.UserId = u2.Id
JOIN PostTypes pt ON pt.Id = p2.PostTypeId
JOIN Comments c ON c.PostId = p2.Id
WHERE p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND u1.DisplayName LIKE '%%'
  AND u2.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND p1.PostTypeId = 2
  AND p2.AcceptedAnswerId IS NULL
  AND p2.Score > 0
  AND p2.CreationDate >= p1.CreationDate
  AND c.Score >= 0
  AND pt.Id = 8
GROUP BY p1.Id, p1.Title, u1.DisplayName,
         p2.Id, p2.Title, u2.DisplayName,
         b.Name, pt.Name
HAVING COUNT(DISTINCT c.Id) >= 1
ORDER BY p2.Score DESC;
