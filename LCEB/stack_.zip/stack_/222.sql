SELECT p.Id, p.Title
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.LastEditDate IS NOT NULL AND p.ParentId IS NULL
  AND NOT EXISTS (
      SELECT 1 FROM PostLinks pl WHERE pl.PostId = p.Id
  );
