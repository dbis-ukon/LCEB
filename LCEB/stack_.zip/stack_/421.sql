SELECT p.Id, p.Title, u.DisplayName AS editor, ph.CreationDate AS edit_date
FROM Posts p
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN Users u ON ph.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND ph.PostHistoryTypeId IN (5, 3, 2, 1, 6)
  AND ph.CreationDate >= '2017-05-02 23:25:29.880000'
  AND p.Score > -1
ORDER BY ph.CreationDate DESC;
