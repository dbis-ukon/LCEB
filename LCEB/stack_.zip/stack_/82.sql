SELECT p.Id, p.Title, t.TagName, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Tags t ON t.ExcerptPostId = p.Id
JOIN Votes v ON v.UserId = u.Id AND v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE (t.TagName LIKE '%%' OR p.Title NOT  LIKE ''%%'')
  AND u.Location LIKE '%%'
  AND t.IsModeratorOnly IS NOT TRUE AND u.Reputation > 1 AND u.Views > 0
  AND v.CreationDate IS NOT NULL
ORDER BY t.Count DESC;
