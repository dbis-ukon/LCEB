SELECT p.Id, p.Title, p.Score, p.ViewCount
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score >= 1
  AND p.ClosedDate IS NULL
  AND NOT EXISTS (
      SELECT 1 FROM PostLinks pl WHERE pl.PostId = p.Id AND pl.LinkTypeId = 1
  )
ORDER BY p.ViewCount DESC;
