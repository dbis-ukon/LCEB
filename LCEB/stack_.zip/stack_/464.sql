SELECT p.Id, p.Title, u.DisplayName, vt.Name AS VoteType, COUNT(*) AS VoteCount
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND vt.Name IN ('Undeletion', 'ApproveEditSuggestion', 'UpMod', 'Close', 'Bookmark')
  AND p.PostTypeId = 1
  AND p.Score >= 2
GROUP BY p.Id, p.Title, u.DisplayName, vt.Name
HAVING COUNT(*) > 2
ORDER BY VoteCount DESC;
