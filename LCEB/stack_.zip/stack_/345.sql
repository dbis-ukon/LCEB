SELECT b.Name AS BadgeName, u.DisplayName, u.Location
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name LIKE '%%'
  AND u.Location LIKE '%%';
