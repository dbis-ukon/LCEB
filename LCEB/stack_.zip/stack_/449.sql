SELECT t.Id, t.TagName, p.Title, u.Location
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
JOIN Users u ON u.Id = p.OwnerUserId
WHERE t.TagName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Score >= 0;
