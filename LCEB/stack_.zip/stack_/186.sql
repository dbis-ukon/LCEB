SELECT u.DisplayName, p.Title, b.Name, c.Text, pt.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.DisplayName NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND b.Name NOT LIKE ''%%''
  AND c.Score >= 0
  AND pt.Id = 1;
