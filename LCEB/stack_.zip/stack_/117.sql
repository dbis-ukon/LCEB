SELECT b.Id, b.Name, u.DisplayName
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND b.Class <= 3
  AND EXISTS (
      SELECT 1 FROM Posts p WHERE p.OwnerUserId = u.Id AND p.Title LIKE '%%'
  )
ORDER BY b.Date DESC;
