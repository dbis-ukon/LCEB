SELECT p1.Id AS QuestionId, p1.Title AS QuestionTitle, p2.Title AS AnswerTitle, u.DisplayName
FROM Posts p1
JOIN Posts p2 ON p2.ParentId = p1.Id
JOIN Users u ON p1.OwnerUserId = u.Id
WHERE p1.Title LIKE '%%'
  AND u.DisplayName LIKE '%%';
