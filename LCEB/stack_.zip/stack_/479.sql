SELECT p.Title, t.TagName, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
CROSS JOIN Tags t
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
WHERE p.Tags LIKE '%%' AND p.Title NOT LIKE ''%%'' AND t.TagName LIKE '%%'
  AND v.VoteTypeId = 2
LIMIT 15;
