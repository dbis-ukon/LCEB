SELECT u.Id, u.DisplayName, u.Reputation
FROM Users u
WHERE u.Location NOT LIKE ''%%''
  AND u.Reputation BETWEEN 1 AND 101
ORDER BY u.Reputation DESC
LIMIT 25;
