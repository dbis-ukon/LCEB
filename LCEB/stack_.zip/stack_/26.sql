SELECT Name, Date, Class
FROM Badges
WHERE Name LIKE '%Year%'
  AND Date >= '2021-01-01'
  AND Class = 2;
