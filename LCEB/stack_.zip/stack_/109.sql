SELECT Location, COUNT(*) FILTER (WHERE (DisplayName LIKE '%dev%' OR DisplayName LIKE '%bot%') AND DisplayName NOT LIKE 'Admin%') AS Matches, AVG(Reputation) AS AvgVal
FROM Users
WHERE Reputation BETWEEN 50 AND 100000 AND Views BETWEEN 1 AND 1000000 AND UpVotes BETWEEN 0 AND 5000 AND DownVotes BETWEEN 0 AND 500 AND Reputation IN (100, 500, 1000, 5000)
GROUP BY Location
HAVING COUNT(*) > 0
ORDER BY Matches DESC;
