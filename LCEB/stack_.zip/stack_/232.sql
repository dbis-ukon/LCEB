SELECT p.Id, p.Title
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.PostTypeId = 1;
