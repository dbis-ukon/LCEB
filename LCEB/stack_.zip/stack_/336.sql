SELECT Id, DisplayName
FROM Users
WHERE (DisplayName LIKE 'Admin%' OR DisplayName LIKE '%engineer%') AND DisplayName NOT LIKE '%John%'
  AND CreationDate >= '2012-01-01' AND LastAccessDate >= '2018-01-01' AND AboutMe IS NOT NULL AND Id > 0 AND Reputation BETWEEN 50 AND 100000
  AND Reputation IS DISTINCT FROM (SELECT MIN(Reputation) FROM Users);
