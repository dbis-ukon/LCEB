SELECT p.Id, p.Title, u.DisplayName, u.Location, p.Score, p.ViewCount
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%')
  AND (u.DisplayName LIKE '%%' OR u.Location LIKE '%%')
  AND p.PostTypeId = 1
  AND p.Score > 1
  AND p.ViewCount > 1082
  AND p.AnswerCount >= 2
  AND u.Reputation > 121
ORDER BY p.Score DESC;
