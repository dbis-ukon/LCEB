SELECT p.Title, u.DisplayName, b.Name, c.Text
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Class = 3
  AND c.Score > 0
ORDER BY p.CreationDate DESC
LIMIT 20;
