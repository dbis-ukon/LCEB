SELECT u.Id, u.DisplayName, u.Location, p.Title
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND u.Reputation < 1
  AND p.Score >= 1
  AND u.Views < 60
  AND NOT EXISTS (
      SELECT 1 FROM Badges b WHERE b.UserId = u.Id AND b.Class = 1
  )
ORDER BY p.CreationDate DESC;
