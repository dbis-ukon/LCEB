SELECT p.Id, p.Title
FROM Posts p
CROSS JOIN Tags t
WHERE p.Tags LIKE '%%' AND p.Title LIKE '%%'
  AND t.TagName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND p.Id IN (4844925, 4143240, 2007431, 3429291, 383725);
