SELECT p.Id, p.Title, u1.DisplayName AS Commenter, u2.DisplayName AS Voter
FROM Posts p
JOIN Comments c ON c.PostId = p.Id
JOIN Users u1 ON c.UserId = u1.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Users u2 ON v.UserId = u2.Id
WHERE p.Title LIKE '%%'
  AND u1.DisplayName LIKE '%%'
  AND u2.DisplayName LIKE '%%';
