SELECT p.Id, p.Title, u.DisplayName, t.TagName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.WikiPostId = p.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
  AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
  AND (t.TagName LIKE '%%' OR t.TagName LIKE '%%' OR t.TagName NOT LIKE ''%%'')
  AND p.PostTypeId = 2
  AND p.Score >= 3
  AND p.ViewCount >= 49
  AND t.Count >= 779
  AND u.Views >= 0;
