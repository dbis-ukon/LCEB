SELECT p.Id, p.Title, vt.Name, COUNT(*) AS vote_count
FROM Posts p
JOIN Votes v ON v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND vt.Name IN ('Close', 'DownMod', 'Deletion', 'Reopen', 'Offensive')
  AND p.PostTypeId = 1
GROUP BY p.Id, p.Title, vt.Name;
