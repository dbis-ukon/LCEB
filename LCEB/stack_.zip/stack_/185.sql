SELECT
    COUNT(*) FILTER (WHERE (Name LIKE '%Promoter%' OR Name LIKE '%Custodian%')) AS MatchCount,
    COUNT(*) FILTER (WHERE NOT ((Name LIKE '%Promoter%' OR Name LIKE '%Custodian%'))) AS NonMatchCount,
    COUNT(*) AS TotalRows
FROM Badges
WHERE Date BETWEEN '2010-01-01' AND '2024-12-31' AND Class IN (1, 2, 3) AND UserId IS NOT NULL;
