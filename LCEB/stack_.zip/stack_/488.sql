SELECT u.Id, u.DisplayName, COUNT(c.Id) AS comment_count
FROM Users u
JOIN Comments c ON c.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Reputation > 1
GROUP BY u.Id, u.DisplayName
HAVING COUNT(c.Id) > 100;
