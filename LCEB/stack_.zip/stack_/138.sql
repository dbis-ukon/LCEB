SELECT p.Id, p.Title, u.DisplayName, COUNT(c.Id) AS comment_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
WHERE (p.Title LIKE '%%' OR  u.Location NOT LIKE ''%%'')
  AND p.LastEditDate IS NOT NULL
  AND p.ParentId IS NULL
  AND u.Views > 4
  AND u.UpVotes > -1
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(c.Id) > 0;
