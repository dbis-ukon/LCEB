SELECT p.Id, p.Title, u.DisplayName, u.Reputation
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND (u.DisplayName LIKE '%%' OR u.Location NOT LIKE ''%%'')
  AND u.DisplayName LIKE '%%'
  AND p.Score > 1 AND p.ViewCount > 379 AND u.Reputation > 1
ORDER BY p.ViewCount DESC;
