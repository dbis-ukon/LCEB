SELECT p.Id, p.Title, u.DisplayName, u.WebsiteUrl
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%')
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND u.WebsiteUrl IS NOT NULL
  AND u.AboutMe IS NOT NULL
  AND p.ClosedDate IS NULL
  AND p.AcceptedAnswerId IS NOT NULL
  AND p.Score > 1
ORDER BY p.Score DESC;
