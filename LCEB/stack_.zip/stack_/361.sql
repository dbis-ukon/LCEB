SELECT p.Title, vt.Name AS VoteType, u.DisplayName AS Bountier, v.BountyAmount, v.CreationDate
FROM Votes v
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
JOIN Users u ON u.Id = v.UserId
JOIN Posts p ON p.Id = v.PostId
WHERE vt.Name LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.Title LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND v.BountyAmount >= 200
  AND u.WebsiteUrl IS NOT NULL;
