SELECT b.Id, b.Name
FROM Badges b
WHERE b.Name LIKE '%%'
  AND b.Class = 3;
