SELECT Id, DisplayName, Location, Reputation
FROM Users
WHERE Location LIKE '%France%'
  AND DisplayName LIKE '%Pierre%'
  AND DisplayName NOT LIKE '%test%';
