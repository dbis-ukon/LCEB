SELECT u.DisplayName, u.Location, b.Name AS BadgeName, p.Title
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Title LIKE '%%';
