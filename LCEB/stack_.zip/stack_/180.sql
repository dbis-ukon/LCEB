SELECT b.Id, b.Name, u.Location, p.Title, pt.Name
FROM Badges b
JOIN Users u ON u.Id = b.UserId
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE b.Name LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND pt.Id IN (4, 6, 3, 5, 2)
  AND b.Date >= '2019-12-12 14:05:20.560000'
  AND b.Class BETWEEN 3 AND 3
  AND u.DownVotes < 0
  AND p.CommentCount >= 0
  AND p.LastActivityDate IS NOT NULL;
