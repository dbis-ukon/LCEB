SELECT a.Id, a.TagName
FROM Tags a
WHERE (a.TagName LIKE '%%' OR a.TagName LIKE '%%') AND a.TagName NOT LIKE ''%%''
  AND IsRequired IS NOT TRUE AND ExcerptPostId IS NOT NULL AND WikiPostId IS NOT NULL AND Id > 0 AND Count <> 0
  AND NOT EXISTS (SELECT 1 FROM Tags b WHERE b.IsModeratorOnly = a.IsModeratorOnly AND b.Count < 37);
