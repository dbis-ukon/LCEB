SELECT
    u.DisplayName,
    c.Text,
    p.Title,
    c.CreationDate
FROM Users u
JOIN Comments c ON c.UserId = u.Id
JOIN Posts p ON p.Id = c.PostId
WHERE
    (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND (c.Text LIKE '%%' OR c.Text LIKE '%%' OR c.Text NOT LIKE ''%%'')
    AND (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND u.Reputation >= 1
    AND c.Score >= 0
    AND p.Score >= 5
    AND p.PostTypeId = 1;
