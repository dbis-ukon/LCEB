SELECT p.Id, p.Title, u.DisplayName, u.Reputation
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND (u.DisplayName LIKE '%%' OR u.Location LIKE '%%')
  AND p.LastEditDate IS NOT NULL AND p.ParentId IS NULL AND u.LastAccessDate >= '2021-03-31 14:00:41.247000' AND u.Reputation BETWEEN 1 AND 131
ORDER BY p.ViewCount DESC
LIMIT 25;
