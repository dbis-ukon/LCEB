SELECT
    p.Id,
    p.Title,
    accepted.Title AS AcceptedTitle,
    p.Score
FROM Posts p
JOIN Posts accepted ON accepted.Id = p.AcceptedAnswerId
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (accepted.Title LIKE '%%' OR accepted.Title LIKE '%%' OR accepted.Title NOT LIKE ''%%'')
    AND p.PostTypeId = 1
    AND accepted.PostTypeId = 1
    AND p.AcceptedAnswerId IS NOT NULL
    AND p.Score >= 1
    AND accepted.Score >= 2;
