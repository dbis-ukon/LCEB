SELECT
    p.Id,
    p.Title,
    p.Score,
    p.ViewCount,
    p.AnswerCount,
    u.DisplayName,
    u.Reputation
FROM Posts p
JOIN Users u
    ON p.OwnerUserId = u.Id
WHERE (
        p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title NOT LIKE ''%%''
      )
  AND (
        u.DisplayName LIKE '%%'
        OR u.DisplayName LIKE '%%'
        OR u.DisplayName NOT LIKE ''%%''
      )
  AND p.PostTypeId = 1
  AND p.ClosedDate IS NULL
  AND p.Score >= 0
  AND p.ViewCount > 80
  AND p.AnswerCount >= 0
  AND u.LastAccessDate >= '2019-02-04 18:17:06.493000'
  AND u.Reputation >= 1
ORDER BY p.ViewCount DESC
LIMIT 25;
