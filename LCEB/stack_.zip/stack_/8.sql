SELECT p.Id, p.Title, u.DisplayName, u.Location
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score >= 1
  AND p.ClosedDate IS NULL
  AND p.ViewCount > 79
  AND p.AnswerCount = 2
  AND NOT EXISTS (
      SELECT 1 FROM PostLinks pl WHERE pl.PostId = p.Id AND pl.LinkTypeId = 1
  )
ORDER BY p.ViewCount DESC;
