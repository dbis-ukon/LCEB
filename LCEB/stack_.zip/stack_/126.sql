SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Score > (SELECT AVG(Score) FROM Posts)
  AND p.ViewCount BETWEEN 54 AND 57 AND p.Score > -1;
