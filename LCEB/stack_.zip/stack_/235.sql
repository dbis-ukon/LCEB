SELECT sub.Id, sub.DisplayName
FROM (
    SELECT Id, DisplayName, DENSE_RANK() OVER (ORDER BY Reputation DESC) AS dr
    FROM Users
    WHERE (DisplayName LIKE '%bot%' OR DisplayName LIKE 'Admin%') AND DisplayName NOT LIKE '%engineer%' AND DownVotes < 500 AND AccountId IS NOT NULL AND WebsiteUrl IS NOT NULL AND CreationDate >= '2012-01-01' AND LastAccessDate >= '2018-01-01'
) sub
WHERE sub.dr = 3;
