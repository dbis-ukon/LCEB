SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score >= 3
  AND p.ClosedDate IS NULL
ORDER BY p.Score DESC;
