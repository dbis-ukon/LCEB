SELECT Id, DisplayName FROM Users WHERE DisplayName NOT LIKE 'A%' AND DisplayName NOT LIKE '%test%' AND DisplayName NOT LIKE '%manager%' AND CreationDate >= '2012-01-01';
