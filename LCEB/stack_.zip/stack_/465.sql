SELECT p1.Title AS Level1, p2.Title AS Level2, p3.Title AS Level3, u1.DisplayName AS Author1, u3.DisplayName AS Author3
FROM Posts p1
JOIN PostLinks pl1 ON pl1.PostId = p1.Id
JOIN Posts p2 ON p2.Id = pl1.RelatedPostId
JOIN PostLinks pl2 ON pl2.PostId = p2.Id
JOIN Posts p3 ON p3.Id = pl2.RelatedPostId
JOIN Users u1 ON u1.Id = p1.OwnerUserId
JOIN Users u3 ON u3.Id = p3.OwnerUserId
WHERE p1.Title LIKE '%%'
  AND u1.DisplayName LIKE '%%'
  AND u1.DisplayName LIKE '%%'
  AND u3.DisplayName NOT LIKE ''%%''
  AND pl2.LinkTypeId = 1;
