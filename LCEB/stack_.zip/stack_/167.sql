SELECT Location, Reputation, COUNT(*) AS Cnt
FROM Users
WHERE (DisplayName LIKE '%owner%' OR DisplayName LIKE '%founder%') AND DisplayName NOT LIKE '%dev%' AND CreationDate >= '2012-01-01' AND LastAccessDate >= '2018-01-01' AND AboutMe IS NOT NULL AND Id > 0 AND Reputation BETWEEN 50 AND 100000
GROUP BY GROUPING SETS ((Location), (Reputation), ())
ORDER BY Location;
