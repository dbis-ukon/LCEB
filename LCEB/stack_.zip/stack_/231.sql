SELECT p.Id, p.Title, u.Location, t.TagName, pl.RelatedPostId
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
JOIN Posts related ON related.Id = pl.RelatedPostId
JOIN Tags t ON t.ExcerptPostId = related.Id
WHERE p.Title LIKE '%%'
  AND u.Location LIKE '%%'
  AND t.TagName LIKE '%%'
  AND pl.CreationDate >= '2013-02-27 09:34:00.107000'
  AND related.Score >= 1
  AND p.ViewCount > 33
  AND lt.Id IN (1, 3)
  AND t.Count > 694;
