SELECT p1.Title AS EditedPost, p2.Title AS OwnedPost, u1.DisplayName AS Editor, u2.DisplayName AS OriginalOwner
FROM Posts p1
JOIN Posts p2 ON p1.LastEditorUserId = p2.OwnerUserId AND p1.OwnerUserId <> p2.OwnerUserId
JOIN Users u1 ON p1.LastEditorUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
WHERE p1.Title LIKE '%%'
  AND p2.Title NOT LIKE ''%%''
  AND u1.DisplayName LIKE '%%'
  AND u2.Location LIKE '%%';
