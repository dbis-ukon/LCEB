SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Score > (SELECT AVG(Score) FROM Posts)
  AND p.ClosedDate IS NULL AND p.CreationDate >= '2013-08-22 09:58:28.773000';
