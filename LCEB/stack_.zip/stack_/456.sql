SELECT *
FROM Posts
WHERE Title LIKE '%function%'
AND Title LIKE '%JavaScript%'
  AND Title NOT LIKE '%async%'
  AND PostTypeId = 1;
