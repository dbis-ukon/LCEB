SELECT b.Name AS BadgeName, b.Class, u.DisplayName,
       u.Reputation, u.CreationDate
FROM Badges b
JOIN Users u ON u.Id = b.UserId
WHERE b.Name LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Class IN (3, 2)
  AND b.Date >= '2016-03-07 08:20:59.993000'
  AND u.Reputation > 215
  AND b.TagBased = FALSE
ORDER BY u.Reputation DESC;
