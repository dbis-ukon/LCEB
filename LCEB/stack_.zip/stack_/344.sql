SELECT
    t.TagName,
    p.Title,
    p.Score,
    p.AnswerCount
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
WHERE
    (t.TagName LIKE '%%' OR t.TagName LIKE '%%' OR t.TagName NOT LIKE ''%%'')
    AND (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND t.Count >= 60
    AND t.IsRequired = FALSE
    AND t.IsModeratorOnly = FALSE
    AND p.PostTypeId IN (2, 1)
    AND p.Score >= 1;
