SELECT p.Id, p.Title, u.DisplayName, v.VoteTypeId, v.CreationDate
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND v.VoteTypeId IN (3, 16, 2)
  AND v.CreationDate >= '2010-11-13 00:00:00'
  AND p.Score < 2
  AND p.ViewCount > 202
  AND p.PostTypeId = 1
ORDER BY v.CreationDate DESC;
