SELECT p.Id, p.Title, u.DisplayName, COUNT(v.Id) AS VoteCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Votes v ON v.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND v.VoteTypeId IN (2, 3, 10)
  AND v.CreationDate >= '2013-12-06 00:00:00'
  AND p.ClosedDate IS NULL
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(v.Id) > 5
ORDER BY VoteCount DESC;
