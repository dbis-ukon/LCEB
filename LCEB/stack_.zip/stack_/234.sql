SELECT p.Id, p.Title, u.DisplayName, u.Location, COUNT(b.Id) AS nice_answer_badges
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Name LIKE '%%'
  AND u.Reputation > 1
  AND p.Score > 0
GROUP BY p.Id, p.Title, u.DisplayName, u.Location;
