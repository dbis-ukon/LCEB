SELECT p.Id, p.Title, p.Score, p.ViewCount, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score >= 2
  AND p.ViewCount >= 322
  AND u.Reputation > 101;
