SELECT p.Id, p.Title, u.DisplayName,
       t.TagName, b.Name AS BadgeName,
       pl.CreationDate AS LinkDate,
       related.Title AS RelatedTitle,
       related.OwnerUserId AS RelatedOwnerId
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.WikiPostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN PostLinks pl ON pl.RelatedPostId = p.Id
JOIN Posts related ON related.Id = pl.PostId
JOIN Users relatedOwner ON relatedOwner.Id = related.OwnerUserId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Name LIKE '%%'
  AND related.Title LIKE '%%'
  AND relatedOwner.Location LIKE '%%'
  AND related.OwnerUserId <> p.OwnerUserId
  AND pl.CreationDate >= '2017-04-25 02:26:07.970000'
  AND p.Score > related.Score
ORDER BY pl.CreationDate DESC;
