SELECT p.Id, p.Title, u.DisplayName,
       t.TagName, b.Name AS BadgeName,
       pl.RelatedPostId, lt.Name AS LinkType
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.ExcerptPostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Name LIKE '%%'
  AND pl.RelatedPostId <> p.Id
  AND t.Count > 1758
  AND p.Score >= 0
ORDER BY pl.CreationDate DESC;
