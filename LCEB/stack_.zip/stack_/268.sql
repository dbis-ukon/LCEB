SELECT u.Location, b.Class, COUNT(*) AS BadgeCount, COUNT(DISTINCT u.Id) AS UniqueUsers
FROM Users u
JOIN Badges b ON b.UserId = u.Id
WHERE u.Location LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND b.Name NOT LIKE ''%%''
  AND b.Class IN (3)
  AND u.Reputation > 101
  AND b.Date >= '2019-05-10 16:55:25.517000'
GROUP BY u.Location, b.Class
HAVING COUNT(*) > 5
ORDER BY BadgeCount DESC;
