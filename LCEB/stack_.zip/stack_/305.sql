SELECT p1.Title AS PostA, p2.Title AS PostB, t1.TagName AS TagA, t2.TagName AS TagB, u1.DisplayName, u2.DisplayName
FROM Posts p1
JOIN Posts p2 ON p1.OwnerUserId = p2.OwnerUserId AND p1.Id <> p2.Id
CROSS JOIN Tags t1
JOIN Tags t2 ON t2.ExcerptPostId = p2.Id
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
WHERE p1.Tags LIKE '%%' AND t1.TagName LIKE '%%' AND p1.Title LIKE '%%'
  AND t1.TagName LIKE '%%'
  AND (t2.TagName LIKE '%%' OR t2.TagName NOT LIKE ''%%'');
