SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Score > 10 AND p.ViewCount > 103
  AND EXISTS (
      SELECT 1 FROM Badges b WHERE b.UserId = u.Id AND b.Name LIKE '%%'
  );
