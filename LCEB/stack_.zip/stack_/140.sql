SELECT a.Id, a.TagName
FROM Tags a
WHERE (a.TagName LIKE '%%' OR a.TagName LIKE '%%') AND a.TagName NOT LIKE ''%%''
  AND WikiPostId IS NOT NULL AND Id > 0 AND Count <> 0 AND Count BETWEEN 1 AND 50000 AND Count IN (10, 50, 100, 500)
  AND NOT EXISTS (SELECT 1 FROM Tags b WHERE b.IsModeratorOnly = a.IsModeratorOnly AND b.TagName LIKE '%%');
