SELECT u.Id, u.DisplayName, p.Title, b.Name AS BadgeName
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND p.Score > 2;
