SELECT p.Id, p.Title, u.DisplayName, c.Text
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%';
