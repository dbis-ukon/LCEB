SELECT
    p.Id,
    p.Title,
    pl.RelatedPostId,
    rp.Title AS RelatedTitle
FROM Posts p
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN Posts rp ON rp.Id = pl.RelatedPostId
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (rp.Title LIKE '%%' OR rp.Title LIKE '%%' OR rp.Title NOT LIKE ''%%'')
    AND pl.LinkTypeId IN (1, 3)
    AND p.PostTypeId = 1
    AND p.Score >= 2
    AND rp.Score >= 2
    AND p.Id <> rp.Id;
