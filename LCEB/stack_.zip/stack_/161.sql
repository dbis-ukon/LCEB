SELECT b.Name, COUNT(*) AS times_awarded, COUNT(DISTINCT b.UserId) AS unique_recipients,
       MIN(b.Date) AS first_awarded, MAX(b.Date) AS last_awarded
FROM Badges b
WHERE b.Name LIKE '%%'
  AND b.TagBased = false
GROUP BY b.Name
HAVING COUNT(*) > 100
ORDER BY times_awarded DESC;
