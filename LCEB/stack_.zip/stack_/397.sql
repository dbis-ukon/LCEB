SELECT Id, Name, Class,
       Class - LAG(Class) OVER (ORDER BY Id) AS DeltaFromPrev
FROM Badges
WHERE (Class = 3 OR Name LIKE '%Editor%') AND UserId > 100 AND UserId < 9000000;
