SELECT p.Id, p.Title, u.DisplayName, COUNT(v.Id) AS vote_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Tags t ON t.ExcerptPostId = p.Id
WHERE p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.TagName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND v.VoteTypeId = 2
  AND u.WebsiteUrl IS NOT NULL
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(v.Id) > 5;
