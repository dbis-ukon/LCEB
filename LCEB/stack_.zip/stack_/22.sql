SELECT b.Name, COUNT(*) AS award_count
FROM Badges b
WHERE b.Name LIKE '%%'
  AND b.TagBased = false
GROUP BY b.Name
HAVING COUNT(*) > 20
ORDER BY award_count DESC;
