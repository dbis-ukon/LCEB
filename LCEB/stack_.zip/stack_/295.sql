SELECT b.Class, AVG(EXTRACT(YEAR FROM b.Date)) AS avg_year, COUNT(*) AS cnt
FROM Badges b
WHERE b.Name LIKE '%%'
GROUP BY b.Class;
