SELECT p.Id, p.Title
FROM Posts p
WHERE p.Title LIKE '%%' AND p.Title LIKE '%%' AND p.Title LIKE '%%'
  AND p.ViewCount > (SELECT AVG(ViewCount) FROM Posts WHERE PostTypeId = 1);
