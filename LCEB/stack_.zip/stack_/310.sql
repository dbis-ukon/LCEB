SELECT Id, Name FROM Badges WHERE Name LIKE 'Student' AND Class IN (1, 2, 3, 5, 8) AND Date <= '2023-12-31' AND TagBased = false AND Id > 0 AND Id < 5000000 AND UserId <> 0;
