SELECT Id, Name, Class FROM Badges WHERE (Name LIKE '%Nice%' OR Name LIKE '%Answer%') AND TagBased = false AND Id > 0 AND Class > (SELECT AVG(Class) FROM Badges);
