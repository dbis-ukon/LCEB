SELECT b.Id, b.Name, u.Location, p.Title
FROM Badges b
JOIN Users u ON u.Id = b.UserId
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE b.Name NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.Score >= 3
  AND u.Views > 2
  AND u.CreationDate >= '2017-06-13 11:12:32.460000'
  AND p.ViewCount BETWEEN 39 AND 325
  AND p.AnswerCount >= 1
  AND b.TagBased = false;
