SELECT c.Id, c.Text, p.Title
FROM Comments c
JOIN Posts p ON p.Id = c.PostId
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND c.Score >= 0
  AND c.UserId IN (264121, 677852, 6312, 82961, 1100430)
ORDER BY c.Score DESC;
