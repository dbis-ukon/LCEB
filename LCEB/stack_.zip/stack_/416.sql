SELECT u.Id, u.DisplayName, u.Location, b.Name AS BadgeName,
       COUNT(DISTINCT p.Id) AS post_count,
       COUNT(DISTINCT c.Id) AS comment_count
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.CreationDate >= '2014-05-03 15:44:39.760000'
  AND c.CreationDate >= '2020-07-23 14:55:29.077000'
  AND b.Class IN (2, 3)
  AND pt.Id IN (8, 1, 7, 3, 2)
GROUP BY u.Id, u.DisplayName, u.Location, b.Name
HAVING COUNT(DISTINCT p.Id) > 1
   AND COUNT(DISTINCT c.Id) > 2;
