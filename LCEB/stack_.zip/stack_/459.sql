SELECT t.Id, t.TagName, p.Title, u.Location, pt.Name
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE t.TagName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND pt.Id IN (2, 4, 3, 8, 5);
