SELECT p.Title, ph1.CreationDate AS TitleEditDate, ph2.CreationDate AS BodyEditDate
FROM PostHistory ph1
JOIN PostHistory ph2 ON ph1.PostId = ph2.PostId AND ph1.PostHistoryTypeId = 4 AND ph2.PostHistoryTypeId = 5
JOIN Posts p ON p.Id = ph1.PostId
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND ph1.CreationDate < ph2.CreationDate
  AND p.Score >= 1
  AND p.ViewCount > 54
  AND p.AnswerCount >= 2
ORDER BY ph2.CreationDate DESC;
