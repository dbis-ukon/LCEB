SELECT Id, TagName, Id
FROM Tags
WHERE (TagName LIKE '%orm%' OR TagName LIKE '%rest%')
  AND Count > 10
  AND Count < 50000
  AND IsModeratorOnly IS NOT TRUE
  AND Id >= (SELECT MIN(Id) FROM Tags);
