SELECT v.PostId, COUNT(v.Id) AS vote_count,
       SUM(COALESCE(v.BountyAmount, 0)) AS total_bounty
FROM Votes v
JOIN Posts p ON p.Id = v.PostId
WHERE p.Title LIKE '%%'
  AND v.CreationDate >= '2013-04-27 00:00:00'
  AND v.VoteTypeId IN (10, 1, 2)
GROUP BY v.PostId
HAVING COUNT(v.Id) >= 3
ORDER BY vote_count DESC;
