SELECT t.TagName, t.Count, p.Title, pt.Name AS PostType
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE t.TagName LIKE '%%'
  AND pt.Name LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND t.TagName LIKE '%%'
  AND t.Count < 119;
