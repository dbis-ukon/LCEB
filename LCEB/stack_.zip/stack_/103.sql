SELECT Id, TagName
FROM Tags
WHERE (TagName LIKE '%devops%' OR TagName LIKE '%%')
  AND TagName NOT LIKE '%deprecated%'
  AND Count <> 0
  AND Count BETWEEN 1 AND 50000
  AND Count IN (10, 50, 100, 500)
  AND IsRequired IS NOT TRUE
  AND Id BETWEEN 1 AND 999999
EXCEPT ALL
SELECT Id, TagName
FROM Tags
WHERE TagName LIKE '%web%';
