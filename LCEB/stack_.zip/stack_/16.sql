SELECT u.DisplayName, b1.Name AS GoldBadge, b2.Name AS SilverBadge
FROM Badges b1
JOIN Badges b2 ON b1.UserId = b2.UserId AND b1.Class = 1 AND b2.Class = 2
JOIN Users u ON b1.UserId = u.Id
WHERE b1.Name LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.AccountId IS NOT NULL AND u.WebsiteUrl IS NOT NULL;
