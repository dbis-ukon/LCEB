SELECT u.Id, u.DisplayName, u.Location, b.Name AS BadgeName
FROM Users u
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Class <= 3
ORDER BY b.Date DESC;
