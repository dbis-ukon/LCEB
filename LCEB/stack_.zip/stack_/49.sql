SELECT p.Id, p.Title, u.DisplayName, pl.RelatedPostId
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostLinks pl ON pl.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND pl.CreationDate >= '2020-12-06 01:28:43.543000'
  AND pl.RelatedPostId <> pl.PostId
  AND p.ParentId IS NULL
  AND p.Score >= 6
ORDER BY pl.CreationDate DESC;
