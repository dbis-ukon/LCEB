SELECT b.Name, u.DisplayName, p.Title
FROM Badges b
JOIN Users u ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE b.Name NOT LIKE ''%%'' and u.Location LIKE '%%'
  AND p.Score < 2
LIMIT 20;
