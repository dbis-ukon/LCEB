SELECT UserId, AVG(Class) AS AvgVal, MAX(Class) AS MaxVal FROM Badges WHERE Name LIKE '%Investor%' AND UserId BETWEEN 1 AND 9999999 GROUP BY UserId HAVING AVG(Class) >= 0 ORDER BY AvgVal DESC;
