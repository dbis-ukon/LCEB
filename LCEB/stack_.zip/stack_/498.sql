SELECT u.Id, u.DisplayName, u.Location, u.Reputation, u.Views
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND u.Reputation BETWEEN 1 AND 1
  AND u.Views > -1
  AND u.UpVotes > -1
  AND u.AccountId IS NOT NULL
  AND u.CreationDate >= '2014-02-24 05:10:13.620000'
ORDER BY u.Reputation DESC;
