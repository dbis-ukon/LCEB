SELECT p.Title, pht.Name AS ChangeType, u.DisplayName AS Editor
FROM PostHistory ph
JOIN PostHistoryTypes pht ON pht.Id = ph.PostHistoryTypeId
JOIN Posts p ON p.Id = ph.PostId
JOIN Users u ON u.Id = ph.UserId
WHERE p.Title LIKE '%%'
  AND pht.Name LIKE '%%'
  AND u.Reputation > 1 AND u.Views > 0;
