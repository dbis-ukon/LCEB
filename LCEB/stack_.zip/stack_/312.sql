SELECT u.DisplayName, p.Title
FROM Comments c
JOIN Posts p ON p.Id = c.PostId
JOIN Users u ON c.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%';
