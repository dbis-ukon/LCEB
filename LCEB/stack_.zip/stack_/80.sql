SELECT p.Id, p.Title, u.DisplayName, COUNT(v.Id) AS vote_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND v.CreationDate >= '2020-08-14 00:00:00' AND u.LastAccessDate >= '2016-07-22 12:03:51.920000' AND u.Reputation BETWEEN 1 AND 1
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(v.Id) > 1;
