SELECT Location, AVG(Reputation) AS AvgVal, MAX(Reputation) AS MaxVal FROM Users WHERE DisplayName LIKE '%lead%' AND Id > 0 GROUP BY Location HAVING AVG(Reputation) >= 0 ORDER BY AvgVal DESC;
