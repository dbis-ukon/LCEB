SELECT p.Title, vt.Name AS VoteType, v.BountyAmount, COUNT(*) AS cnt
FROM Votes v
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
JOIN Posts p ON p.Id = v.PostId
WHERE p.Title LIKE '%%'
  AND vt.Name LIKE '%%'
  AND v.BountyAmount > 100
  AND v.CreationDate >= '2016-09-17 00:00:00'
GROUP BY p.Title, vt.Name, v.BountyAmount;
