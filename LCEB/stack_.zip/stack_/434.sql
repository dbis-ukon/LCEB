SELECT u.Id, u.DisplayName, u.Location,
       (SELECT COUNT(*) FROM Posts p WHERE p.OwnerUserId = u.Id) AS total_posts
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND u.DownVotes < 0 AND u.AccountId IS NOT NULL;
