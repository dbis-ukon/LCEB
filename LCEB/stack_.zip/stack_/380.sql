SELECT t.TagName, t.Count
FROM Tags t
WHERE t.TagName LIKE '%%'
  AND t.TagName NOT LIKE ''%%''
  AND t.Count > 131;
