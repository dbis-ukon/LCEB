SELECT p.Id, p.Title, p.OwnerDisplayName, p.ContentLicense
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.OwnerDisplayName LIKE '%%'
  AND p.CommunityOwnedDate IS NOT NULL
  AND p.PostTypeId = 1;
