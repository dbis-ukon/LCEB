SELECT u.Id, u.DisplayName, u.Location, p.Title, b.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND b.Name LIKE '%%';
