SELECT b.Name, u.DisplayName
FROM Badges b
JOIN Users u ON b.UserId = u.Id
WHERE b.Name NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND b.Class = 3
  AND u.Reputation > 1;
