SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (u.DisplayName LIKE '%%' OR u.Location LIKE '%%')
  AND p.ViewCount > 77
  AND u.Reputation > 1
  AND EXISTS (
    SELECT 1 FROM Comments c WHERE c.PostId = p.Id
  )
ORDER BY p.Score DESC;
