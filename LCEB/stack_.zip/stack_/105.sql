SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.LastEditorUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND p.LastEditDate >= '2017-04-13 12:19:45.503000';
