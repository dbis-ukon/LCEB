SELECT p.Title, u.DisplayName, u.Location
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE (u.DisplayName LIKE '%%' OR u.Location LIKE '%%')
  AND u.AccountId IS NOT NULL
  AND p.ViewCount > 94
ORDER BY p.Score DESC;
