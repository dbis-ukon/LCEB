SELECT p.Id, p.Title, p.Score, p.ViewCount
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE (u.DisplayName LIKE '%%' OR u.Location LIKE '%%')
  AND p.Score > -1
  AND p.PostTypeId = 1
ORDER BY p.Score DESC;
