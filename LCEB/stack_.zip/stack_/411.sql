SELECT sub.Id, sub.TagName, sub.Count
FROM (
    SELECT Id, TagName, Count, ROW_NUMBER() OVER (ORDER BY Count DESC) AS rk
    FROM Tags
    WHERE (TagName LIKE '%devops%' OR TagName LIKE '%%') AND IsRequired IS NOT TRUE AND ExcerptPostId IS NOT NULL
) sub
WHERE sub.rk <= 10;
