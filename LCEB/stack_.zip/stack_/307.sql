SELECT Id, DisplayName
FROM Users
WHERE (DisplayName LIKE '%engineer%' OR DisplayName LIKE '%John%') AND DisplayName NOT LIKE '%Smith'
  AND Id > 0 AND Reputation BETWEEN 50 AND 100000 AND Views BETWEEN 1 AND 1000000 AND UpVotes BETWEEN 0 AND 5000 AND DownVotes BETWEEN 0 AND 500
  AND Id IN (SELECT Id FROM Users WHERE Reputation > 0 ORDER BY Reputation DESC LIMIT 100);
