SELECT
    b.Name,
    u.DisplayName,
    u.Reputation,
    b.Date
FROM Badges b
JOIN Users u ON u.Id = b.UserId
WHERE
    (b.Name LIKE '%%' OR b.Name LIKE '%%' OR b.Name NOT LIKE ''%%'')
    AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND b.Class = 2
    AND b.TagBased = FALSE
    AND u.Reputation >= 1
    AND b.Date >= '2015-08-28 16:01:56.560000';
