SELECT p1.Title AS SourceTitle, p2.Title AS LinkedTitle, u1.DisplayName AS SourceOwner, u2.DisplayName AS LinkedOwner
FROM Posts p1
JOIN PostLinks pl ON pl.PostId = p1.Id AND pl.LinkTypeId = 1
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
WHERE p1.Title LIKE '%%'
  AND u1.DisplayName NOT LIKE ''%%''
  AND u2.DisplayName LIKE '%%'
  AND u2.Location LIKE '%%'
  AND p1.Score > 1
  AND p2.Score > 0
  AND pl.CreationDate >= '2015-01-26 00:04:06.193000'
  AND p1.PostTypeId = 1
  AND p2.PostTypeId = 1
ORDER BY pl.CreationDate DESC;
