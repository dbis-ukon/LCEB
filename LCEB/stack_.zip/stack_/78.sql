SELECT Id, TagName, Count,
       Count - LAG(Count) OVER (ORDER BY Id) AS DeltaFromPrev
FROM Tags
WHERE (TagName LIKE 'python' OR TagName LIKE '%framework%') AND Id > 0 AND Count <> 0;
