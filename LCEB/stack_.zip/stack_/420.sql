SELECT u.Id, u.Location, p.Title, b.Name, v.VoteTypeId, ph.CreationDate
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE u.Location NOT LIKE ''%%''
  AND p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND v.VoteTypeId IN (16, 1, 3, 10, 2)
  AND ph.CreationDate > p.CreationDate;
