SELECT
    u.DisplayName,
    u.Location,
    p.Title,
    p.Score
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE
    (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND (u.Location LIKE '%%' OR u.Location LIKE '%%' OR u.Location NOT LIKE ''%%'')
    AND (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND u.Location IS NOT NULL
    AND u.Reputation >= 11
    AND p.Score >= 2
    AND p.PostTypeId = 1;
