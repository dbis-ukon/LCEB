SELECT Id, TagName, Count
FROM Tags
WHERE TagName NOT LIKE '%old%'
  AND (TagName LIKE '%python%' OR TagName LIKE '%ruby%')
  AND Count > 75;
