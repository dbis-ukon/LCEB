SELECT t.TagName, t.Count, p.Title,
       u.DisplayName, b.Name AS BadgeName
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE t.TagName LIKE '%%'
  AND p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.Count > 219
  AND u.Reputation >= 1
ORDER BY t.Count DESC;
