SELECT t.Id, t.TagName, p.Title, u.DisplayName
FROM Tags t
JOIN Posts p ON p.Id = t.WikiPostId
JOIN Users u ON u.Id = p.OwnerUserId
WHERE t.TagName NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND p.Score >= 0;
