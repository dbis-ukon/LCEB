SELECT p.Id, p.Title, u.DisplayName, p.CreationDate
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.CreationDate BETWEEN '2019-01-01' AND '2023-12-31'
  AND p.PostTypeId IN (1, 2)
  AND p.Score BETWEEN 0 AND 2
  AND u.Reputation > 1
  AND p.ViewCount > 1630
ORDER BY p.CreationDate DESC;
