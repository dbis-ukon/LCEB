SELECT *
FROM Tags
WHERE (TagName LIKE 'c%' OR TagName LIKE 'c++%')
  AND IsRequired = true;
