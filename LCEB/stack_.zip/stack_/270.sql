SELECT
    Id,
    TagName
FROM Tags
WHERE (TagName LIKE '%orm%' OR TagName LIKE '%rest%')
  AND TagName NOT LIKE '%security%'
  AND LENGTH(TagName) BETWEEN 3 AND 60
  AND Count BETWEEN 1 AND 50000
  AND Count IN (10, 50, 100, 500)
  AND IsRequired IS NOT TRUE
  AND Id BETWEEN 1 AND 999999
  AND Count > 10;
