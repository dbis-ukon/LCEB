SELECT u.Id, u.DisplayName, p.Title, b.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND u.Reputation >= 21
  AND u.Views > 0
  AND u.UpVotes >= 16
  AND p.ViewCount BETWEEN 25 AND 60
  AND b.Date >= '2023-12-19 16:32:25.223000';
