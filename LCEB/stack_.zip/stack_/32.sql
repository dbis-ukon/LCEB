SELECT p.Id, p.Title, p.Score, p.ViewCount, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.location LIKE '%%'
  AND p.PostTypeId = 1
  AND p.ClosedDate IS NULL
  AND u.LastAccessDate >= '2022-09-21 09:19:34.267000'
ORDER BY p.ViewCount DESC
LIMIT 25;
