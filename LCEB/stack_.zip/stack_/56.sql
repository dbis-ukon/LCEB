SELECT
    u.DisplayName,
    p.Title,
    ph.CreationDate,
    ph.Comment
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE
    (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
    AND (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (ph.Comment LIKE '%%' OR ph.Comment LIKE '%%' OR ph.Comment NOT LIKE ''%%'')
    AND p.PostTypeId = 1
    AND ph.PostHistoryTypeId IN (2, 5, 1, 4, 24)
    AND ph.CreationDate >= '2011-04-21 21:06:12.213000'
    AND u.Reputation >= 71;
