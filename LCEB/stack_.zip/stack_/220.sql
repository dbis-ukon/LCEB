SELECT p.Id, p.Title, pl.RelatedPostId, ph.Comment
FROM Posts p
JOIN PostLinks pl ON pl.RelatedPostId = p.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
  AND (ph.Comment LIKE '%%' OR ph.Comment LIKE '%%' OR ph.Comment NOT LIKE ''%%'')
  AND p.PostTypeId = 1
  AND pl.LinkTypeId = 1
  AND ph.PostHistoryTypeId IN (5, 2, 1, 3)
  AND p.Score >= 2;
