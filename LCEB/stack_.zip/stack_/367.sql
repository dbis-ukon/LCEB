SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.OwnerUserId IN (441439, 66212, 140475, 49053, 248602)
  AND EXISTS (
      SELECT 1 FROM Votes v WHERE v.PostId = p.Id AND v.VoteTypeId = 2
  )
ORDER BY p.Score DESC;
