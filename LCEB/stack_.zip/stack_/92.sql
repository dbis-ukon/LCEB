SELECT p.Id, p.Title, u.DisplayName, p.Score
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title NOT LIKE ''%%'' OR u.DisplayName LIKE '%%')
  AND (u.Location LIKE '%%')
  AND p.Score > 1
  AND p.PostTypeId = 2
ORDER BY p.CreationDate DESC;
