SELECT p.Id, p.Title, u.DisplayName, COUNT(v.Id) AS vote_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Tags t ON t.ExcerptPostId = p.Id
WHERE t.TagName NOT LIKE ''%%'' AND u.Location LIKE '%%' AND b.Name NOT LIKE ''%%'' AND u.DisplayName LIKE '%%'
  AND v.BountyAmount IS NOT NULL
  AND u.Reputation > 101
  AND u.Views > 0
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(v.Id) > 0;
