SELECT u.DisplayName, p.Title, c.Text, v.VoteTypeId
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND c.Score >= 3
  AND v.VoteTypeId IN (3, 2, 1);
