SELECT Location, COUNT(*) AS Cnt
FROM Users
WHERE (DisplayName LIKE '%senior%' OR DisplayName LIKE '%admin%') AND DisplayName NOT LIKE 'A%'
GROUP BY Location
HAVING COUNT(*) > (SELECT AVG(sub.cnt) FROM (SELECT COUNT(*) AS cnt FROM Users WHERE DisplayName LIKE '%admin%' GROUP BY Location) sub);
