SELECT p.Id, p.Title, u.DisplayName, p.Score, p.AnswerCount
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND p.Score > 3
  AND p.AnswerCount >= 1
  AND p.ClosedDate IS NULL;
