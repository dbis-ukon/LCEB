SELECT v.Id, v.VoteTypeId, p.Title
FROM Votes v
JOIN Posts p ON p.Id = v.PostId
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND v.VoteTypeId = 15
  AND v.PostId NOT IN (3144792, 3321380, 858371, 380177, 2579355)
ORDER BY v.CreationDate DESC;
