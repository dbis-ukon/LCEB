SELECT Id, TagName, Count
FROM Tags
WHERE (TagName LIKE '%testing%' OR TagName LIKE '%test%' OR TagName LIKE '%unit%')
  AND TagName NOT LIKE '%deprecated%'
  AND Count BETWEEN 10 AND 50000
  AND Count <> 500
  AND IsRequired IS NOT TRUE
  AND WikiPostId IS NOT NULL
  AND Id > 0
ORDER BY Count ASC;
