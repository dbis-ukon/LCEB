SELECT p.Id, p.Title, u.DisplayName AS LastEditor, p.LastEditDate
FROM Posts p
JOIN Users u ON p.LastEditorUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.LastEditDate >= '2013-12-16 17:16:41.613000'
  AND p.LastActivityDate >= '2020-05-22 00:47:19.107000'
  AND p.Score >= 0
  AND u.Reputation > 1
  AND p.AnswerCount >= 3
ORDER BY p.LastEditDate DESC;
