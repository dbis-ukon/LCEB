SELECT b.Id, b.Name
FROM Badges b
WHERE b.Name LIKE '%%'
  AND EXISTS (
      SELECT 1 FROM Users u WHERE u.Id = b.UserId AND u.DisplayName NOT LIKE ''%%''
        AND EXISTS (
            SELECT 1 FROM Posts p WHERE p.OwnerUserId = u.Id AND p.Title LIKE '%%'
              AND EXISTS (
                  SELECT 1 FROM Votes v WHERE v.PostId = p.Id AND v.VoteTypeId = 3
              )
        )
  );
