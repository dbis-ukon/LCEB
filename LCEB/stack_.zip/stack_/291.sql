SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND p.AnswerCount > 2
  AND p.Score >= 4;
