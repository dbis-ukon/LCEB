SELECT p.Title, u1.DisplayName AS Owner, u2.DisplayName AS Voter, b.Name AS VoterBadge
FROM Posts p
JOIN Users u1 ON p.OwnerUserId = u1.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Users u2 ON v.UserId = u2.Id
JOIN Badges b ON b.UserId = u2.Id
WHERE p.Title LIKE '%%'
  AND b.Name LIKE '%%';
