SELECT p.Id, p.Title, u.DisplayName, b.Name, ph.PostHistoryTypeId
FROM Posts p
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN Users u ON ph.UserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND ph.PostHistoryTypeId = 6
  AND b.Class <= 2
  AND ph.CreationDate >= '2024-04-14 19:12:28.690000'
  AND p.Score >= 3
  AND u.Reputation > 1
ORDER BY ph.CreationDate DESC;
