SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND p.Score > -1
  AND p.PostTypeId = 1
  AND p.ViewCount > 74
  AND EXISTS (
      SELECT 1 FROM Comments c WHERE c.PostId = p.Id AND c.UserId = u.Id
  )
ORDER BY p.Score DESC;
