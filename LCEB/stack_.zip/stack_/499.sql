SELECT u.Id, u.DisplayName, MAX(p.CreationDate) AS last_post
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND p.PostTypeId IN (2, 1)
GROUP BY u.Id, u.DisplayName
HAVING MAX(p.CreationDate) >= '2023-01-01';
