SELECT p.Id, p.Title, u.DisplayName,
       editor.DisplayName AS EditorName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Users editor ON editor.Id = p.LastEditorUserId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND editor.DisplayName LIKE '%%'
  AND p.LastEditDate >= '2017-06-19 23:41:22.607000'
  AND p.LastEditorUserId <> p.OwnerUserId
  AND p.Score > 5
  AND u.Reputation > 1
ORDER BY p.LastEditDate DESC;
