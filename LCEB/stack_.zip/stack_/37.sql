SELECT p.Id, p.Title, pt.Name AS PostType
FROM Posts p
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND pt.Name LIKE '%%'
  AND p.ParentId IS NULL AND p.ViewCount BETWEEN 122 AND 5822;
