SELECT p.Id, p.Title, u.DisplayName, COUNT(c.Id) AS comment_count,
       AVG(c.Score) AS avg_comment_score
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND u.Reputation >= 21
  AND c.CreationDate >= '2016-10-22 16:36:54.010000'
  AND p.AnswerCount >= 1
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(c.Id) >= 2
ORDER BY comment_count DESC;
