SELECT p.Id, p.Title, u.DisplayName, b.Name AS badge_name, b.Class
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND b.Name NOT LIKE ''%%''
  AND b.Class = 3
  AND b.Class <= 3
  AND p.Score > 2
  AND u.Reputation > 1
ORDER BY b.Date DESC;
