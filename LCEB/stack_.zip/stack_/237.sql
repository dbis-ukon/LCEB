SELECT p1.Id AS PostId, p1.Title AS PostTitle,
       p2.Id AS RelatedPostId, p2.Title AS RelatedTitle,
       u.DisplayName, lt.Name AS LinkType
FROM PostLinks pl
JOIN Posts p1 ON p1.Id = pl.PostId
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
JOIN Users u ON u.Id = p1.OwnerUserId
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
WHERE p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND u.Reputation >= 101
  AND pl.CreationDate >= '2013-04-09 05:02:49.253000'
  AND pl.PostId <> pl.RelatedPostId
ORDER BY pl.CreationDate DESC;
