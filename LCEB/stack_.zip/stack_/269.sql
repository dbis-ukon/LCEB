SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Score > (SELECT AVG(Score) FROM Posts)
  AND p.ParentId IS NULL AND p.ViewCount BETWEEN 49 AND 3037;
