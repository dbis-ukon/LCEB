SELECT *
FROM Tags
WHERE TagName NOT LIKE '%test%'
  AND Count >= 50;
