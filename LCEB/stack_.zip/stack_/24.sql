SELECT b.Id, b.Name, u.Location, p.Title
FROM Badges b
JOIN Users u ON u.Id = b.UserId
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE b.Name NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND p.Title LIKE '%%';
