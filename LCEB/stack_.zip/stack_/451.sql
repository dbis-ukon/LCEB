SELECT u.Id, u.DisplayName, p.Title, b.Name, ph.CreationDate
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN PostHistory ph ON ph.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND p.Title LIKE '%%'
  AND b.Name NOT LIKE ''%%''
  AND ph.CreationDate > p.CreationDate
  AND p.Score >= 0;
