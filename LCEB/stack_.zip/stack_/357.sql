SELECT t.TagName, t.Count
FROM Tags t
WHERE t.TagName LIKE '%%'
  AND t.Count > 28
  AND t.IsModeratorOnly IS NOT TRUE;
