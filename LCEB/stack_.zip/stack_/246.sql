SELECT Id, TagName
FROM Tags
WHERE (TagName LIKE '%devops%' OR TagName LIKE '%%')
  AND TagName NOT LIKE '%deprecated%'
  AND IsRequired IS NOT TRUE
  AND ExcerptPostId IS NOT NULL
  AND WikiPostId IS NOT NULL
  AND Id > 0
  AND Count <> 0
ORDER BY Id
LIMIT ALL
OFFSET 30;
