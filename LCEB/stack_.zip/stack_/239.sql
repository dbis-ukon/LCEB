SELECT p.Title, pt.Name AS PostType, u.DisplayName, b.Name AS BadgeName, b.Date AS BadgeDate
FROM Posts p
JOIN PostTypes pt ON pt.Id = p.PostTypeId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE (pt.Name LIKE '%%' OR u.Location LIKE '%%')
  AND p.Title LIKE '%%'
  AND b.Class = 3
  AND b.Date >= '2019-05-10 15:50:37.757000'
  AND u.Views > 0;
