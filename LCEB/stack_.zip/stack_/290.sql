SELECT u.DisplayName, p1.Title AS PostA, p2.Title AS PostB, c1.Text AS CommentA, c2.Text AS CommentB
FROM Posts p1
JOIN Posts p2 ON p1.OwnerUserId = p2.OwnerUserId AND p1.Id <> p2.Id
JOIN Users u ON p1.OwnerUserId = u.Id
JOIN Comments c1 ON c1.PostId = p1.Id
JOIN Comments c2 ON c2.PostId = p2.Id
WHERE (p1.Title LIKE '%%' OR p1.Title LIKE '%%') AND p2.Title LIKE '%%' AND u.DisplayName NOT LIKE ''%%'';
