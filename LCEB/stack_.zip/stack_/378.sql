SELECT p.Id, p.Title
FROM Posts p
WHERE p.Title LIKE '%%'
  AND NOT EXISTS (
      SELECT 1 FROM Users u WHERE u.Id = p.OwnerUserId AND u.DisplayName LIKE '%%'
  )
  AND EXISTS (
      SELECT 1 FROM Comments c WHERE c.PostId = p.Id
        AND EXISTS (
            SELECT 1 FROM Users cu WHERE cu.Id = c.UserId AND cu.DisplayName LIKE '%%'
        )
  );
