SELECT
    p.Id,
    p.Title,
    p.Score,
    p.ViewCount,
    u.DisplayName,
    u.Location
FROM Posts p
JOIN Users u
    ON p.OwnerUserId = u.Id
WHERE (
        p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title LIKE '%%'
        OR p.Title NOT LIKE ''%%''
      )
  AND (
        u.DisplayName LIKE '%%'
        OR u.DisplayName LIKE '%%'
        OR u.DisplayName NOT LIKE ''%%''
      )
  AND (
        u.Location LIKE '%%'
        OR u.Location LIKE '%%'
        OR u.Location NOT LIKE ''%%''
      )
  AND p.PostTypeId = 2
  AND p.Score > -1
  AND p.ViewCount >= 5754
  AND p.FavoriteCount > 0
  AND u.Reputation >= 1
  AND u.LastAccessDate >= '2022-10-18 10:08:13.653000'
ORDER BY p.ViewCount DESC
LIMIT 25;
