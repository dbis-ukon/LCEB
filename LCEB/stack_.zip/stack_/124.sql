SELECT *
FROM Users
WHERE Location LIKE '%California%'
  AND DisplayName LIKE '%John%'
  AND Location NOT LIKE '%Los Angeles%'
   AND DisplayName LIKE '%John%'
  AND Location NOT LIKE '%Los Angeles%'
  AND Reputation > 1000
  AND Views > 100;
