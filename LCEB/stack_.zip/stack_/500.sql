SELECT u.Id, u.DisplayName, u.Location, u.Reputation, u.UpVotes
FROM Users u
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND u.Reputation BETWEEN 1 AND 1
  AND u.UpVotes > -1
  AND u.DownVotes < 2
  AND u.CreationDate >= '2018-04-08 14:11:54.093000'
ORDER BY u.Reputation DESC;
