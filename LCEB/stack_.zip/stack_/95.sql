SELECT u.DisplayName, p.Title, ph.CreationDate, pt.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN PostHistory ph ON ph.PostId = p.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND ph.CreationDate >= TIMESTAMP '2020-01-01'
  AND pt.Id = 1;
