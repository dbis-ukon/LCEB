SELECT p.Id AS ItemId, 'Post' AS SourceType, p.Title AS MatchedText
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.ViewCount > 485 AND p.AnswerCount >= 0
UNION
SELECT c.Id AS ItemId, 'Comment' AS SourceType, u.DisplayName AS MatchedText
FROM Comments c
JOIN Users u ON u.Id = c.UserId
WHERE u.DisplayName LIKE '%%';
