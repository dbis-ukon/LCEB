SELECT u.Id, u.DisplayName, u.Location,
       p.Title, b.Name AS BadgeName,
       t.TagName, COUNT(DISTINCT v.Id) AS VoteCount,
       COUNT(DISTINCT c.Id) AS CommentCount
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Tags t ON t.WikiPostId = p.Id
LEFT JOIN Votes v ON v.PostId = p.Id
LEFT JOIN Comments c ON c.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Title LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.TagName LIKE '%%'
  AND u.Reputation >= 101
  AND p.CreationDate >= '2019-09-16 10:54:00.150000'
  AND t.IsRequired IS NOT TRUE
GROUP BY u.Id, u.DisplayName, u.Location, p.Id,
         p.Title, b.Name, t.TagName
HAVING COUNT(DISTINCT v.Id) >= 1
   AND COUNT(DISTINCT c.Id) >= 1
ORDER BY VoteCount DESC, CommentCount DESC;
