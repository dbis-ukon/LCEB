SELECT u.DisplayName, COUNT(*) AS matching_posts
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
  AND EXISTS (SELECT 1 FROM Badges b WHERE b.UserId = u.Id)
GROUP BY u.DisplayName;
