SELECT p.Title, pht.Name AS Action, crt.Name AS Reason
FROM PostHistory ph
JOIN PostHistoryTypes pht ON pht.Id = ph.PostHistoryTypeId
JOIN CloseReasonTypes crt ON crt.Id = CAST(ph.Comment AS integer)
JOIN Posts p ON p.Id = ph.PostId
WHERE ph.PostHistoryTypeId = 1
  AND (crt.Name LIKE '%%' OR crt.Name LIKE '%%')
  AND p.Title NOT LIKE ''%%''
  AND p.AnswerCount = 2
  AND p.CommentCount > 9;
