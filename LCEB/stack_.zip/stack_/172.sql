SELECT Id, DisplayName
FROM Users
WHERE (DisplayName LIKE '%John%' OR DisplayName LIKE '%Smith') AND DisplayName NOT LIKE '%senior%'
  AND Reputation BETWEEN 50 AND 100000 AND Views BETWEEN 1 AND 1000000 AND UpVotes BETWEEN 0 AND 5000 AND DownVotes BETWEEN 0 AND 500 AND Reputation IN (100, 500, 1000, 5000)
  AND Id NOT IN (SELECT Id FROM Users WHERE Reputation < 0);
