SELECT p.Id, p.Title, u.DisplayName, u.Location
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Score > 1
  AND u.Reputation > 21;
