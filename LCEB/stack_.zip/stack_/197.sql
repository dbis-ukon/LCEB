SELECT p.Id, p.Title, u1.DisplayName AS Commenter1, u2.DisplayName AS Commenter2
FROM Comments c1
JOIN Comments c2 ON c1.PostId = c2.PostId AND c1.UserId <> c2.UserId
JOIN Users u1 ON c1.UserId = u1.Id
JOIN Users u2 ON c2.UserId = u2.Id
JOIN Posts p ON p.Id = c1.PostId
WHERE p.Title LIKE '%%'
  AND u1.DisplayName NOT LIKE ''%%'';
