SELECT p.Id, p.Title, u.DisplayName, COUNT(c.Id) AS CommentCount, AVG(c.Score) AS AvgCommentScore
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Score > -1
  AND p.PostTypeId = 1
  AND p.ClosedDate IS NULL
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(c.Id) > 3 AND AVG(c.Score) > 0
ORDER BY CommentCount DESC;
