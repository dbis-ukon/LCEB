SELECT Id, DisplayName, Reputation
FROM Users
WHERE (DisplayName LIKE '%consultant%' OR DisplayName LIKE '%researcher%') AND DisplayName NOT LIKE '%owner%'
  AND Views > 5 AND Views < 1000000 AND UpVotes > 0 AND DownVotes < 500 AND AccountId IS NOT NULL
  AND Reputation BETWEEN (SELECT MIN(Reputation) FROM Users) AND (SELECT MAX(Reputation) FROM Users);
