SELECT u.Id, u.DisplayName, COUNT(v.Id) AS upvote_count
FROM Users u
JOIN Votes v ON v.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND v.VoteTypeId = 2
  AND u.Reputation > 51
GROUP BY u.Id, u.DisplayName
HAVING COUNT(v.Id) > 50;
