SELECT p.Id, p.Title, v.VoteTypeId, u.DisplayName
FROM Posts p
JOIN Votes v ON v.PostId = p.Id
JOIN Users u ON u.Id = v.UserId
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
  AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%' OR u.DisplayName NOT LIKE ''%%'')
  AND p.PostTypeId = 1
  AND p.Score >= 4
  AND p.ViewCount >= 206
  AND v.VoteTypeId IN (1, 3, 2, 16, 10)
  AND v.CreationDate >= '2024-02-17 00:00:00';
