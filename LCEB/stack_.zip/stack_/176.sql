SELECT p.Id, p.Title, u.DisplayName, c.Text, c.Score AS CommentScore
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%')
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND c.Score > -1
  AND p.PostTypeId = 1
  AND p.Score >= 1
  AND p.AnswerCount > 0
  AND u.Reputation > 1
ORDER BY c.Score DESC;
