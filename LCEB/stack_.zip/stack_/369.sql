SELECT p1.Title AS Level1, p2.Title AS Level2, p3.Title AS Level3
FROM Posts p1
JOIN PostLinks pl1 ON pl1.PostId = p1.Id
JOIN Posts p2 ON p2.Id = pl1.RelatedPostId
JOIN PostLinks pl2 ON pl2.PostId = p2.Id
JOIN Posts p3 ON p3.Id = pl2.RelatedPostId
WHERE p1.Title LIKE '%%'
  AND p2.Title NOT LIKE ''%%''
  AND p3.Title LIKE '%%';
