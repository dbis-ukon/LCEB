SELECT p.Id, p.Title, u.DisplayName, COUNT(c.Id) AS comment_count, AVG(c.Score) AS avg_comment_score
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND P.Title LIKE '%%'
  AND U.Location NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score >= 6
  AND u.Reputation > 1
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(c.Id) > 2
ORDER BY comment_count DESC;
