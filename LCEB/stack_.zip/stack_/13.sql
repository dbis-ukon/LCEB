SELECT u1.Id AS UserA, u1.DisplayName AS NameA, u2.Id AS UserB, u2.DisplayName AS NameB, u1.Location
FROM Users u1
JOIN Users u2 ON u1.Location = u2.Location AND u1.Id <> u2.Id
WHERE u1.DisplayName LIKE '%%'
  AND u2.DisplayName NOT LIKE ''%%''
  AND u1.Location LIKE '%%'
  AND u1.Reputation > u2.Reputation
  AND u1.Reputation > 1
  AND u2.Reputation > 33
  AND u2.UpVotes > 0
ORDER BY u1.Reputation DESC;
