SELECT Id, TagName FROM Tags WHERE TagName LIKE '%rest%'
UNION ALL
SELECT Id, TagName FROM Tags WHERE TagName LIKE '%mobile%'
UNION ALL
SELECT Id, TagName FROM Tags WHERE TagName LIKE '%devops%';
