SELECT p1.Title AS QuestionTitle, p2.Title AS AnswerTitle, u1.DisplayName AS Asker, u2.DisplayName AS Answerer
FROM Posts p1
JOIN Posts p2 ON p2.ParentId = p1.Id
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
JOIN Badges b ON b.UserId = u2.Id
JOIN Votes v ON v.PostId = p2.Id
WHERE p1.Title LIKE '%%'
  AND u2.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND p2.CreationDate >= '2014-11-20 08:54:39.260000' AND p2.LastEditDate IS NOT NULL;
