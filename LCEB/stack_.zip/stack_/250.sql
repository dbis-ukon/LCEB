SELECT t.Id, t.TagName, p.Title, u.Location, b.Name
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE t.TagName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND p.Score >= 0;
