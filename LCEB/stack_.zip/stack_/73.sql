SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND (b.Name LIKE '%%' OR b.Name LIKE '%%')
  AND p.ViewCount BETWEEN 3125 AND 6736 AND p.Score > 1 AND b.Date >= '2015-08-18 06:01:52.250000'
  AND pt.Name IS NOT NULL
  AND c.Score >= 0
ORDER BY b.Date DESC;
