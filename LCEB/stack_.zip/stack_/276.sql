SELECT *
FROM Users
WHERE Location LIKE '%New%'
  AND Location LIKE '%York%'
  AND DisplayName NOT LIKE '%test%'
  AND DisplayName LIKE '%Smith%'
   AND Location LIKE '%York%'
  AND DisplayName NOT LIKE '%test%'
  AND DisplayName LIKE '%Smith%'
  AND Reputation >= 500
  AND UpVotes > 50;
