SELECT p.Title, u.DisplayName, u.Location
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (p.Title NOT LIKE ''%%'' OR u.DisplayName LIKE '%%')
  AND (u.Location LIKE '%%')
  AND p.AnswerCount >= 1
  AND u.UpVotes > 0
ORDER BY p.CreationDate DESC;
