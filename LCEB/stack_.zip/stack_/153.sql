SELECT p.Id AS ItemId, 'Post' AS SourceType, p.Title AS MatchedText, p.CreationDate
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score > 4
  AND p.ViewCount > 301
UNION
SELECT c.Id AS ItemId, 'Comment' AS SourceType, p.Title AS MatchedText, c.CreationDate
FROM Comments c
JOIN Posts p ON p.Id = c.PostId
WHERE p.Title LIKE '%%'
  AND c.Score > 1
  AND p.PostTypeId = 2
ORDER BY CreationDate DESC;
