SELECT p.Id, p.Title, COUNT(DISTINCT v1.Id) AS Upvotes, COUNT(DISTINCT v2.Id) AS Downvotes
FROM Posts p
JOIN Votes v1 ON v1.PostId = p.Id AND v1.VoteTypeId = 2
JOIN Votes v2 ON v2.PostId = p.Id AND v2.VoteTypeId = 3
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.Score BETWEEN 1 AND 2
  AND p.ViewCount > 111
GROUP BY p.Id, p.Title
HAVING COUNT(DISTINCT v1.Id) > 3 AND COUNT(DISTINCT v2.Id) > 3
ORDER BY p.ViewCount DESC;
