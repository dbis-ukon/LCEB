SELECT p.Title, u.DisplayName, ph1.CreationDate AS FirstEdit, ph2.CreationDate AS SecondEdit
FROM PostHistory ph1
JOIN PostHistory ph2 ON ph1.PostId = ph2.PostId AND ph1.UserId = ph2.UserId AND ph1.CreationDate < ph2.CreationDate
JOIN Posts p ON p.Id = ph1.PostId
JOIN Users u ON ph1.UserId = u.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%')
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score > -1
  AND u.Reputation > 1
  AND p.ViewCount > 988
  AND p.AnswerCount >= 1
ORDER BY ph2.CreationDate DESC;
