SELECT b.Id AS ItemId, 'Badge' AS SourceType, b.Name AS MatchedName, b.Class AS Weight
FROM Badges b
WHERE b.Class = 3
  AND b.TagBased = false
  AND b.Class = 3
UNION ALL
SELECT t.Id AS ItemId, 'Tag' AS SourceType, t.TagName AS MatchedName, t.Count AS Weight
FROM Tags t
WHERE t.TagName LIKE '%%'
  AND t.IsModeratorOnly IS NOT TRUE
  AND t.Count > 1509
ORDER BY Weight DESC;
