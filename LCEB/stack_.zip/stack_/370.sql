SELECT p.Id, p.Title, u.DisplayName, AVG(c.Score) AS avg_comment_score, COUNT(c.Id) AS comment_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND p.Score > 2
  AND p.PostTypeId = 1
  AND p.ClosedDate IS NULL
GROUP BY p.Id, p.Title, u.DisplayName
HAVING AVG(c.Score) > 0
ORDER BY avg_comment_score DESC;
