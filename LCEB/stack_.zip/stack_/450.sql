SELECT p.Id, p.Title, lt.Name
FROM Posts p
JOIN PostLinks pl ON pl.PostId = p.Id
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
WHERE p.Title LIKE '%%'
  AND lt.Name = 'Linked'
  AND pl.CreationDate >= '2018-04-26 01:52:29.497000';
