SELECT u.Id, u.DisplayName, u.Location, COUNT(p.Id) AS post_count
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.Location LIKE '%%'
  AND u.Reputation > 11
  AND p.CreationDate >= '2018-09-14 03:10:53.147000'
  AND p.Score >= 2
GROUP BY u.Id, u.DisplayName, u.Location
HAVING COUNT(p.Id) >= 3
ORDER BY post_count DESC;
