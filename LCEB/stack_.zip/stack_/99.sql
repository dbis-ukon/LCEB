SELECT p.Id, p.Title, u.DisplayName, t.TagName,
       b.Name AS BadgeName, COUNT(DISTINCT v.Id) AS VoteCount
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.WikiPostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Name LIKE '%%'
  AND t.Count > 4618
  AND t.IsModeratorOnly IS NOT TRUE
  AND vt.Id IN (7, 15, 6, 10, 8)
GROUP BY p.Id, p.Title, u.DisplayName, t.TagName, b.Name
HAVING COUNT(DISTINCT v.Id) >= 2
ORDER BY VoteCount DESC;
