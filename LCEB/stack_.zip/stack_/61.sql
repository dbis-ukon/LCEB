SELECT p1.Title AS Source, p2.Title AS Related, u1.DisplayName AS Owner1, u2.DisplayName AS Owner2, t.TagName
FROM Posts p1
JOIN PostLinks pl ON pl.PostId = p1.Id
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
JOIN Users u1 ON p1.OwnerUserId = u1.Id
JOIN Users u2 ON p2.OwnerUserId = u2.Id
CROSS JOIN Tags t
WHERE p1.Tags LIKE '%%' AND p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND u1.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%';
