SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Votes v ON v.UserId = u.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE (p.Title LIKE '%%' OR b.Name LIKE '%%')
  AND p.Score > 3 AND p.ViewCount > 409 AND b.Class <= 3
  AND v.PostId = p.Id
  AND vt.Name IS NOT NULL
ORDER BY b.Date DESC;
