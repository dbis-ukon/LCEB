SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName,
       pt.Name AS PostType, v.VoteTypeId, vt.Name AS VoteType
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
JOIN PostTypes pt ON pt.Id = p.PostTypeId
JOIN Votes v ON v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.AcceptedAnswerId IS NOT NULL
  AND p.Score BETWEEN 0 AND 1
  AND v.CreationDate >= '2013-03-21 00:00:00'
  AND vt.Id IN (12, 15, 6, 1, 7)
ORDER BY p.Score DESC;
