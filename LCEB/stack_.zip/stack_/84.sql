SELECT u.Id, u.DisplayName, p.Title, b.Name, c.Text, v.VoteTypeId
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND c.Score > 0
  AND v.VoteTypeId = 16;
