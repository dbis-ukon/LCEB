SELECT
    ph.Id,
    p.Title,
    ph.UserDisplayName,
    ph.Comment
FROM PostHistory ph
JOIN Posts p ON p.Id = ph.PostId
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (ph.Comment LIKE '%%' OR ph.Comment LIKE '%%' OR ph.Comment NOT LIKE ''%%'')
    AND ph.PostHistoryTypeId IN (5, 24, 6, 2, 1)
    AND p.PostTypeId = 1
    AND ph.CreationDate >= '2019-02-18 15:54:50.920000'
    AND p.ClosedDate IS NOT NULL;
