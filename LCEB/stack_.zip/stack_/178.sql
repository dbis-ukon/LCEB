SELECT p.Id, p.Title, u.DisplayName, COUNT(c.Id) AS comment_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
WHERE p.Title LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.ViewCount > 47 AND p.AnswerCount >= 1 AND u.WebsiteUrl IS NOT NULL AND u.CreationDate >= '2021-10-28 09:19:04.827000'
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(c.Id) > 4;
