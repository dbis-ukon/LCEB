SELECT p.Title, c.Text, v.VoteTypeId
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Comments c ON c.PostId = p.Id
JOIN Votes v ON v.PostId = p.Id
WHERE p.Title NOT LIKE ''%%''
  AND u.DisplayName NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND c.Score < 1
  AND v.VoteTypeId = 2
ORDER BY c.Score ASC
LIMIT 20;
