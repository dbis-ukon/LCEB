SELECT u.Id, u.DisplayName, COUNT(b.Id) AS badge_count
FROM Users u
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
GROUP BY u.Id, u.DisplayName
HAVING COUNT(b.Id) > 3;
