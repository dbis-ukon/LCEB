SELECT u.Id, u.DisplayName, COUNT(DISTINCT p.Id) AS PostCount, SUM(CASE WHEN v.VoteTypeId = 2 THEN 1 ELSE 0 END) AS Upvotes
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.Reputation > 11
  AND p.PostTypeId = 1
  AND p.Score > 0
  AND p.ViewCount > 550
GROUP BY u.Id, u.DisplayName
HAVING SUM(CASE WHEN v.VoteTypeId = 16 THEN 1 ELSE 0 END) > 5
ORDER BY Upvotes DESC;
