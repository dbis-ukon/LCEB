SELECT u.Id, u.DisplayName, u.Location, COUNT(b.Id) AS gold_badges
FROM Users u
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName LIKE '%%'
  AND u.Location LIKE '%%'
  AND b.Class = 3
  AND b.Class = 3
  AND u.Reputation > 1
GROUP BY u.Id, u.DisplayName, u.Location
HAVING COUNT(b.Id) >= 1
ORDER BY gold_badges DESC;
