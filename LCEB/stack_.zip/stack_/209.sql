SELECT b.Id, b.Name, u.Location, p.Title
FROM Badges b
JOIN Users u ON u.Id = b.UserId
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE b.Name LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p.Title NOT LIKE ''%%''
  AND p.Score > 3;
