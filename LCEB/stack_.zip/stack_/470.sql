SELECT p.Id, p.Title, t.TagName
FROM Tags t
JOIN Posts p ON t.ExcerptPostId = p.Id
WHERE t.TagName LIKE '%%'
  AND p.Title NOT LIKE ''%%'';
