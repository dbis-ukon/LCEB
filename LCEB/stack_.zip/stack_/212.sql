SELECT t.TagName, t.Count,
       p1.Id AS ExcerptPostId,
       p2.Id AS WikiPostId,
       u.DisplayName, u.Location,
       b.Name AS BadgeName
FROM Tags t
JOIN Posts p1 ON t.ExcerptPostId = p1.Id
JOIN Posts p2 ON t.WikiPostId = p2.Id
JOIN Users u ON p1.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE t.TagName LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND t.Count > 19
ORDER BY t.Count DESC;
