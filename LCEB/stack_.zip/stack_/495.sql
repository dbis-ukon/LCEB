SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName NOT LIKE ''%%''
  AND u.Reputation > 21
  AND EXISTS (
      SELECT 1 FROM Badges b WHERE b.UserId = u.Id AND b.Name LIKE '%%' AND b.Class = 1
  )
ORDER BY p.CreationDate DESC;
