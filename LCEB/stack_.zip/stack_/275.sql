SELECT p.Title, u1.DisplayName AS Owner, u2.DisplayName AS Editor, u3.DisplayName AS Voter, b.Name AS VoterBadge
FROM Posts p
JOIN Users u1 ON p.OwnerUserId = u1.Id
JOIN Users u2 ON p.LastEditorUserId = u2.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Users u3 ON v.UserId = u3.Id
JOIN Badges b ON b.UserId = u3.Id
WHERE (p.Title LIKE '%%' OR p.Title LIKE '%%') AND u1.DisplayName NOT LIKE ''%%'' AND u2.DisplayName LIKE '%%' AND u3.DisplayName LIKE '%%' AND b.Class <> 3;
