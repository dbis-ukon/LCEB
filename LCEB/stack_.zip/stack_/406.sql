SELECT p.Id, p.Title, u.Location, b.Name
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND b.Name LIKE '%%'
  AND p.Score >= 4
  AND p.ViewCount BETWEEN 94 AND 107
  AND p.ClosedDate IS NULL
  AND p.LastEditDate IS NOT NULL
  AND u.UpVotes > 0
  AND u.AccountId IS NOT NULL
  AND b.TagBased = false;
