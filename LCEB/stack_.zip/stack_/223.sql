SELECT p.Id, p.Title, u.DisplayName, COUNT(v.Id) AS vote_count
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Tags t ON t.ExcerptPostId = p.Id
WHERE t.TagName LIKE '%%' AND u.Location LIKE '%%' AND b.Name NOT LIKE ''%%''
  AND v.VoteTypeId IN (1, 2, 3)
  AND u.UpVotes > 0
  AND u.DownVotes < 0
GROUP BY p.Id, p.Title, u.DisplayName
HAVING COUNT(v.Id) > 2;
