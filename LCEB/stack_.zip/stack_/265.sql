SELECT p.Title, c1.Text AS EarlyComment,
       (SELECT p2.Score FROM Posts p2 WHERE p2.Id = c1.PostId) AS PostScore
FROM Comments c1
JOIN Comments c2 ON c1.PostId = c2.PostId AND c1.CreationDate < c2.CreationDate
JOIN Posts p ON p.Id = c1.PostId
WHERE p.Title LIKE '%%'
  AND c1.Score > 0
  AND c2.Score >= 0
  AND p.PostTypeId = 1
ORDER BY PostScore DESC;
