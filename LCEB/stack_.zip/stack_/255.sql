SELECT Id, TagName, Count,
       LAG(Count, 2) OVER (ORDER BY Id) AS TwoRowsBack
FROM Tags
WHERE (TagName LIKE '%orm%' OR TagName LIKE '%rest%')
  AND TagName NOT LIKE '%security%'
  AND Count BETWEEN 1 AND 50000
  AND Count IN (10, 50, 100, 500)
  AND IsRequired IS NOT TRUE
  AND Id BETWEEN 1 AND 999999
  AND Count > 10;
