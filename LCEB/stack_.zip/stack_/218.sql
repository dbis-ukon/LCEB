SELECT u.Id, u.DisplayName, u.Location, p.Title, b.Name
FROM Users u
JOIN Posts p ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND p.Title LIKE '%%'
  AND b.Name NOT LIKE ''%%'';
