SELECT p.Id, p.Title, p.ViewCount
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score >= 2
  AND p.AnswerCount = 0
EXCEPT
SELECT p.Id, p.Title, p.ViewCount
FROM Posts p
JOIN Comments c ON c.PostId = p.Id
WHERE p.PostTypeId = 2;
