SELECT p.Id, p.Title, u.DisplayName,
       t.TagName, b.Name AS BadgeName,
       v.BountyAmount, vt.Name AS VoteType,
       pt.Name AS PostType
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Tags t ON t.WikiPostId = p.Id
JOIN Badges b ON b.UserId = u.Id
JOIN Votes v ON v.PostId = p.Id
JOIN VoteTypes vt ON vt.Id = v.VoteTypeId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND t.TagName LIKE '%%'
  AND b.Name LIKE '%%'
  AND v.BountyAmount > 50
  AND p.ViewCount >= 196
  AND pt.Id IN (4, 1, 7, 3, 8)
ORDER BY v.BountyAmount DESC;
