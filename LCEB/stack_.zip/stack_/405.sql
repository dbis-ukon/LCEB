SELECT p.Id, p.Title, u.DisplayName, p.Score
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
JOIN Badges b ON b.UserId = u.Id
WHERE (p.Title NOT LIKE ''%%'' OR u.DisplayName LIKE '%%')
  AND (u.Location LIKE '%%')
  AND (b.Name LIKE '%%')
  AND p.ClosedDate IS NULL
  AND u.Views > 0
  AND p.Score > 5
  AND p.PostTypeId = 2
ORDER BY p.CreationDate DESC;
