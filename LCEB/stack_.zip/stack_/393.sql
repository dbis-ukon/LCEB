SELECT p.Id, p.Title, pt.Name
FROM Posts p
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE p.Title LIKE '%%'
  AND pt.Name = 'Question'
  AND p.Score >= 0;
