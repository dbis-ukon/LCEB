SELECT p1.Title AS PostA, p2.Title AS PostB, u.DisplayName
FROM Posts p1
JOIN Posts p2 ON p1.OwnerUserId = p2.OwnerUserId AND p1.Id <> p2.Id
JOIN Users u ON p1.OwnerUserId = u.Id
WHERE p1.Title LIKE '%%'
  AND p2.Title LIKE '%%'
  AND u.DisplayName LIKE '%%';
