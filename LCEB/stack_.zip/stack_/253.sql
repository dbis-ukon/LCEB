SELECT *
FROM Users
WHERE DisplayName LIKE '%John%'
  AND (DisplayName LIKE '%Smith%' OR DisplayName LIKE '%Brown%')
  AND Location NOT LIKE '%Unknown%'
  AND Location NOT LIKE '%Test%'
  AND Reputation > 100
  AND UpVotes >= 20;
