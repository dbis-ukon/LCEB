SELECT p.Id, p.Title
FROM Posts p
JOIN Badges b ON b.UserId = p.OwnerUserId
WHERE (p.Title LIKE '%%' OR  p.Title LIKE '%%')
  AND b.Name LIKE '%%'
  AND b.Class = 2
  AND p.Id IN (SELECT PostId FROM Comments GROUP BY PostId HAVING COUNT(*) > 5);
