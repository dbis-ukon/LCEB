SELECT Id, Title, Score
FROM Posts
WHERE (Title LIKE '%Python%' OR Title LIKE '%Java%')
  AND ViewCount > 500;
