SELECT sub.Id, sub.DisplayName, sub.Reputation
FROM (
    SELECT Id, DisplayName, Reputation, ROW_NUMBER() OVER (ORDER BY Reputation DESC) AS rk
    FROM Users
    WHERE (DisplayName LIKE '%founder%' OR DisplayName LIKE '%dev%') AND DownVotes BETWEEN 0 AND 500 AND Reputation IN (100, 500, 1000, 5000)
) sub
WHERE sub.rk <= 10;
