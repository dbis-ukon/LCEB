SELECT p1.Id AS SourcePost, p1.Title AS SourceTitle, p2.Title AS RelatedTitle, lt.Name AS LinkType
FROM Posts p1
JOIN PostLinks pl ON pl.PostId = p1.Id
JOIN Posts p2 ON p2.Id = pl.RelatedPostId
JOIN LinkTypes lt ON lt.Id = pl.LinkTypeId
WHERE p1.Title LIKE '%%'
  AND p2.Title NOT LIKE ''%%''
  AND lt.Name = 'Linked'
  AND p1.PostTypeId = 1
  AND p2.PostTypeId = 1
  AND pl.CreationDate >= '2021-11-05 13:26:54.153000'
  AND p1.Score > -1
ORDER BY pl.CreationDate DESC;
