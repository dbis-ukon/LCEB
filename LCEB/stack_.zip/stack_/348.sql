SELECT t.Id, t.TagName, p.Title, b.Name
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE t.TagName LIKE '%%'
  AND b.Name LIKE '%%';
