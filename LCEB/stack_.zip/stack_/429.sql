SELECT p1.Id AS QuestionId, p1.Title AS QuestionTitle, p2.Id AS AnswerId, u.DisplayName AS Asker
FROM Posts p1
JOIN Posts p2 ON p2.ParentId = p1.Id
JOIN Users u ON p1.OwnerUserId = u.Id
WHERE p1.Title LIKE '%%'
  AND p1.Title NOT LIKE ''%%''
  AND u.DisplayName LIKE '%%'
  AND u.Location NOT LIKE ''%%''
  AND p1.PostTypeId = 1
  AND p2.PostTypeId = 2
  AND p2.Score > 4
  AND p1.AnswerCount > 2
  AND p1.ViewCount > 106
ORDER BY p2.Score DESC;
