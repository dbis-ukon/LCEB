SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND p.PostTypeId = 1
  AND p.OwnerUserId IN (
      SELECT UserId FROM Badges GROUP BY UserId HAVING COUNT(*) > 10
  )
ORDER BY p.Score DESC;
