SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.Title NOT LIKE ''%%''
  AND u.DisplayName NOT LIKE ''%%'';
