SELECT u.Id, u.DisplayName, u.Location, b.Name, p.Title
FROM Users u
JOIN Badges b ON b.UserId = u.Id
JOIN Posts p ON p.OwnerUserId = u.Id
WHERE u.DisplayName NOT LIKE ''%%''
  AND u.Location LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Score > 3;
