SELECT p.Id, p.Title, u.DisplayName
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE p.Title LIKE '%%'
  AND p.CreationDate >= '2012-07-12 01:27:50.150000' AND p.LastEditDate IS NOT NULL
  AND EXISTS (
      SELECT 1 FROM Badges b WHERE b.UserId = u.Id AND b.Name LIKE '%%'
  );
