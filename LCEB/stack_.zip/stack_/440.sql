SELECT *
FROM Posts
WHERE Title LIKE '%API%'
  AND PostTypeId IN (1, 2)
  AND LastActivityDate >= '2023-01-01';
