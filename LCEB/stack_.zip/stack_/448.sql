SELECT p.Id, p.Title, p.Score
FROM Posts p
WHERE p.Title LIKE '%%'
  AND p.PostTypeId = 1
  AND p.Score > 0
  AND p.OwnerUserId IN (162258, 28401, 142385, 317339, 16078)
ORDER BY p.Score DESC;
