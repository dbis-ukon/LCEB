SELECT p.Id, p.Title, u.DisplayName, u.Reputation
FROM Posts p
JOIN Users u ON p.OwnerUserId = u.Id
WHERE (u.Location LIKE '%%' or u.Location LIKE '%%')
  AND u.DisplayName LIKE '%%'
  AND p.ParentId IS NULL AND p.ViewCount BETWEEN 53 AND 1826 AND u.Reputation BETWEEN 1 AND 473 AND u.Reputation > 1
ORDER BY p.ViewCount DESC
LIMIT 250;
