SELECT
    p.Id,
    p.Title,
    u.DisplayName,
    b.Name AS BadgeName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE
    (p.Title LIKE '%%' OR p.Title LIKE '%%' OR p.Title NOT LIKE ''%%'')
    AND (u.DisplayName LIKE '%%' OR u.DisplayName LIKE '%%')
    AND (b.Name LIKE '%%' OR b.Name NOT LIKE ''%%'')
    AND p.PostTypeId = 1
    AND p.Score BETWEEN 1 AND 1
    AND u.Reputation >= 1
    AND b.Class IN (3);
