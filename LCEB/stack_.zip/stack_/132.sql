SELECT p.Id, p.Title, u.DisplayName, b.Name AS BadgeName
FROM Posts p
JOIN Users u ON u.Id = p.OwnerUserId
JOIN Badges b ON b.UserId = u.Id
WHERE p.Title LIKE '%%'
  AND u.DisplayName LIKE '%%'
  AND b.Name LIKE '%%'
  AND p.Score BETWEEN 2 AND 3
  AND p.AnswerCount >= 4
  AND p.ClosedDate IS NULL
  AND u.Reputation >= 1
  AND b.Class IN (2, 3)
ORDER BY p.Score DESC;
