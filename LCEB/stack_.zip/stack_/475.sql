SELECT t.Id, t.TagName, p.Title, u.Location, pt.Name
FROM Tags t
JOIN Posts p ON p.Id = t.ExcerptPostId
JOIN Users u ON u.Id = p.OwnerUserId
JOIN PostTypes pt ON pt.Id = p.PostTypeId
WHERE t.TagName LIKE '%%'
  AND u.Location LIKE '%%'
  AND p.Score > -1
  AND pt.Id = 4;
