SELECT akat.id, akat.title, akat.production_year, akat.kind_id,
       mc.company_id, c.name AS company_name,
       mk.keyword_id, k.keyword,
       ci.person_id
FROM aka_title akat
JOIN movie_companies mc   ON akat.movie_id = mc.movie_id
JOIN company_name c       ON mc.company_id = c.id
JOIN movie_keyword mk     ON akat.movie_id = mk.movie_id
JOIN keyword k            ON mk.keyword_id = k.id
LEFT JOIN cast_info ci    ON akat.movie_id = ci.movie_id
WHERE akat.title LIKE '%%'
  AND akat.title LIKE '%%'
  AND c.name LIKE '%%'
  AND c.country_code = '[il]'
  AND mc.company_type_id IN (1, 2)
  AND k.keyword LIKE '%%'
  AND akat.production_year BETWEEN 1926 AND 1986
  AND akat.kind_id IN (3, 1)or
  AND ci.role_id IS NOT NULL;
