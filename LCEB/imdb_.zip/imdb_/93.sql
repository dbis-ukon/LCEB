SELECT k.keyword, COUNT(DISTINCT t.id) AS total_movies
FROM keyword k
JOIN movie_keyword mk ON mk.keyword_id = k.id
JOIN title t ON t.id = mk.movie_id
WHERE k.keyword LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.title LIKE '%%'
  AND t.title NOT LIKE '%%'
  AND t.season_nr = 1
  AND t.episode_nr <= 33
  AND t.production_year >= 1935
GROUP BY k.keyword
ORDER BY total_movies DESC;
