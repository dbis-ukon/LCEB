SELECT t.id AS item_id, 'title' AS source, t.title AS matched_text
FROM title t
WHERE t.title LIKE '%%'
  AND t.season_nr >= 13 AND t.episode_nr <= 23 AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL
UNION
SELECT akat.id AS item_id, 'aka_title' AS source, akat.title AS matched_text
FROM aka_title akat
WHERE akat.title LIKE '%%'
  AND akat.episode_nr <= 8 AND akat.episode_of_id IS NULL AND akat.episode_of_id IS NOT NULL AND akat.md5sum IS NOT NULL;
