SELECT id, title, production_year
FROM aka_title
WHERE (title LIKE '%city%' OR title LIKE '%town%')
  AND title NOT LIKE '%small town%'
  AND production_year BETWEEN 1970 AND 2020
  AND id > 100;
