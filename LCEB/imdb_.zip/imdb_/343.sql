SELECT id, name, imdb_index, imdb_id, name_pcode_nf, surname_pcode, md5sum
FROM char_name cn
WHERE cn.name LIKE '%%'
  AND cn.imdb_id > 500
  AND cn.name_pcode_nf IS NOT NULL
  AND cn.surname_pcode IS NOT NULL;
