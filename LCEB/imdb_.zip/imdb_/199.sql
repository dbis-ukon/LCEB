SELECT id, name, country_code, imdb_id, name_pcode_nf, name_pcode_sf, md5sum
FROM company_name c
WHERE (c.name LIKE '%%' OR c.name LIKE '%%')
  AND c.name LIKE '%%'
  AND c.country_code = '[gb]'
  AND c.md5sum IS NOT NULL;
