SELECT t.id, t.title, kt.kind, it.info AS InfoCategory, mi.info AS Details, n.name AS ActorName
FROM title t
JOIN kind_type kt ON kt.id = t.kind_id
JOIN movie_info mi ON mi.movie_id = t.id
JOIN info_type it ON it.id = mi.info_type_id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND kt.kind = 'episode'
  AND it.info = 'goofs'
  AND (n.name LIKE '%%' OR n.name LIKE '%%')
  AND it.id > 1;
