SELECT cn.id, cn.name, cn.imdb_index, cn.imdb_id, cn.name_pcode_nf, cn.surname_pcode, cn.md5sum,
       akat.title, akat.episode_nr
FROM char_name cn
JOIN cast_info ci ON cn.id = ci.person_id
JOIN aka_title akat ON ci.movie_id = akat.movie_id
WHERE cn.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND cn.name_pcode_nf = 'F6524'
  AND (cn.md5sum LIKE '%%' OR cn.imdb_id > 2000)
  AND akat.episode_nr BETWEEN 8 AND 25;
