SELECT id, name
FROM name
WHERE (name LIKE '%Kevin%' OR name LIKE '%Brian%')
  AND name NOT LIKE '%Test%'
  AND imdb_index IS NOT NULL
  AND id > 100;
