SELECT cn.name AS character_name, t.title, ci.role_id, MAX(t.production_year) AS latest_year
FROM char_name cn
JOIN cast_info ci ON cn.id = ci.person_id
JOIN title t ON ci.movie_id = t.id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name c ON mc.company_id = c.id
WHERE cn.name LIKE '%%'
  AND t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND c.name LIKE '%%'
  AND rt.role LIKE '%%'
  AND t.production_year >= 2004
GROUP BY cn.name, t.title, ci.role_id
ORDER BY latest_year DESC;
