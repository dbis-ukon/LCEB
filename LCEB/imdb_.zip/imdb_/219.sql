SELECT t.id, t.title, it1.info AS InfoType1, mi.info AS Value1, mi_idx.info AS RatingValue
FROM title t
JOIN movie_info mi ON mi.movie_id = t.id
JOIN info_type it1 ON it1.id = mi.info_type_id
JOIN movie_info_idx mi_idx ON mi_idx.movie_id = t.id
JOIN info_type it2 ON it2.id = mi_idx.info_type_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND it1.info = 'genres'
  AND it2.info = 'votes'
  AND t.production_year > 1997 AND t.production_year < 2005 AND t.production_year BETWEEN 1968 AND 2013;
