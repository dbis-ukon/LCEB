SELECT t.title, n.name, k.keyword, t.production_year
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE (t.title LIKE '%%' OR n.name LIKE '%%')
  AND ci.nr_order <= 9
  AND t.production_year <= 1995
  AND t.kind_id = 7
  AND k.keyword NOT LIKE '%%'
ORDER BY t.production_year DESC
LIMIT 200;
