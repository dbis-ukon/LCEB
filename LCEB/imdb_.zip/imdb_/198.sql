SELECT t.title, n.name, chn.name AS CharacterName, rt.role
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN char_name chn ON chn.id = ci.person_role_id
JOIN role_type rt ON rt.id = ci.role_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND n.name NOT LIKE '%%'
  AND (chn.name LIKE '%%' OR chn.name LIKE '%%')
  AND rt.role = 'actress'
  AND ci.movie_id < 500000
  AND chn.id > 100
  AND n.id BETWEEN 1000 AND 100000;
