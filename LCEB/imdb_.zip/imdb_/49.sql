SELECT id, title, production_year
FROM aka_title
WHERE (title LIKE '%star%' OR title LIKE '%wars%')
  AND title NOT LIKE '%episode%'
  AND production_year >= 1980
  AND kind_id > 0;
