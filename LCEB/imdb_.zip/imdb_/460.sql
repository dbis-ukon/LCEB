SELECT id, keyword
FROM keyword
WHERE (keyword LIKE '%computer%' OR keyword LIKE '%internet%')
  AND keyword NOT LIKE '%computer game%'
  AND id BETWEEN 100 AND 900000
  AND phonetic_code IS NOT NULL;
