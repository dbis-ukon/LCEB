SELECT n.id, n.name AS real_name, an.name AS aka_name, t.title, kt.kind
FROM name n
JOIN aka_name an ON an.person_id = n.id
JOIN cast_info ci ON n.id = ci.person_id
JOIN title t ON ci.movie_id = t.id
JOIN kind_type kt ON t.kind_id = kt.id
WHERE n.name LIKE '%%'
  AND n.name LIKE '%%'
  AND n.name_pcode_nf IS NOT NULL AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND ci.nr_order <= 2 AND t.production_year > 1969 AND t.production_year < 2006 AND t.production_year BETWEEN 1994 AND 2007 AND t.kind_id IN (3, 1, 4, 7);
