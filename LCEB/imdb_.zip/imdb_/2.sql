SELECT t.id, t.title
FROM title t
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.phonetic_code IS NOT NULL AND t.production_year > 1900 AND t.production_year < 2006
  AND NOT EXISTS (
      SELECT 1 FROM aka_title at WHERE at.movie_id = t.id
  )
  AND EXISTS (
      SELECT 1 FROM cast_info ci JOIN name n ON n.id = ci.person_id
      WHERE ci.movie_id = t.id AND n.name NOT LIKE '%%'
  );
