SELECT akat.movie_id,
       t.title,
       COUNT(DISTINCT k.keyword) AS num_keywords,
       MAX(akat.production_year) AS latest_year,
       cn.name AS character_name,
       ci.role_id
FROM aka_title akat
JOIN cast_info ci ON akat.movie_id = ci.movie_id
JOIN char_name cn ON ci.person_id = cn.id
JOIN name n ON cn.id = n.id
JOIN movie_keyword mk ON akat.movie_id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN title t ON akat.movie_id = t.id
WHERE cn.name LIKE '%%'
  AND n.name LIKE '%%'
  AND ci.nr_order <= 1
  AND akat.title LIKE '%%'
  AND t.title LIKE '%%'
  AND k.keyword LIKE '%%''_-pilgrimage'
  AND k.keyword LIKE '%%'
  AND akat.production_year >= 1956
GROUP BY akat.movie_id, t.title, cn.name, ci.role_id
ORDER BY latest_year DESC;
