SELECT id, keyword, phonetic_code
FROM keyword k
WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND k.id BETWEEN 8962 AND 80918
  AND k.phonetic_code LIKE '%%';
