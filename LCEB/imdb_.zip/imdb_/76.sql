SELECT a.title, COUNT(DISTINCT cc.subject_id) AS total_actors
FROM aka_title a
JOIN complete_cast cc ON cc.movie_id = a.movie_id
JOIN name n ON n.id = cc.subject_id
WHERE (a.title LIKE '%%' or n.name NOT LIKE '%%')
  AND n.gender = 'm'
  AND a.episode_nr >= 5
GROUP BY a.title
ORDER BY total_actors DESC;
