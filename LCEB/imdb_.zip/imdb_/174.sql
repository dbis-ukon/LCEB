SELECT t.id, t.title, n.name AS PersonName, rt.role, chn.name AS CharacterName
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN char_name chn ON chn.id = ci.person_role_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND rt.role = 'actor'
  AND (chn.name LIKE '%%' OR chn.name LIKE '%%')
  AND t.production_year > 1962 AND t.production_year < 2012 AND t.production_year BETWEEN 2001 AND 2011 AND ci.person_role_id IS NOT NULL AND ci.nr_order <= 5;
