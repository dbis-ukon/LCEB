SELECT t.id, t.title, k.keyword, kt.kind, cct1.kind AS subject_kind, cct2.kind AS status_kind
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN complete_cast cc ON t.id = cc.movie_id
JOIN comp_cast_type cct1 ON cc.subject_id = cct1.id
JOIN comp_cast_type cct2 ON cc.status_id = cct2.id
WHERE t.title LIKE '%%'
  AND t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND k.keyword NOT LIKE '%%'
  AND t.production_year < 2001 AND t.production_year BETWEEN 1990 AND 2002 AND t.kind_id IN (4, 1, 7, 3) AND t.season_nr >= 2 AND k.phonetic_code IS NOT NULL AND k.id > 42741 AND cc.status_id IS NOT NULL;
