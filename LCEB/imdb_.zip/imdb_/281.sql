SELECT t.id, t.title, cn.name AS company_name, ct.kind, mii.info AS rating_value
FROM title t
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_info_idx mii ON t.id = mii.movie_id
JOIN info_type it ON mii.info_type_id = it.id
WHERE t.title LIKE '%%'
  AND cn.name LIKE '%%'
  AND it.info = 'rating'
  AND cn.name_pcode_sf IS NOT NULL AND cn.country_code = '[us]' AND cn.country_code IS NOT NULL AND mc.company_id > 69 AND mc.company_type_id IN (1, 2) AND t.production_year BETWEEN 1976 AND 1993 AND t.kind_id IN (1, 7, 3) AND t.season_nr >= 1 AND t.episode_nr <= 11;
