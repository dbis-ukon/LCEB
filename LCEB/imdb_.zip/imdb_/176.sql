SELECT akat.movie_id, akat.title,
       COUNT(DISTINCT k.keyword) AS num_keywords,
       MAX(akat.episode_nr) AS max_episode,
       COUNT(DISTINCT ci.person_id) AS main_cast,
       MAX(akat.production_year) AS latest_year,
       MIN(ct.kind) AS company_type_kind,
       MIN(n.gender) AS gender_flag,
       MIN(c.country_code) AS country,
       MIN(comp.kind) AS comp_cast_kind
FROM aka_title akat
JOIN movie_keyword mk1 ON akat.movie_id = mk1.movie_id
JOIN keyword k ON mk1.keyword_id = k.id
JOIN movie_keyword mk2 ON akat.movie_id = mk2.movie_id
JOIN keyword k2 ON mk2.keyword_id = k2.id
JOIN movie_companies mc ON akat.movie_id = mc.movie_id
JOIN company_name c ON mc.company_id = c.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN cast_info ci ON akat.movie_id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN comp_cast_type comp ON ci.role_id = comp.id
WHERE (akat.title LIKE '%%' OR akat.title LIKE '%%')
  AND k.keyword LIKE '%%'
  AND k2.keyword LIKE '%%'
  AND c.country_code = '[ge]'
  AND ci.nr_order <= 23
  AND n.gender IN ('m', 'f')
  AND ct.kind IN ('special effects companies', 'production companies', 'distributors', 'miscellaneous companies')
  AND comp.kind LIKE '%%'
  AND akat.production_year BETWEEN 1990 AND 1994
GROUP BY akat.movie_id, akat.title
ORDER BY num_keywords DESC;
