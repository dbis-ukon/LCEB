SELECT a.title, COUNT(DISTINCT ml.movie_id) AS linked_movies
FROM aka_title a
JOIN movie_link ml ON ml.movie_id = a.movie_id
JOIN link_type lt ON lt.id = ml.link_type_id
WHERE a.title LIKE '%%'
  AND a.title LIKE '%%'
  AND lt.link LIKE '%%'
  AND a.production_year >= 2010
GROUP BY a.title
ORDER BY linked_movies DESC;
