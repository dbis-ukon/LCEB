SELECT t.id, t.title, kt.kind, rt.role, cn.name AS company_name, k.keyword
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.title LIKE '%%'
  AND kt.kind = 'episode'
  AND k.keyword LIKE '%%'
  AND cn.name LIKE '%%'
  AND ci.note IS NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND cn.country_code = '[us]' AND cn.country_code IS NOT NULL AND cn.imdb_id > 3800 AND mc.company_type_id IN (2, 1) AND mc.note IS NULL;
