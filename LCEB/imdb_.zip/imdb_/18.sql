SELECT t.id, t.title, mi.info AS Plot
FROM title t
JOIN movie_info mi ON mi.movie_id = t.id
JOIN info_type it ON it.id = mi.info_type_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND it.info = 'plot'
  AND EXISTS (
      SELECT 1 FROM movie_keyword mk JOIN keyword k ON k.id = mk.keyword_id
      WHERE mk.movie_id = t.id AND k.keyword LIKE '%%'
  )
  AND EXISTS (
      SELECT 1 FROM cast_info ci JOIN name n ON n.id = ci.person_id
      WHERE ci.movie_id = t.id AND n.name LIKE '%%' AND n.name NOT LIKE '%%'
  );
