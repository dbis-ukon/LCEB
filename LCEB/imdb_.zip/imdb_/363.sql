SELECT t.id, t.title, n1.name AS Actor1, n2.name AS Actor2, k1.keyword AS Keyword1, k2.keyword AS Keyword2, cn.name AS CompanyName
FROM title t
JOIN cast_info ci1 ON ci1.movie_id = t.id
JOIN name n1 ON n1.id = ci1.person_id
JOIN cast_info ci2 ON ci2.movie_id = t.id AND ci2.person_id <> ci1.person_id
JOIN name n2 ON n2.id = ci2.person_id
JOIN movie_keyword mk1 ON mk1.movie_id = t.id
JOIN keyword k1 ON k1.id = mk1.keyword_id
JOIN movie_keyword mk2 ON mk2.movie_id = t.id AND mk2.keyword_id <> mk1.keyword_id
JOIN keyword k2 ON k2.id = mk2.keyword_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND cn.name NOT LIKE '%%'
  AND mc.company_type_id IN (1, 2, 3)
  AND cn.id > 1000;
