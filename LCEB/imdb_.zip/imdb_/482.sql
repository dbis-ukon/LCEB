SELECT cn.name AS company_name, ct.kind, cn.country_code, COUNT(DISTINCT mc.movie_id) AS movie_count
FROM company_name cn
JOIN movie_companies mc ON AND t.title LIKE '%%'cn.id = mc.company_id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN title t ON mc.movie_id = t.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE cn.name LIKE '%%'
  AND t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.production_year > 1915 AND t.production_year < 2007 AND t.production_year BETWEEN 1962 AND 2010 AND t.kind_id IN (7, 4, 1)
GROUP BY cn.name, ct.kind, cn.country_code
HAVING COUNT(DISTINCT mc.movie_id) > 4;
