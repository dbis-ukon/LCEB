SELECT id, name, name_pcode_cf, name_pcode_nf, surname_pcode
FROM name n
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name_pcode_nf = 'W4526';
