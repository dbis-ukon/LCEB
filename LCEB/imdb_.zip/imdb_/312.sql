SELECT t.title, k.keyword, t.production_year
FROM title t
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.kind_id IN (1, 7, 3, 4)
  AND t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.episode_nr <= 17
ORDER BY t.production_year DESC
LIMIT 100;
