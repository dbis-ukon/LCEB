SELECT
    co.name AS company_name,
    COUNT(DISTINCT cc.movie_id) AS movies_count
FROM complete_cast cc
JOIN title t ON cc.movie_id = t.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE (co.name LIKE '%%' or t.title NOT LIKE '%%')
  AND t.season_nr >= 1
  AND t.episode_nr > 22
GROUP BY co.name
ORDER BY movies_count DESC;
