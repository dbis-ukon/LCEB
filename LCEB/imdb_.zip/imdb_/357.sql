SELECT n.id, n.name
FROM name n
JOIN cast_info ci ON n.id = ci.person_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_keyword mk ON ci.movie_id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE k.keyword LIKE '%%'
  AND n.name LIKE '%%'
  AND n.imdb_id IS NOT NULL AND n.imdb_id > 4750 AND n.name_pcode_nf IS NOT NULL AND ci.role_id IN (8, 10, 2, 9, 3) AND ci.note IS NULL AND ci.note IS NOT NULL
INTERSECT
SELECT n.id, n.name
FROM name n
JOIN cast_info ci ON n.id = ci.person_id
JOIN movie_keyword mk ON ci.movie_id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE k.keyword LIKE '%%';
