SELECT n.name, rt.role, kt.kind, lt.link, COUNT(DISTINCT t.id) AS n_movies
FROM name n
JOIN cast_info ci ON n.id = ci.person_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN title t ON ci.movie_id = t.id
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_link ml ON t.id = ml.movie_id
JOIN link_type lt ON ml.link_type_id = lt.id
WHERE n.name LIKE '%%'
  AND rt.role IN ('costume designer', 'composer', 'guest', 'producer', 'actor')
  AND kt.kind = 'episode'
  AND lt.link LIKE '%%'
  AND ci.nr_order <= 18
  AND t.production_year BETWEEN 1982 AND 2010
  AND n.gender IN ('m', 'f')
GROUP BY n.name, rt.role, kt.kind, lt.link
HAVING COUNT(DISTINCT t.id) >= 2
ORDER BY n_movies DESC;
