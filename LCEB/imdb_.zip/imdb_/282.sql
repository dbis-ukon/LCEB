SELECT t.id, t.title, mi.info, it.info, k.keyword
FROM title t
JOIN movie_info mi ON mi.movie_id = t.id
JOIN info_type it ON it.id = mi.info_type_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND mi.info LIKE '%%'
  AND mi.info NOT LIKE '%%'
  AND it.info LIKE '%%'
  AND it.info NOT LIKE '%%'
  AND k.keyword LIKE '%%'
  AND k.keyword NOT LIKE '%%'
  AND t.production_year BETWEEN 2010 AND 2013
  AND mi.info_type_id > 3
  AND mk.keyword_id > 263
  AND t.kind_id IN (1, 7, 3);
