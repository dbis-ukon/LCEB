SELECT t.id, t.title, mii.info AS rating_value, k.keyword, kt.kind, n.name AS actor_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_info_idx mii ON t.id = mii.movie_id
JOIN info_type it ON mii.info_type_id = it.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE t.title LIKE '%%'
  AND t.title LIKE '%%'
  AND it.info = 'book'
  AND k.keyword LIKE '%%'
  AND ci.note IS NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND t.kind_id IN (4, 3, 7, 1) AND t.season_nr >= 2 AND t.episode_nr <= 29 AND t.episode_of_id IS NULL;
