SELECT t.title, rt.role, COUNT(DISTINCT ci.person_id) AS roles
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN role_type rt ON rt.id = ci.role_id
WHERE (t.title LIKE '%%' or t.title NOT LIKE '%%')
  AND rt.role LIKE '%%'
  AND ci.nr_order <= 4
  AND t.production_year >= 2011
  AND t.kind_id IN (3, 1, 4, 7)
GROUP BY t.title, rt.role
ORDER BY roles DESC;
