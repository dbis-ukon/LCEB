SELECT t.id, t.title, cn.name AS character_name, rt.role, k.keyword, it.info AS info_type, mi.info AS info_value
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN char_name cn ON ci.person_role_id = cn.id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN movie_info mi ON t.id = mi.movie_id
JOIN info_type it ON mi.info_type_id = it.id
WHERE t.title LIKE '%%'
  AND cn.name NOT LIKE '%%'
  AND cn.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL AND t.phonetic_code IS NOT NULL AND t.imdb_id IS NOT NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND ci.nr_order <= 5 AND cn.surname_pcode IS NOT NULL AND cn.md5sum IS NOT NULL AND k.phonetic_code IS NOT NULL AND k.id > 82301;
