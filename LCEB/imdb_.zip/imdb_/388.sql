SELECT cn.name AS character_name, kt.kind, rt.role, COUNT(DISTINCT ci.movie_id) AS appearances
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN role_type rt ON ci.role_id = rt.id
JOIN title t ON t.id = ci.movie_id
JOIN kind_type kt ON t.kind_id = kt.id
WHERE cn.name LIKE '%%'
  AND t.production_year BETWEEN 1938 AND 1952 AND t.kind_id IN (4, 1, 7) AND t.season_nr >= 1 AND t.episode_nr <= 921 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 16 AND 21 AND ci.role_id IN (3, 8, 10, 1, 2) AND cn.surname_pcode IS NOT NULL AND cn.md5sum IS NOT NULL
GROUP BY cn.name, kt.kind, rt.role
ORDER BY appearances DESC;
