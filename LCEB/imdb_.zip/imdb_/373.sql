SELECT t.title, n.name, k.keyword, t.production_year
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE k.phonetic_code IS NOT NULL
  AND ci.role_id IN (2, 1, 11, 8, 4)
  AND n.gender = 'm'
  AND k.keyword NOT LIKE '%%'
  AND (t.title LIKE '%%' OR n.name LIKE '%%')
  AND t.episode_nr <= 15
ORDER BY t.production_year DESC
LIMIT 200;
