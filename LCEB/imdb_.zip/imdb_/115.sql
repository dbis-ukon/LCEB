SELECT t.id AS item_id, 'title' AS source, t.title AS matched_text
FROM title t
WHERE t.title LIKE '%%'
  AND t.production_year BETWEEN 1961 AND 1998 AND t.kind_id IN (1, 4, 7, 2) AND t.season_nr >= 1 AND t.episode_nr <= 1
UNION
SELECT akat.id AS item_id, 'aka_title' AS source, akat.title AS matched_text
FROM aka_title akat
WHERE akat.title LIKE '%%'
  AND akat.kind_id IN (4, 1, 6, 3, 2) AND akat.season_nr >= 1 AND akat.episode_nr <= 1 AND akat.episode_of_id IS NULL;
