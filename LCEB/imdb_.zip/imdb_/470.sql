SELECT t.title, k.keyword, t.production_year
FROM title t
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.kind_id IN (1, 7, 4, 3)
  AND t.season_nr IS NULL
  AND (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND t.production_year BETWEEN 2005 AND 2010
  AND k.keyword NOT LIKE '%%';
