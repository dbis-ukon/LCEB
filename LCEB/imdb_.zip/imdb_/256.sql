SELECT id, name, imdb_id
FROM char_name
WHERE (name LIKE '%Agent%' OR name LIKE '%Spy%')
  AND name NOT LIKE '%Secret Agent%'
  AND name NOT LIKE '%Unknown%'
  AND id BETWEEN 1000 AND 900000;
