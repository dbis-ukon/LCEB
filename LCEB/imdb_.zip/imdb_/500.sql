SELECT id, title, note
FROM aka_title
WHERE (title LIKE '%dark%' OR title LIKE '%black%')
  AND title NOT LIKE '%documentary%'
  AND production_year IS NOT NULL
  AND kind_id <> 0;
