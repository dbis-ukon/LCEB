SELECT id, name, gender
FROM name
WHERE name LIKE '%Smith%'
  AND name NOT LIKE '%William%'
  AND gender IN ('m', 'f')
  AND imdb_id > 0;
