SELECT id, name
FROM char_name
WHERE (name LIKE '%Detective%' OR name LIKE '%Officer%')
  AND name NOT LIKE '%Police%'
  AND id > 0
  AND name <> '';
