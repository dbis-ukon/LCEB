SELECT t.id, t.title, cct1.kind AS subject_kind, cct2.kind AS status_kind, kt.kind, n.name AS actor_name, rt.role
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN complete_cast cc ON t.id = cc.movie_id
JOIN comp_cast_type cct1 ON cc.subject_id = cct1.id
JOIN comp_cast_type cct2 ON cc.status_id = cct2.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN role_type rt ON ci.role_id = rt.id
WHERE t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND n.name NOT LIKE '%%'
  AND cc.status_id IS NOT NULL AND ci.nr_order <= 36 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 5 AND 19 AND t.production_year > 1967 AND t.production_year < 2006 AND t.production_year BETWEEN 2004 AND 2011 AND t.kind_id IN (4, 3, 7, 1);
