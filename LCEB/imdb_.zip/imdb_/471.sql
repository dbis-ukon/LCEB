SELECT n.id, n.name, akat.title, kt.kind, rt.role
FROM name n
JOIN aka_title akat ON n.imdb_id = akat.movie_id
JOIN kind_type kt ON akat.kind_id = kt.id
JOIN cast_info ci ON ci.person_id = n.id AND ci.movie_id = akat.movie_id
JOIN role_type rt ON ci.role_id = rt.id
WHERE n.name LIKE '%%'
  AND n.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL AND n.gender = 'm' AND akat.md5sum IS NOT NULL AND akat.phonetic_code IS NOT NULL AND akat.imdb_id IS NOT NULL AND akat.series_years IS NOT NULL AND ci.role_id IN (3, 10, 9, 4, 2) AND ci.note IS NULL AND ci.note IS NOT NULL;
