SELECT id, title
FROM title
WHERE title LIKE '%dream%'
  AND title NOT LIKE '%dreamland%'
  AND title NOT LIKE '%dreamer%'
  AND production_year > 1970;
