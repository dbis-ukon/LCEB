SELECT t.title, COUNT(DISTINCT k.id) AS keywords
FROM title t
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.production_year BETWEEN 1950 AND 2010
  AND t.kind_id IN (1, 7, 4)
GROUP BY t.title
ORDER BY keywords DESC;
