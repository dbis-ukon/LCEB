SELECT t.id,
       t.title,
       n.name,
       cn.name AS company_name,
       ch.name AS character_name,
       k.keyword
FROM title t
JOIN cast_info ci
  ON ci.movie_id = t.id
JOIN name n
  ON n.id = ci.person_id
JOIN char_name ch
  ON ch.id = ci.person_role_id
JOIN movie_companies mc
  ON mc.movie_id = t.id
JOIN company_name cn
  ON cn.id = mc.company_id
JOIN movie_keyword mk
  ON mk.movie_id = t.id
JOIN keyword k
  ON k.id = mk.keyword_id
WHERE n.name LIKE '%%'
  AND ch.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.title LIKE '%%'
  AND t.production_year > 1989
  AND ci.role_id = 1
  AND mc.company_type_id IN (1, 2)
  AND t.kind_id = 2;
