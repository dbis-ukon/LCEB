SELECT id, name, gender
FROM name
WHERE (name LIKE '%John%' OR name LIKE '%James%')
  AND name NOT LIKE '%Jr.%'
  AND gender IS NOT NULL
  AND id > 1000;
