SELECT t.id, t.title, k.keyword, ak.title
FROM title t
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
JOIN aka_title ak ON ak.movie_id = t.id
WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND k.keyword NOT LIKE '%%'
  AND t.title LIKE '%%'
  AND t.title NOT LIKE '%%'
  AND ak.title LIKE '%%'
  AND ak.title NOT LIKE '%%'
  AND t.production_year >= 1995
  AND t.production_year < 2011
  AND mk.keyword_id BETWEEN 231 AND 1381
  AND ak.id > 359301
  AND ak.kind_id > 1;
