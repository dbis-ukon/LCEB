SELECT t.id AS item_id, 'title' AS source, t.title AS matched_text
FROM title t
WHERE t.title LIKE '%%'
  AND t.production_year < 2004 AND t.production_year BETWEEN 1938 AND 2003 AND t.kind_id IN (7, 6, 1, 4) AND t.season_nr >= 2
UNION
SELECT akat.id AS item_id, 'aka_title' AS source, akat.title AS matched_text
FROM aka_title akat
WHERE akat.title LIKE '%%'
  AND akat.production_year BETWEEN 1992 AND 1998 AND akat.kind_id IN (3, 4, 1) AND akat.season_nr >= 11 AND akat.episode_nr <= 1;
