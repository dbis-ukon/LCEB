SELECT id, keyword, phonetic_code
FROM keyword k
WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND k.id BETWEEN 34162 AND 36671
  AND k.phonetic_code IS NOT NULL;
