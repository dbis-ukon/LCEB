SELECT t.id, t.title, kt.kind, n.name AS actor_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE t.title LIKE '%%'
  AND t.title NOT LIKE '%%'
  AND n.name LIKE '%%'
  AND t.episode_nr <= 59 AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL AND ci.person_role_id IS NOT NULL AND ci.nr_order <= 5 AND ci.nr_order IS NOT NULL AND n.name_pcode_nf IS NOT NULL AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL
  AND NOT EXISTS (
      SELECT 1 FROM aka_title akat WHERE akat.movie_id = t.id
  );
