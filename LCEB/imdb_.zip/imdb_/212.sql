SELECT t1.title AS TitleA, t2.title AS TitleB, k.keyword
FROM movie_link ml1
JOIN movie_link ml2 ON ml1.movie_id = ml2.linked_movie_id AND ml1.linked_movie_id = ml2.movie_id
JOIN title t1 ON t1.id = ml1.movie_id
JOIN title t2 ON t2.id = ml1.linked_movie_id
JOIN movie_keyword mk ON mk.movie_id = t1.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE (t1.title LIKE '%%' OR t1.title LIKE '%%')
  AND t2.title LIKE '%%'
  AND k.keyword LIKE '%%';
