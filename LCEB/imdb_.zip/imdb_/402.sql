SELECT n.name, n.gender, COUNT(DISTINCT t.id) AS movies
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN person_info pi ON n.id = pi.person_id
WHERE t.title LIKE '%%'
  AND t.episode_nr <= 261
  AND ci.nr_order <= 25
  AND n.gender = 'f'
  AND t.kind_id = 7
  AND t.production_year < 2002
  AND (n.name LIKE '%%' OR n.name LIKE '%%')
GROUP BY n.name, n.gender
HAVING COUNT(DISTINCT t.id) > 1
ORDER BY movies DESC;
