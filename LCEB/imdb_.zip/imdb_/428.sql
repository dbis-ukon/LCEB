SELECT akat.movie_id, akat.title, COUNT(DISTINCT k.keyword) AS num_keywords, MIN(akat.production_year) AS first_year
FROM aka_title akat
JOIN movie_keyword mk ON akat.movie_id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE akat.title LIKE '%%'
  AND (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND k.keyword NOT LIKE '%%'
GROUP BY akat.movie_id, akat.title
HAVING COUNT(DISTINCT k.keyword) > 1
ORDER BY num_keywords DESC;
