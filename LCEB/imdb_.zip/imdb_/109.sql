SELECT n.id, n.name AS real_name, an.name AS aka_name, t.title, kt.kind
FROM name n
JOIN aka_name an ON an.person_id = n.id
JOIN cast_info ci ON n.id = ci.person_id
JOIN title t ON ci.movie_id = t.id
JOIN kind_type kt ON t.kind_id = kt.id
WHERE n.name LIKE '%%'
  AND t.title LIKE '%%'
  AND n.name_pcode_nf IS NOT NULL AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL AND ci.note IS NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL AND t.phonetic_code IS NOT NULL;
