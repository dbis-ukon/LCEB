SELECT t.id, cn.name, n.gender
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN char_name cn ON ci.person_role_id = cn.id
JOIN name n ON ci.person_id = n.id
WHERE EXISTS (
    SELECT 1
    FROM movie_keyword mk
    JOIN keyword k ON mk.keyword_id = k.id
    WHERE mk.movie_id = t.id AND k.keyword LIKE '%%'
)
  AND cn.name LIKE '%%'
  AND n.name LIKE '%%'
  AND n.gender = 'f'
  AND ci.nr_order <= 13
  AND t.production_year >= 1982;
