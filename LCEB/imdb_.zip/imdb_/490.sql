SELECT n.id, n.name, an.name AS AkaName, it.info AS InfoCategory, pi.info AS Details
FROM name n
JOIN aka_name an ON an.person_id = n.id
JOIN person_info pi ON pi.person_id = n.id
JOIN info_type it ON it.id = pi.info_type_id
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name NOT LIKE '%%'
  AND n.name_pcode_nf IS NOT NULL AND n.gender = 'f';
