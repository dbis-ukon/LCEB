SELECT t.id, co.name
FROM title t
JOIN aka_title akat ON t.id = akat.movie_id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN char_name cn ON ci.person_role_id = cn.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE k.keyword LIKE '%%'
  AND t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND co.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND t.production_year BETWEEN 1993 AND 2011
  AND ci.nr_order < 28
  AND mc.company_id > 16708
  AND t.kind_id = 1;
