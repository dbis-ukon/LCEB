SELECT id, name
FROM company_name
WHERE (name LIKE '%film%' OR name LIKE '%studio%')
  AND name NOT LIKE '%production%'
  AND id BETWEEN 1 AND 100000
  AND country_code <> '';
