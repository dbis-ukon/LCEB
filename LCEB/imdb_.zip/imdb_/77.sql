SELECT t.id, t.title, n.name AS ActorName, k.keyword
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND (n.name LIKE '%%' OR n.name LIKE '%%')
  AND (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND t.production_year > (SELECT AVG(production_year) FROM title WHERE production_year IS NOT NULL);
