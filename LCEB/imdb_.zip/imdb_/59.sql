SELECT id, title
FROM aka_title
WHERE (title LIKE '%fire%' OR title LIKE '%water%')
  AND title NOT LIKE '%fireplace%'
  AND kind_id <> 0
  AND production_year IS NOT NULL;
