SELECT akat.movie_id, akat.title, COUNT(DISTINCT ci.person_id) AS cast_count, MIN(akat.episode_nr) AS first_episode, MAX(akat.episode_nr) AS last_episode
FROM aka_title akat
JOIN cast_info ci ON akat.movie_id = ci.movie_id
JOIN char_name cn ON ci.person_id = cn.id
JOIN movie_companies mc ON akat.movie_id = mc.movie_id
JOIN company_name c ON mc.company_id = c.id
JOIN movie_keyword mk ON akat.movie_id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE akat.title LIKE '%%'
  AND cn.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND c.name LIKE '%%'
  AND ci.nr_order <= 4
  AND akat.production_year BETWEEN 1958 AND 1977
  AND akat.episode_nr BETWEEN 1 AND 17
GROUP BY akat.movie_id, akat.title
ORDER BY cast_count DESC;
