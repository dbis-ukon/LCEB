SELECT t.id, t.title, n.name, ch.name, pi.info
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN char_name ch ON ch.id = ci.person_role_id
JOIN person_info pi ON pi.person_id = n.id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND n.name LIKE '%%'
  AND n.name NOT LIKE '%%'
  AND ch.name LIKE '%%'
  AND ch.name NOT LIKE '%%'
  AND pi.info LIKE '%%'
  AND pi.info NOT LIKE '%%'
  AND t.production_year BETWEEN 1973 AND 1996
  AND ci.nr_order BETWEEN 2 AND 27
  AND ci.role_id > 1
  AND n.gender IS NOT NULL
  AND pi.info_type_id > 20;
