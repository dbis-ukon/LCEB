SELECT t.id, t.title, kt.kind, n.name AS actor_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND t.series_years IS NOT NULL AND t.production_year > 1957 AND t.production_year < 1987 AND t.production_year BETWEEN 1900 AND 1999 AND ci.nr_order <= 21 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 2 AND 3 AND n.name_pcode_nf IS NOT NULL AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL
  AND NOT EXISTS (
      SELECT 1 FROM aka_title akat WHERE akat.movie_id = t.id
  );
