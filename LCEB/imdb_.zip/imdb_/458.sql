SELECT id, keyword, phonetic_code
FROM keyword
WHERE (keyword LIKE '%mystery%' OR keyword LIKE '%secret%')
  AND keyword NOT LIKE '%secret agent%'
  AND id > 0
  AND keyword <> '';
