SELECT cn.name AS character_name, n.name AS actor_name, co.name AS company_name, rt.role,
       COUNT(DISTINCT t.id) AS movies, COUNT(DISTINCT mk.keyword_id) AS keyword_count
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN name n ON n.id = ci.person_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN title t ON t.id = ci.movie_id
JOIN kind_type kt ON kt.id = t.kind_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name co ON co.id = mc.company_id
JOIN company_type ct ON ct.id = mc.company_type_id
JOIN movie_keyword mk ON mk.movie_id = t.id
WHERE cn.name LIKE '%%'
  AND n.name LIKE '%%'
  AND co.name LIKE '%%'
  AND ct.kind IN ('distributors', 'production companies', 'special effects companies', 'miscellaneous companies')
  AND rt.role IN ('actress', 'writer', 'cinematographer', 'production designer', 'costume designer')
  AND ci.nr_order <= 1
  AND mc.note IS NOT NULL
GROUP BY cn.name, n.name, co.name, rt.role
HAVING COUNT(DISTINCT mk.keyword_id) >= 1
ORDER BY movies DESC;
