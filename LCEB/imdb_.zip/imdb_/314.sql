SELECT id, keyword
FROM keyword
WHERE (keyword LIKE '%death%' OR keyword LIKE '%murder%')
  AND keyword NOT LIKE '%accidental%'
  AND id > 0
  AND phonetic_code IS NOT NULL;
