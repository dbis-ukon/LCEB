SELECT id, name, gender, imdb_index
FROM name n
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name LIKE '%%'
  AND n.surname_pcode LIKE '%%';
