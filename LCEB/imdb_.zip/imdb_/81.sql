SELECT n.name, cn.name AS char_name, a.title, k.keyword
FROM name n
JOIN cast_info ci ON n.id = ci.person_id
JOIN char_name cn ON ci.person_id = cn.id
JOIN aka_title a ON ci.movie_id = a.movie_id
JOIN movie_keyword mk ON a.movie_id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE n.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND a.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND a.production_year BETWEEN 1935 AND 1997
  AND ci.nr_order <= 4
  AND cn.name_pcode_nf IS NOT NULL;
