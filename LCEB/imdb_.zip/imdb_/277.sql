SELECT t1.title AS source_title, t2.title AS related_title, lt.link, kt1.kind AS kind1, kt2.kind AS kind2, n.name AS actor_name
FROM title t1
JOIN kind_type kt1 ON t1.kind_id = kt1.id
JOIN movie_link ml ON t1.id = ml.movie_id
JOIN title t2 ON ml.linked_movie_id = t2.id
JOIN kind_type kt2 ON t2.kind_id = kt2.id
JOIN link_type lt ON ml.link_type_id = lt.id
JOIN cast_info ci ON t1.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE t1.title LIKE '%%'
  AND t2.title NOT LIKE '%%'
  AND n.name LIKE '%%'
  AND lt.link = 'followed by'
  AND t1.production_year > 2003 AND t1.production_year < 2008 AND t1.production_year BETWEEN 1955 AND 2011 AND t1.kind_id IN (1, 3, 4, 7) AND ci.nr_order BETWEEN 19 AND 29 AND ci.role_id IN (3, 10, 5, 1, 4) AND ci.note IS NULL;
