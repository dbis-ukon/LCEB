SELECT t.id,
       t.title,
       at.title AS alternate_title,
       n.name,
       cn.name AS company_name,
       ch.name AS character_name,
       k.keyword
FROM title t
JOIN aka_title at ON at.movie_id = t.id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN char_name ch ON ch.id = ci.person_role_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE t.title LIKE '%%'
  AND at.title LIKE '%%'
  AND n.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND ch.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.production_year BETWEEN 2011 AND 2012
  AND ci.role_id = 2
  AND mc.company_type_id = 2
  AND t.kind_id = 7;
