SELECT cn.id, cn.name, cn.country_code
FROM company_name cn
JOIN movie_companies mc ON cn.id = mc.company_id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN title t ON mc.movie_id = t.id
WHERE cn.name LIKE '%%'
  AND cn.country_code IS NOT NULL AND cn.imdb_id > 1100 AND cn.imdb_id IS NOT NULL AND mc.company_type_id IN (2, 1) AND mc.note IS NULL
EXCEPT
SELECT cn.id, cn.name, cn.country_code
FROM company_name cn
JOIN movie_companies mc ON cn.id = mc.company_id
JOIN title t ON mc.movie_id = t.id
WHERE t.title LIKE '%%'
  AND t.title LIKE '%%';
