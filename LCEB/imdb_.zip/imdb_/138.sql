SELECT id, name, imdb_id, md5sum
FROM name n
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name LIKE '%%'
  AND (n.gender = 'm' OR n.imdb_id > 1000);
