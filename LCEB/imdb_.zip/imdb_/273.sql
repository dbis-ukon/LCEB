SELECT co.name, COUNT(DISTINCT t.id) AS movie_count, MAX(t.production_year) AS last_year
FROM company_name co
JOIN movie_companies mc ON mc.company_id = co.id
JOIN title t ON t.id = mc.movie_id
WHERE (co.name LIKE '%%' OR co.name LIKE '%%' or t.title LIKE '%%')
  AND t.production_year BETWEEN 1992 AND 1993
GROUP BY co.name
ORDER BY last_year DESC;
