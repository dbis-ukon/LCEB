SELECT t.id, t.title
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN char_name cn ON ci.person_role_id = cn.id
WHERE EXISTS (
    SELECT 1
    FROM movie_keyword mk
    JOIN keyword k ON mk.keyword_id = k.id
    WHERE mk.movie_id = t.id
      AND k.keyword LIKE '%%'
)
  AND n.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND ci.nr_order <= 36
  AND t.production_year BETWEEN 1962 AND 1967;
