SELECT id, title
FROM title
WHERE title LIKE '%house%'
  AND title NOT LIKE '%haunted%'
  AND title NOT LIKE '%white house%'
  AND production_year > 1990;
