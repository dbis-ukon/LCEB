SELECT id, name
FROM char_name
WHERE name LIKE '%Detective%'
  AND name NOT LIKE '%Young Detective%'
  AND name NOT LIKE '%Police Detective%'
  AND id > 0;
