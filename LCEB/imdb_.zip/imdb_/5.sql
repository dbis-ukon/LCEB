SELECT t.id, t.title, mii.info AS rating_value, k.keyword, kt.kind, n.name AS actor_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_info_idx mii ON t.id = mii.movie_id
JOIN info_type it ON mii.info_type_id = it.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE t.title LIKE '%%'
  AND it.info = 'printed media reviews'
  AND k.keyword LIKE '%%'
  AND ci.nr_order BETWEEN 3 AND 7 AND ci.role_id IN (10, 4, 1, 9, 2) AND ci.note IS NULL AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL AND t.phonetic_code IS NOT NULL;
