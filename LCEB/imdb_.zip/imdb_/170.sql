SELECT cn.name, rt.role, t.title, COUNT(DISTINCT ci.movie_id) AS role_count
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN role_type rt ON rt.id = ci.role_id
JOIN title t ON t.id = ci.movie_id
WHERE cn.name LIKE '%%'
  AND rt.role LIKE '%%'
  AND t.title LIKE '%%'
  AND ci.nr_order <= 45
  AND t.production_year >= 2007
GROUP BY cn.name, rt.role, t.title
ORDER BY role_count DESC;
