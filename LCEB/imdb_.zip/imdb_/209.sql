SELECT id, name, gender, md5sum
FROM name n
WHERE n.name LIKE '%%'
  AND n.name NOT LIKE '%%'
  AND n.gender = 'm'
  AND n.md5sum IS NOT NULL;
