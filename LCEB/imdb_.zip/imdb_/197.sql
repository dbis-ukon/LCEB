SELECT t.title, n.name, k.keyword, t.production_year
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE (t.title LIKE '%%' OR n.name LIKE '%%')
  AND t.kind_id IN (1, 7)
  AND k.keyword NOT LIKE '%%'
  AND t.episode_nr <= 261
  AND n.gender = 'm'
  AND ci.role_id IN (1, 10, 9, 11, 3)
ORDER BY t.production_year DESC
LIMIT 200;
