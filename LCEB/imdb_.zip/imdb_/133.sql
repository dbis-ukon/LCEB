SELECT t1.title AS level1, t2.title AS level2, t3.title AS level3, kt1.kind, kt2.kind, kt3.kind
FROM title t1
JOIN kind_type kt1 ON t1.kind_id = kt1.id
JOIN movie_link ml1 ON t1.id = ml1.movie_id
JOIN link_type lt1 ON ml1.link_type_id = lt1.id
JOIN title t2 ON ml1.linked_movie_id = t2.id
JOIN kind_type kt2 ON t2.kind_id = kt2.id
JOIN movie_link ml2 ON t2.id = ml2.movie_id
JOIN link_type lt2 ON ml2.link_type_id = lt2.id
JOIN title t3 ON ml2.linked_movie_id = t3.id
JOIN kind_type kt3 ON t3.kind_id = kt3.id
WHERE t1.title LIKE '%%'
  AND t3.title NOT LIKE '%%'
  AND t3.title NOT LIKE '%%'
  AND t1.production_year BETWEEN 1958 AND 2011 AND t1.kind_id IN (4, 3, 7, 1) AND t1.season_nr >= 5 AND t1.episode_nr <= 4;
