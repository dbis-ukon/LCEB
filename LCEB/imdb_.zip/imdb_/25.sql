SELECT a.title, COUNT(DISTINCT co.id) AS companies
FROM aka_title a
JOIN movie_companies mc ON mc.movie_id = a.movie_id
JOIN company_name co ON co.id = mc.company_id
WHERE a.title LIKE '%%' 
  AND co.name LIKE '%%'
  AND co.country_code = '[in]'
  AND mc.note LIKE '%%'
  AND a.production_year BETWEEN 1951 AND 1955
GROUP BY a.title
ORDER BY companies DESC;
