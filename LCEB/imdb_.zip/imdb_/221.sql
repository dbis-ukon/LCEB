SELECT n.id, n.name, akat.title, kt.kind, rt.role
FROM name n
JOIN aka_title akat ON n.imdb_id = akat.movie_id
JOIN kind_type kt ON akat.kind_id = kt.id
JOIN cast_info ci ON ci.person_id = n.id AND ci.movie_id = akat.movie_id
JOIN role_type rt ON ci.role_id = rt.id
WHERE ( n.name LIKE '%%' OR  akat.title LIKE '%%')
  AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL AND n.gender = 'm' AND akat.production_year BETWEEN 1961 AND 1994 AND akat.kind_id IN (1, 3, 4, 2) AND akat.season_nr >= 1 AND akat.episode_nr <= 4 AND ci.note IS NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL;
