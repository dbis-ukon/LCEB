SELECT id, keyword, phonetic_code
FROM keyword k
WHERE k.keyword LIKE '%%'
  AND k.id > 7156
  AND k.phonetic_code LIKE '%%';
