SELECT id, title
FROM title
WHERE (title LIKE '%love%' OR title LIKE '%life%')
  AND title NOT LIKE '%dead%'
  AND production_year BETWEEN 1990 AND 2020
  AND id > 1000;
