SELECT n1.name AS director, n2.name AS actor, kt.kind, k.keyword, COUNT(DISTINCT t.id) AS n_collabs
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci1 ON t.id = ci1.movie_id
JOIN role_type rt1 ON ci1.role_id = rt1.id
JOIN name n1 ON ci1.person_id = n1.id
JOIN cast_info ci2 ON t.id = ci2.movie_id
JOIN role_type rt2 ON ci2.role_id = rt2.id
JOIN name n2 ON ci2.person_id = n2.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE rt1.role = 'composer'
  AND rt2.role IN ('costume designer', 'editor', 'writer', 'actor', 'composer')
  AND t.title LIKE '%%'
  AND n1.name LIKE '%%'
  AND n2.name LIKE '%%'
  AND k.keyword LIKE '%%'
GROUP BY n1.name, n2.name, kt.kind, k.keyword
HAVING COUNT(DISTINCT t.id) >= 3;
