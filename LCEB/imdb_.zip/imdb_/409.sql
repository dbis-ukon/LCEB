SELECT id, title
FROM aka_title
WHERE (title LIKE '%road%' OR title LIKE '%street%')
  AND title NOT LIKE '%road trip%'
  AND production_year IS NOT NULL
  AND id > 500;
