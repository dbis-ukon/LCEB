SELECT cn.name AS character_name, n.name AS actor_name, co.name AS company_name, k.keyword, rt.role,
       COUNT(DISTINCT t.id) AS movies, COUNT(DISTINCT cc.id) AS cast_records
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN name n ON n.id = ci.person_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN title t ON t.id = ci.movie_id
JOIN kind_type kt ON kt.id = t.kind_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name co ON co.id = mc.company_id
JOIN company_type ct ON ct.id = mc.company_type_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
JOIN complete_cast cc ON cc.movie_id = t.id
WHERE cn.name LIKE '%%'
  AND n.name LIKE '%%'
  AND co.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND ct.kind IN ('special effects companies', 'distributors', 'production companies', 'miscellaneous companies')
  AND rt.role IN ('producer', 'guest', 'actor', 'writer', 'costume designer')
  AND kt.kind IN ('movie', 'tv movie', 'video game', 'tv mini series', 'tv series')
  AND ci.nr_order <= 8
  AND t.production_year BETWEEN 1961 AND 1996
  AND co.country_code = '[nl]'
GROUP BY cn.name, n.name, co.name, k.keyword, rt.role
HAVING COUNT(DISTINCT t.id) >= 1
ORDER BY movies DESC, cast_records DESC;
