SELECT t.id, t.title, rt.role, it.info AS info_type, mi.info, cn.name AS company_name
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_info mi ON t.id = mi.movie_id
JOIN info_type it ON mi.info_type_id = it.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE t.title LIKE '%%'
  AND t.title LIKE '%%'
  AND rt.role = 'actress'
  AND cn.name LIKE '%%'
  AND ci.nr_order BETWEEN 1 AND 20 AND ci.role_id IN (8, 3, 6, 10, 4) AND ci.note IS NULL AND t.kind_id IN (4, 1, 7, 6) AND t.season_nr >= 15 AND t.episode_nr <= 29 AND t.episode_of_id IS NULL AND cn.country_code = '[us]' AND cn.country_code IS NOT NULL AND cn.imdb_id > 2600;
