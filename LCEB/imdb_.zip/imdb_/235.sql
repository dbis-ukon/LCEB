SELECT t.id, t.title, kt.kind, cn.name AS company_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE t.title LIKE '%%'
  AND t.production_year > (SELECT AVG(production_year) FROM title WHERE production_year IS NOT NULL)
  AND cn.imdb_id IS NOT NULL AND cn.name_pcode_nf IS NOT NULL AND cn.name_pcode_sf IS NOT NULL AND mc.note IS NOT NULL AND mc.company_id > 11313;
