WITH eligible AS (
    SELECT t.id, t.title, t.kind_id
    FROM title t
    WHERE t.title LIKE '%%'
      AND t.series_years IS NOT NULL AND t.production_year > 1983 AND t.production_year < 2006 AND t.production_year BETWEEN 1969 AND 2000
)
SELECT e.id, e.title, kt.kind, n.name AS actor_name, cn.name AS company_name
FROM eligible e
JOIN kind_type kt ON e.kind_id = kt.id
JOIN cast_info ci ON e.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_companies mc ON e.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE n.name LIKE '%%'
  AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 0 AND 14 AND ci.role_id IN (4, 8, 3, 9, 1) AND cn.imdb_id > 2900 AND cn.imdb_id IS NOT NULL AND cn.name_pcode_nf IS NOT NULL;
