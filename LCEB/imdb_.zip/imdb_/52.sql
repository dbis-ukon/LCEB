SELECT a.title, cn.name AS char_name, co.name AS company_name
FROM aka_title a
JOIN cast_info ci ON a.movie_id = ci.movie_id
JOIN char_name cn ON ci.person_id = cn.id
JOIN movie_companies mc ON a.movie_id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE a.title LIKE '%%'
  AND cn.name LIKE '%%'
  AND co.name LIKE '%%'
  AND a.production_year >= 1937
  AND ci.nr_order <= 19
  AND mc.company_type_id IS NOT NULL;
