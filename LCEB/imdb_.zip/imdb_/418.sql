WITH eligible AS (
    SELECT t.id, t.title, t.kind_id
    FROM title t
    WHERE t.title LIKE '%%'
      AND t.production_year < 1998 AND t.production_year BETWEEN 1967 AND 2005 AND t.kind_id IN (7, 4, 1) AND t.season_nr >= 10
)
SELECT e.id, e.title, kt.kind, n.name AS actor_name, cn.name AS company_name
FROM eligible e
JOIN kind_type kt ON e.kind_id = kt.id
JOIN cast_info ci ON e.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_companies mc ON e.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE n.name LIKE '%%'
  AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND ci.nr_order <= 10 AND cn.name_pcode_nf IS NOT NULL AND cn.name_pcode_sf IS NOT NULL AND cn.country_code = '[de]';
