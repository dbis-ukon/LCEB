SELECT id, keyword, phonetic_code
FROM keyword k
WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND k.id BETWEEN 92285 AND 115822;
