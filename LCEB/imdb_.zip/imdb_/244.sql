SELECT t.title, cn1.name AS Company1, cn2.name AS Company2, ct.kind AS CompanyRole
FROM movie_companies mc1
JOIN movie_companies mc2 ON mc1.movie_id = mc2.movie_id AND mc1.company_id <> mc2.company_id
JOIN company_name cn1 ON cn1.id = mc1.company_id
JOIN company_name cn2 ON cn2.id = mc2.company_id
JOIN company_type ct ON ct.id = mc1.company_type_id
JOIN title t ON t.id = mc1.movie_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND (cn1.name LIKE '%%' OR cn1.name LIKE '%%')
  AND cn2.name NOT LIKE '%%'
  AND ct.kind = 'production companies'
  AND t.production_year BETWEEN 1990 AND 2020;
