SELECT id, keyword, phonetic_code
FROM keyword k
WHERE k.keyword LIKE '%%'
  AND k.id < 79203
  AND k.phonetic_code = 'A2516';
