SELECT id, movie_id, title, imdb_index, kind_id, production_year, phonetic_code, episode_of_id, season_nr, episode_nr, note, md5sum
FROM aka_title akat
WHERE (akat.title LIKE '%%' OR akat.title LIKE '%%')
  AND akat.episode_of_id IS NOT NULL
  AND akat.kind_id IN (7, 4, 1, 2, 3);
