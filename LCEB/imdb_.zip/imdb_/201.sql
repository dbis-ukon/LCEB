SELECT id, keyword
FROM keyword
WHERE (keyword LIKE '%summer%' OR keyword LIKE '%winter%')
  AND keyword NOT LIKE '%summer camp%'
  AND id BETWEEN 1 AND 500000
  AND keyword <> '';
