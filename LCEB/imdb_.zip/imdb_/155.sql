SELECT t.id AS ItemId, 'Title' AS SourceType, t.title AS MatchedText
FROM title t
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
UNION
SELECT at.id AS ItemId, 'AkaTitle' AS SourceType, at.title AS MatchedText
FROM aka_title at
WHERE (at.title LIKE '%%' OR at.title LIKE '%%')
UNION
SELECT k.id AS ItemId, 'Keyword' AS SourceType, k.keyword AS MatchedText
FROM keyword k
WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%');
