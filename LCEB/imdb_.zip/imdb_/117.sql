SELECT a.title, n.name, co.name AS company_name
FROM aka_title a
JOIN cast_info ci ON a.movie_id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_companies mc ON a.movie_id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE a.title LIKE '%%'
  AND n.name LIKE '%%'
  AND co.name LIKE '%%'
  AND n.name LIKE '%%'
  AND co.name LIKE '%%'
  AND a.production_year >= 1959
  AND a.season_nr = 1
  AND mc.company_type_id IS NOT NULL;
