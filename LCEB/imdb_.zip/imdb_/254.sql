SELECT t.title, COUNT(DISTINCT k.id) AS num_keywords
FROM title t
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND k.keyword LIKE '%%'
  AND t.production_year BETWEEN 1950 AND 2009
  AND t.kind_id IN (7, 1, 4)
GROUP BY t.title
ORDER BY num_keywords DESC;
