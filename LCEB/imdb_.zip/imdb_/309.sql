SELECT t.id, t.title
FROM title t
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND EXISTS (
      SELECT 1 FROM cast_info ci JOIN name n ON n.id = ci.person_id
      WHERE ci.movie_id = t.id AND n.name LIKE '%%'
  )
  AND EXISTS (
      SELECT 1 FROM movie_keyword mk JOIN keyword k ON k.id = mk.keyword_id
      WHERE mk.movie_id = t.id AND k.keyword LIKE '%%'
  )
  AND EXISTS (
      SELECT 1 FROM movie_companies mc JOIN company_name cn ON cn.id = mc.company_id
      WHERE mc.movie_id = t.id AND cn.name LIKE '%%'
  );
