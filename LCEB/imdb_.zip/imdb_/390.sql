SELECT cn.id, cn.name, cn.imdb_index, cn.imdb_id, cn.name_pcode_nf, cn.surname_pcode, cn.md5sum,
       ci.role_id, akat.production_year
FROM char_name cn
JOIN cast_info ci ON cn.id = ci.person_id
JOIN aka_title akat ON ci.movie_id = akat.movie_id
WHERE (cn.name LIKE '%%' OR cn.name LIKE '%%' OR akat.title NOT LIKE '%%')
  AND cn.imdb_id < 10000
  AND cn.name_pcode_nf = 'F6451'
  AND cn.surname_pcode = 'S6'
  AND akat.production_year BETWEEN 1990 AND 1994;
