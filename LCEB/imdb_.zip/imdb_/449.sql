WITH Eligible AS (
    SELECT t.id, t.title
    FROM title t
    WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
      AND t.season_nr IS NOT NULL AND t.imdb_id IS NOT NULL AND t.phonetic_code IS NOT NULL
),
EligibleKeyworded AS (
    SELECT e.id, e.title
    FROM Eligible e
    JOIN movie_keyword mk ON mk.movie_id = e.id
    JOIN keyword k ON k.id = mk.keyword_id
    WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
)
SELECT ek.id, ek.title, n.name AS ActorName
FROM EligibleKeyworded ek
JOIN cast_info ci ON ci.movie_id = ek.id
JOIN name n ON n.id = ci.person_id
WHERE (n.name LIKE '%%' OR n.name LIKE '%%');
