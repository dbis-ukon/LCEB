SELECT n.name, t.title, t.production_year, pi.info
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN person_info pi ON n.id = pi.person_id
WHERE t.production_year >= 2005
  AND n.name LIKE '%%'
  AND t.season_nr = 2
  AND t.production_year BETWEEN 1990 AND 2008
  AND ci.nr_order <= 4
  AND ci.role_id IN (2, 3, 8, 9, 10)
  AND t.title LIKE '%%'
ORDER BY t.production_year DESC
LIMIT 100;
