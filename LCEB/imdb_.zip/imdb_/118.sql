SELECT t.title, kt.kind, n.name, rt1.role AS role1, rt2.role AS role2
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci1 ON t.id = ci1.movie_id
JOIN role_type rt1 ON ci1.role_id = rt1.id
JOIN cast_info ci2 ON ci1.person_id = ci2.person_id AND ci1.movie_id = ci2.movie_id AND ci1.role_id <> ci2.role_id
JOIN role_type rt2 ON ci2.role_id = rt2.id
JOIN name n ON ci1.person_id = n.id
WHERE (t.title LIKE '%%' OR n.name LIKE '%%')
  AND t.episode_nr <= 4 AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL;
