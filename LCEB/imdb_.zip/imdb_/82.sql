SELECT id, name, gender, surname_pcode
FROM name n
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name LIKE '%%'
  AND n.gender = 'm';
