SELECT t.id AS item_id, 'title' AS source, t.title AS matched_text
FROM title t
WHERE t.title LIKE '%%'
  AND t.production_year > 2008 AND t.production_year < 2011 AND t.production_year BETWEEN 2008 AND 2010 AND t.kind_id IN (1, 4, 3, 7)
UNION
SELECT akat.id AS item_id, 'aka_title' AS source, akat.title AS matched_text
FROM aka_title akat
WHERE akat.title LIKE '%%'
  AND akat.production_year < 2012 AND akat.production_year BETWEEN 1932 AND 1973 AND akat.kind_id IN (1, 3, 7, 4) AND akat.season_nr >= 1;
