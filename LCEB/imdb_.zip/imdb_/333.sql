SELECT id, name, imdb_index
FROM name n
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name LIKE '%%'
  AND n.surname_pcode LIKE '%%'
  AND n.imdb_id > 5000;
