SELECT k1.keyword AS keyword_a, k2.keyword AS keyword_b, COUNT(DISTINCT t.id) AS shared_movies
FROM keyword k1
JOIN movie_keyword mk1 ON k1.id = mk1.keyword_id
JOIN movie_keyword mk2 ON mk1.movie_id = mk2.movie_id AND mk1.keyword_id <> mk2.keyword_id
JOIN keyword k2 ON mk2.keyword_id = k2.id
JOIN title t ON mk1.movie_id = t.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE k1.keyword LIKE '%%'
  AND k2.keyword NOT LIKE '%%'
  AND co.country_code = '[in]'
  AND t.production_year >= 2007
GROUP BY k1.keyword, k2.keyword
HAVING COUNT(DISTINCT t.id) >= 2
ORDER BY shared_movies DESC;
