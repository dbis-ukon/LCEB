SELECT t.title, n.name, k.keyword, t.production_year
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.production_year BETWEEN 2007 AND 2008
  AND k.keyword LIKE '%%'
  AND n.gender = 'm'
  AND ci.role_id IN (1, 3, 2, 10, 4)
  AND (t.title LIKE '%%''ll%ke You to _un_h' OR n.name LIKE '%%')
ORDER BY t.production_year DESC
LIMIT 200;
