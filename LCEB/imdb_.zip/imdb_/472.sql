SELECT
    n.name,
    COUNT(DISTINCT co.id) AS companies_worked
FROM name n
JOIN cast_info ci ON n.id = ci.person_id
JOIN movie_companies mc ON mc.movie_id = ci.movie_id
JOIN company_name co ON co.id = mc.company_id
WHERE (n.name LIKE '%%' OR co.name LIKE '%%')
  AND n.gender = 'm'
  AND mc.note LIKE '%%'
  AND co.country_code = '[it]'
GROUP BY n.name
ORDER BY companies_worked DESC;
