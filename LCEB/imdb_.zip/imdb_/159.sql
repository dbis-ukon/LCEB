SELECT k1.keyword AS keyword1, k2.keyword AS keyword2, t.title, kt.kind, COUNT(DISTINCT mc.company_id) AS n_companies
FROM keyword k1
JOIN movie_keyword mk1 ON k1.id = mk1.keyword_id
JOIN movie_keyword mk2 ON mk1.movie_id = mk2.movie_id AND mk1.keyword_id <> mk2.keyword_id
JOIN keyword k2 ON mk2.keyword_id = k2.id
JOIN title t ON mk1.movie_id = t.id
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_companies mc ON t.id = mc.movie_id
WHERE k1.keyword LIKE '%%'
  AND k2.keyword NOT LIKE '%%'
  AND t.title LIKE '%%'
  AND t.production_year < 1999 AND t.production_year BETWEEN 1954 AND 2004 AND t.kind_id IN (7, 4, 1) AND t.season_nr >= 1 AND mc.note IS NOT NULL AND mc.company_id > 707
GROUP BY k1.keyword, k2.keyword, t.title, kt.kind
HAVING COUNT(DISTINCT mc.company_id) >= 2;
