SELECT cn.name AS company_name, ct.kind, cn.country_code, COUNT(DISTINCT mc.movie_id) AS movie_count
FROM company_name cn
JOIN movie_companies mc ON cn.id = mc.company_id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN title t ON mc.movie_id = t.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE cn.name LIKE '%%'
  AND t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.production_year BETWEEN 1958 AND 2010 AND t.kind_id IN (3, 7, 1, 4) AND t.season_nr >= 2 AND t.episode_nr <= 230
GROUP BY cn.name, ct.kind, cn.country_code
HAVING COUNT(DISTINCT mc.movie_id) > 0;
