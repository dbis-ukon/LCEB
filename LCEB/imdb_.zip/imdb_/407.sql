SELECT id, keyword
FROM keyword
WHERE (keyword LIKE '%hospital%' OR keyword LIKE '%doctor%')
  AND keyword NOT LIKE '%hospital doctor%'
  AND id BETWEEN 1 AND 999999
  AND keyword <> '';
