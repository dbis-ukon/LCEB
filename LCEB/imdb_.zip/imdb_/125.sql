SELECT id, name, imdb_index, imdb_id, name_pcode_nf, surname_pcode, md5sum
FROM char_name cn
WHERE (cn.name LIKE '%%' OR cn.name LIKE '%%')
  AND cn.md5sum LIKE '%%'
  AND cn.name_pcode_nf = 'J2452';
