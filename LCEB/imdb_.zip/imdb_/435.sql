SELECT n.id, n.name, it.info AS info_category, pi.info AS details, t.title, kt.kind
FROM name n
JOIN person_info pi ON n.id = pi.person_id
JOIN info_type it ON pi.info_type_id = it.id
JOIN cast_info ci ON n.id = ci.person_id
JOIN title t ON ci.movie_id = t.id
JOIN kind_type kt ON t.kind_id = kt.id
WHERE n.name LIKE '%%'
  AND n.name LIKE '%%'
  AND t.title LIKE '%%'
  AND it.info = 'pictorial'
  AND n.name_pcode_nf IS NOT NULL AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 1 AND 6 AND ci.role_id IN (1, 8, 3, 4, 10) AND t.series_years IS NOT NULL AND t.production_year > 1963 AND t.production_year < 2007 AND t.production_year BETWEEN 1990 AND 2009;
