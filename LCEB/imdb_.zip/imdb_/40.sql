SELECT n.id, n.name, t.title, ch.name AS character_name
FROM name n
JOIN cast_info ci ON ci.person_id = n.id
JOIN title t ON t.id = ci.movie_id
JOIN char_name ch ON ch.id = ci.person_role_id
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name NOT LIKE '%%'
  AND ch.name LIKE '%%'
  AND ch.name NOT LIKE '%%'
  AND t.title LIKE '%%'
  AND t.title NOT LIKE '%%'
  AND n.id > 1140069
  AND ci.nr_order IS NOT NULL
  AND ci.nr_order <= 11
  AND ci.role_id > 1
  AND t.production_year BETWEEN 2003 AND 2004;
