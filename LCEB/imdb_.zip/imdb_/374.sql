SELECT id, title
FROM aka_title
WHERE (title LIKE '%american%' OR title LIKE '%america%')
  AND title NOT LIKE '%american idol%'
  AND production_year BETWEEN 1950 AND 2020
  AND id > 0;
