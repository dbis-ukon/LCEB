SELECT id, title
FROM title
WHERE (title LIKE '%summer%' OR title LIKE '%winter%')
  AND title NOT LIKE '%summer camp%'
  AND production_year BETWEEN 1960 AND 2020
  AND episode_of_id IS NULL;
