SELECT
    akat.title,
    COUNT(DISTINCT ci.person_id) AS main_cast,
    COUNT(DISTINCT k.id) AS keywords
FROM aka_title akat
JOIN title t           ON akat.movie_id = t.id
JOIN cast_info ci      ON t.id = ci.movie_id
JOIN name n            ON ci.person_id = n.id
JOIN movie_keyword mk  ON t.id = mk.movie_id
JOIN keyword k         ON mk.keyword_id = k.id
WHERE n.gender = 'm'
  AND ci.nr_order BETWEEN 10 AND 27
  AND akat.title LIKE '%%'
  AND t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND n.name LIKE '%%'
GROUP BY akat.title
ORDER BY main_cast DESC;
