SELECT cn.name AS character_name, n.name AS actor_name, co.name AS company_name, k.keyword, rt.role,
       COUNT(DISTINCT t.id) AS movies
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN name n ON n.id = ci.person_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN title t ON t.id = ci.movie_id
JOIN kind_type kt ON kt.id = t.kind_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name co ON co.id = mc.company_id
JOIN company_type ct ON ct.id = mc.company_type_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE cn.name LIKE '%%'
  AND n.name LIKE '%%'
  AND co.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND ct.kind = 'miscellaneous companies'
  AND rt.role = 'composer'
  AND kt.kind = 'movie'
  AND ci.nr_order <= 16
  AND t.production_year >= 2008
GROUP BY cn.name, n.name, co.name, k.keyword, rt.role
HAVING COUNT(DISTINCT t.id) >= 1
ORDER BY movies DESC;
