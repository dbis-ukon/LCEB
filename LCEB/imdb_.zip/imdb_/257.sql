SELECT t.id, t.title, kt.kind, n.name AS actor_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE (t.title LIKE '%%' OR  n.name LIKE '%%')
  AND t.production_year > 1982 AND t.production_year < 2010 AND t.production_year BETWEEN 1984 AND 1991 AND t.kind_id IN (4, 1, 7, 3) AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 2 AND 7 AND ci.role_id IN (1, 8, 10, 2, 3) AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL AND n.gender = 'f'
  AND NOT EXISTS (
      SELECT 1 FROM aka_title akat WHERE akat.movie_id = t.id
  );
