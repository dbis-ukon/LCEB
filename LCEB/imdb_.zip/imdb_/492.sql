SELECT id, title
FROM aka_title
WHERE (title LIKE '%gold%' OR title LIKE '%silver%')
  AND title NOT LIKE '%golden%old%'
  AND production_year >= 1960
  AND kind_id <> 0;
