SELECT cn.id, cn.name, cn.imdb_index, cn.imdb_id, cn.name_pcode_nf, cn.surname_pcode, cn.md5sum,
       akat.title
FROM char_name cn
JOIN cast_info ci ON cn.id = ci.person_id
JOIN aka_title akat ON ci.movie_id = akat.movie_id
WHERE cn.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND cn.md5sum LIKE '%%'
  AND (cn.imdb_id BETWEEN 1000 AND 5000 OR cn.name_pcode_nf = 'M1462')
  AND akat.production_year BETWEEN 1961 AND 2009;
