SELECT t.id, t.title, n.name AS actor_name, rt.role, kt.kind, cn.name AS company_name, ct.kind AS company_type
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN name n ON ci.person_id = n.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
JOIN company_type ct ON mc.company_type_id = ct.id
WHERE t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL AND t.phonetic_code IS NOT NULL AND n.gender = 'm' AND n.imdb_id IS NOT NULL AND n.imdb_id > 2000 AND ci.person_role_id IS NOT NULL AND ci.nr_order <= 14 AND ci.nr_order IS NOT NULL AND cn.country_code = '[de]' AND cn.country_code IS NOT NULL AND cn.imdb_id > 2300 AND mc.note IS NOT NULL AND mc.company_id > 44843;
