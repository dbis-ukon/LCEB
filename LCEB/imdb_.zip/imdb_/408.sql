SELECT cn.id, cn.name
FROM company_name cn
JOIN movie_companies mc ON mc.company_id = cn.id
JOIN company_type ct ON ct.id = mc.company_type_id
JOIN title t ON t.id = mc.movie_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND ct.kind = 'miscellaneous companies'
EXCEPT
SELECT cn.id, cn.name
FROM company_name cn
JOIN movie_companies mc ON mc.company_id = cn.id
JOIN title t ON t.id = mc.movie_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%');
