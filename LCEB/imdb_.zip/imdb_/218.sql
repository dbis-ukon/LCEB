SELECT id, name, imdb_index, imdb_id, name_pcode_nf, surname_pcode, md5sum
FROM char_name cn
WHERE cn.name LIKE '%%'
  AND cn.name NOT LIKE '%%'
  AND cn.surname_pcode = 'A526'
  AND cn.imdb_id BETWEEN 2300 AND 16500;
