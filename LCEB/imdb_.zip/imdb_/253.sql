SELECT cn.name, rt.role, kt.kind, MIN(t.production_year) AS first_year, MAX(t.production_year) AS last_year
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN role_type rt ON rt.id = ci.role_id
JOIN title t ON t.id = ci.movie_id
JOIN kind_type kt ON kt.id = t.kind_id
WHERE cn.name LIKE '%%'
  AND rt.role LIKE '%%'
  AND kt.kind IN ('episode', 'movie', 'tv series', 'video movie', 'tv mini series')
  AND ci.nr_order <= 1
  AND t.production_year BETWEEN 2004 AND 2006
GROUP BY cn.name, rt.role, kt.kind
ORDER BY last_year DESC;
