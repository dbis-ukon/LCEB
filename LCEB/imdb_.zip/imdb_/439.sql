SELECT n.name, t.title, k.keyword, t.production_year
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE k.keyword LIKE '%%'
  AND t.title LIKE '%%'
  AND ci.nr_order <= 100
  AND (n.name LIKE '%%''K%' OR n.name LIKE '%%')
  AND t.kind_id IN (7, 3, 1)
  AND n.gender = 'f'
ORDER BY n.name;
