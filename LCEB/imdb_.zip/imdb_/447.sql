SELECT t.id, t.title, cct1.kind AS subject_kind, cct2.kind AS status_kind, kt.kind
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN complete_cast cc ON t.id = cc.movie_id
JOIN comp_cast_type cct1 ON cc.subject_id = cct1.id
JOIN comp_cast_type cct2 ON cc.status_id = cct2.id
WHERE t.title LIKE '%%'
  AND cct1.kind = 'crew'
  AND cct2.kind = 'complete'
  AND t.production_year BETWEEN 1995 AND 2010;
