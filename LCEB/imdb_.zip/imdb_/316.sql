SELECT id, title, production_year
FROM title
WHERE (title LIKE '%return%' OR title LIKE '%revenge%')
  AND title NOT LIKE '%returning%'
  AND production_year BETWEEN 1970 AND 2020
  AND episode_of_id IS NULL;
