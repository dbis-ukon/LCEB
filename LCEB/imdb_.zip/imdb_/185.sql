SELECT t.id, t.title, rt.role, it.info AS info_type, mi.info, cn.name AS company_name
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_info mi ON t.id = mi.movie_id
JOIN info_type it ON mi.info_type_id = it.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE t.title LIKE '%%'
  AND rt.role = 'actress'
  AND cn.name LIKE '%%'
  AND ci.nr_order <= 6 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 1 AND 4 AND t.production_year < 2008 AND t.production_year BETWEEN 1992 AND 1997 AND t.kind_id IN (4, 1, 7) AND t.season_nr >= 2 AND cn.name_pcode_nf IS NOT NULL AND cn.name_pcode_sf IS NOT NULL AND cn.country_code = '[de]';
