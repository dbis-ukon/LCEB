SELECT t.id AS item_id, 'title' AS source, t.title AS matched_text
FROM title t
WHERE t.title LIKE '%%'
  AND t.phonetic_code IS NOT NULL AND t.imdb_id IS NOT NULL AND t.series_years IS NOT NULL AND t.production_year > 1967
UNION
SELECT akat.id AS item_id, 'aka_title' AS source, akat.title AS matched_text
FROM aka_title akat
WHERE akat.title LIKE '%%'
  AND akat.imdb_id IS NOT NULL AND akat.series_years IS NOT NULL AND akat.production_year > 1959 AND akat.production_year < 1979;
