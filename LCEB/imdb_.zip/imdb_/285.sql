SELECT t.id, t.title, cn.name, ct.kind, mc.note
FROM title t
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
JOIN company_type ct ON ct.id = mc.company_type_id
WHERE (cn.name LIKE '%%' OR cn.name LIKE '%%')
  AND cn.name NOT LIKE '%%'
  AND ct.kind LIKE '%%'
  AND ct.kind NOT LIKE '%%'
  AND t.title LIKE '%%'
  AND t.title NOT LIKE '%%'
  AND t.production_year >= 1995
  AND t.production_year <= 1998
  AND mc.company_id > 16298
  AND mc.company_type_id IN (2, 1)
  AND mc.note IS NOT NULL;
