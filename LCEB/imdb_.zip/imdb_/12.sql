SELECT t.title, kt.kind, n1.name AS actor1, rt1.role AS role1, n2.name AS actor2, rt2.role AS role2
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci1 ON t.id = ci1.movie_id
JOIN role_type rt1 ON ci1.role_id = rt1.id
JOIN name n1 ON ci1.person_id = n1.id
JOIN cast_info ci2 ON ci1.movie_id = ci2.movie_id AND ci1.person_id <> ci2.person_id
JOIN role_type rt2 ON ci2.role_id = rt2.id
JOIN name n2 ON ci2.person_id = n2.id
WHERE t.title LIKE '%%'
  AND n1.name LIKE '%%'
  AND n2.name NOT LIKE '%%'
  AND ci1.nr_order <= 16 AND ci1.nr_order IS NOT NULL AND ci1.nr_order BETWEEN 0 AND 2 AND n1.name_pcode_nf IS NOT NULL AND n1.name_pcode_cf IS NOT NULL AND n1.surname_pcode IS NOT NULL;
