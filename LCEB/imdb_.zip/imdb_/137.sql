SELECT id, title, imdb_index, kind_id, production_year, imdb_id, phonetic_code, episode_of_id, season_nr, episode_nr, series_years, md5sum
FROM title t
WHERE (t.title LIKE '%%' OR t.title LIKE '%%' or t.title LIKE '%%')
  AND t.production_year BETWEEN 1976 AND 2005
  AND t.md5sum LIKE '%%'
  AND t.kind_id = 1;
