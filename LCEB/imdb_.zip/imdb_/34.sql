SELECT t.id, t.title, n.name AS ActorName, rt.role, ci.nr_order
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN role_type rt ON rt.id = ci.role_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name NOT LIKE '%%'
  AND t.production_year < 2008 AND t.production_year BETWEEN 1997 AND 2009 AND t.episode_of_id IS NULL AND ci.nr_order IS NOT NULL AND ci.note IS NOT NULL;
