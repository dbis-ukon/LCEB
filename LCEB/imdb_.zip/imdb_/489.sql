SELECT t.id, t.title, n.name AS actor_name, chn.name AS character_name, rt.role,
       k.keyword, cn.name AS company_name, ct.kind AS company_type, kt.kind AS title_kind
FROM title t
JOIN kind_type kt ON kt.id = t.kind_id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN char_name chn ON chn.id = ci.person_role_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
JOIN company_type ct ON ct.id = mc.company_type_id
WHERE t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND cn.name LIKE '%%'
  AND t.production_year BETWEEN 1938 AND 2012 AND t.kind_id IN (4, 1, 7, 6) AND t.season_nr >= 1 AND t.episode_nr <= 23 AND ci.person_role_id IS NOT NULL AND ci.nr_order <= 33 AND ci.nr_order IS NOT NULL AND cn.name_pcode_sf IS NOT NULL AND cn.country_code = '[de]' AND cn.country_code IS NOT NULL AND mc.note IS NOT NULL AND mc.company_id > 1886;
