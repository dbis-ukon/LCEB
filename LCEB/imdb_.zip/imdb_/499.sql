SELECT n.id, n.name AS RealName, an.name AS AkaName, it.info AS InfoType, pi.info AS Details
FROM name n
JOIN aka_name an ON an.person_id = n.id
JOIN person_info pi ON pi.person_id = n.id
JOIN info_type it ON it.id = pi.info_type_id
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.name NOT LIKE '%%'
  AND an.name_pcode_cf IS NOT NULL
  AND it.info = 'biographical movies'
  AND n.gender = 'm' AND n.gender = 'm';
