SELECT t.id, t.title, k.keyword, kt.kind, cct1.kind AS subject_kind, cct2.kind AS status_kind
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN complete_cast cc ON t.id = cc.movie_id
JOIN comp_cast_type cct1 ON cc.subject_id = cct1.id
JOIN comp_cast_type cct2 ON cc.status_id = cct2.id
WHERE t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.episode_nr <= 11 AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL AND k.id > 7156 AND k.id BETWEEN 17460 AND 119399 AND cc.subject_id = 2;
