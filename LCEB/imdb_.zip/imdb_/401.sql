SELECT t.id, t.title, kt.kind
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
WHERE t.title LIKE '%%'
  AND t.series_years IS NOT NULL AND t.production_year > 1998 AND t.production_year < 2010 AND t.production_year BETWEEN 1997 AND 2010
  AND EXISTS (
      SELECT 1 FROM movie_keyword mk JOIN keyword k ON mk.keyword_id = k.id
      WHERE mk.movie_id = t.id AND k.keyword LIKE '%%'
  )
  AND EXISTS (
      SELECT 1 FROM cast_info ci JOIN name n ON ci.person_id = n.id
      WHERE ci.movie_id = t.id AND n.name LIKE '%%' AND ci.nr_order BETWEEN 0 AND 10 AND ci.role_id IN (5, 1, 4, 6, 10) AND ci.note IS NULL
  )
  AND EXISTS (
      SELECT 1 FROM movie_companies mc JOIN company_name cn ON mc.company_id = cn.id
      WHERE mc.movie_id = t.id AND cn.name_pcode_nf IS NOT NULL AND cn.name_pcode_sf IS NOT NULL AND cn.country_code = '[us]'
  );
