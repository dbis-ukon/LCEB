SELECT cn.name, ct.kind, t.title, kt.kind AS title_kind, n.name AS actor_name, rt.role
FROM company_name cn
JOIN movie_companies mc ON cn.id = mc.company_id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN title t ON mc.movie_id = t.id
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN role_type rt ON ci.role_id = rt.id
WHERE cn.name LIKE '%%'
  AND ct.kind = 'special effects companies'
  AND t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND cn.imdb_id IS NOT NULL AND cn.name_pcode_nf IS NOT NULL AND cn.name_pcode_sf IS NOT NULL AND mc.company_type_id IN (1, 2) AND mc.note IS NULL AND ci.nr_order <= 14 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 8 AND 22;
