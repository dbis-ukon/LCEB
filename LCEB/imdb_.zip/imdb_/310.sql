SELECT t1.title AS source_title, t2.title AS related_title, lt.link, kt1.kind AS kind1, kt2.kind AS kind2, n.name AS actor_name
FROM title t1
JOIN kind_type kt1 ON t1.kind_id = kt1.id
JOIN movie_link ml ON t1.id = ml.movie_id
JOIN title t2 ON ml.linked_movie_id = t2.id
JOIN kind_type kt2 ON t2.kind_id = kt2.id
JOIN link_type lt ON ml.link_type_id = lt.id
JOIN cast_info ci ON t1.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE t1.title LIKE '%%'
  AND t2.title NOT LIKE '%%'
  AND n.name LIKE '%%'
  AND lt.link = 'featured in'
  AND t1.series_years IS NOT NULL AND t1.production_year > 1932 AND t1.production_year < 2008 AND t1.production_year BETWEEN 1983 AND 2004 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 2 AND 6 AND ci.role_id IN (2, 4, 10, 9, 1);
