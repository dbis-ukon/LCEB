SELECT cn1.name AS Company1, cn2.name AS Company2, t1.title AS Movie1, t2.title AS Movie2, k.keyword
FROM company_name cn1
JOIN company_name cn2 ON cn1.country_code = cn2.country_code AND cn1.id <> cn2.id
JOIN movie_companies mc1 ON mc1.company_id = cn1.id
JOIN title t1 ON t1.id = mc1.movie_id
JOIN movie_companies mc2 ON mc2.company_id = cn2.id
JOIN title t2 ON t2.id = mc2.movie_id
JOIN movie_keyword mk ON mk.movie_id = t1.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE (cn1.name LIKE '%%' OR cn1.name LIKE '%%')
  AND (t1.title LIKE '%%' OR t1.title LIKE '%%')
  AND t2.title NOT LIKE '%%'
  AND k.keyword LIKE '%%';
