SELECT DISTINCT a.title, c.name AS char_name, co.name AS company_name, k.keyword
FROM aka_title a
JOIN movie_keyword mk ON a.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON a.id = ci.movie_id
JOIN char_name c ON ci.person_id = c.id
JOIN movie_companies mc ON a.id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE (a.title LIKE '%%' OR c.name LIKE '%%' OR co.name LIKE '%%' OR a.title LIKE '%%')
  AND k.keyword LIKE '%%'
  AND a.production_year >= 1967
  AND co.country_code = '[gb]'
  AND ci.nr_order > 0
  AND k.phonetic_code LIKE '%%'
  AND mc.note LIKE '%%'
  AND a.season_nr >= 1;
