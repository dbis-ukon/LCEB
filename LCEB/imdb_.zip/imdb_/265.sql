SELECT t.id, t.title, n.name AS ActorName, chn.name AS CharacterName, rt.role,
       k.keyword, cn.name AS CompanyName, kt.kind AS TitleKind
FROM title t
JOIN kind_type kt ON kt.id = t.kind_id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN char_name chn ON chn.id = ci.person_role_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
WHERE t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND n.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND cn.name LIKE '%%'
  AND t.episode_nr <= 10007;
