SELECT id, name, country_code
FROM company_name
WHERE (name LIKE '%Warner%' OR name LIKE '%Universal%')
  AND name NOT LIKE '%Television%'
  AND country_code IS NOT NULL
  AND id > 0;
