SELECT t.id, t.imdb_index
FROM title t
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE k.keyword LIKE '%%'
  AND t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND t.production_year >= 1920
  AND ci.role_id = 10;
