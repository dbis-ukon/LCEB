SELECT t.id, t.title, kt.kind, cn.name AS company_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE t.title LIKE '%%'
  AND (cn.name LIKE '%%' OR  cn.name LIKE '%%')
  AND t.production_year > (SELECT AVG(production_year) FROM title WHERE production_year IS NOT NULL)
  AND cn.country_code = '[ph]' AND cn.country_code IS NOT NULL AND cn.imdb_id > 4700 AND mc.company_id > 119 AND mc.company_type_id IN (1, 2);
