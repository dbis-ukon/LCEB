WITH keyword_movies AS (
    SELECT mk.movie_id
    FROM movie_keyword mk
    JOIN keyword k ON mk.keyword_id = k.id
    WHERE k.keyword LIKE '%%'
)
SELECT t.title, n.name AS actor_name, co.name AS company_name, t.production_year
FROM keyword_movies km
JOIN title t ON km.movie_id = t.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE ci.nr_order = 12
  AND co.country_code = '[gb]'
  AND t.kind_id = 1
  AND n.gender = 'f';
