SELECT t.title, k.keyword, t.production_year
FROM title t
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.title LIKE '%%'
  AND k.phonetic_code IS NOT NULL
  AND t.episode_nr <= 1
  AND t.kind_id IN (4, 7, 1)
  AND k.keyword LIKE '%%'
  AND t.production_year >= 2013
ORDER BY t.production_year DESC
LIMIT 100;
