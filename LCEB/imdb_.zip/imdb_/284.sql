SELECT id, name, country_code
FROM company_name
WHERE (name LIKE '%Lionsgate%' OR name LIKE '%MGM%')
  AND name NOT LIKE '%Home%'
  AND country_code IS NOT NULL
  AND id > 0;
