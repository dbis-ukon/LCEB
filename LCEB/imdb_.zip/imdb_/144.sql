SELECT id, keyword, phonetic_code
FROM keyword k
WHERE k.keyword LIKE '%%'
  AND k.id < 77857
  AND k.phonetic_code = 'B4235';
