SELECT id, title
FROM title
WHERE (title LIKE '%secret%' OR title LIKE '%mystery%')
  AND title NOT LIKE '%secretary%'
  AND production_year >= 1980
  AND kind_id IN (1, 2, 3);
