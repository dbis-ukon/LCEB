SELECT n.id, n.name, it.info AS info_category, pi.info AS details, t.title, kt.kind
FROM name n
JOIN person_info pi ON n.id = pi.person_id
JOIN info_type it ON pi.info_type_id = it.id
JOIN cast_info ci ON n.id = ci.person_id
JOIN title t ON ci.movie_id = t.id
JOIN kind_type kt ON t.kind_id = kt.id
WHERE (n.name LIKE '%%' or n.name LIKE '%%' or t.title LIKE '%%')
  AND it.info = 'article'
  AND n.name_pcode_cf IS NOT NULL AND n.surname_pcode IS NOT NULL AND n.gender = 'm' AND ci.nr_order BETWEEN 1 AND 7 AND ci.role_id IN (2, 5, 11, 6, 8) AND ci.note IS NULL AND t.production_year > 1990 AND t.production_year < 2007 AND t.production_year BETWEEN 1983 AND 2012 AND t.kind_id IN (7, 4, 1);
