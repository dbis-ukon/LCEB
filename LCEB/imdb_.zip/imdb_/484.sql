SELECT t.id,
       t.title,
       at.title AS alternate_title,
       n.name,
       cn.name AS company_name,
       k.keyword
FROM title t
JOIN aka_title at
  ON at.movie_id = t.id
JOIN cast_info ci
  ON ci.movie_id = t.id
JOIN name n
  ON n.id = ci.person_id
JOIN movie_companies mc
  ON mc.movie_id = t.id
JOIN company_name cn
  ON cn.id = mc.company_id
JOIN movie_keyword mk
  ON mk.movie_id = t.id
JOIN keyword k
  ON k.id = mk.keyword_id
WHERE at.title LIKE '%%'
  AND n.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.production_year >= 1999
  AND t.production_year < 2008
  AND ci.role_id = 10
  AND mc.company_type_id = 1
  AND k.id BETWEEN 28881 AND 57677;
