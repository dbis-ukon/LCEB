SELECT cn.name, rt.role, COUNT(DISTINCT ci.movie_id) AS roles
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN role_type rt ON rt.id = ci.role_id
JOIN title t ON t.id = ci.movie_id
WHERE cn.name LIKE '%%'
  AND t.title NOT LIKE '%%'
  AND rt.role LIKE '%%'
  AND ci.nr_order <= 2
  AND t.production_year BETWEEN 1991 AND 2009
  AND t.kind_id IN (3, 1, 4, 7)
GROUP BY cn.name, rt.role
ORDER BY roles DESC;
