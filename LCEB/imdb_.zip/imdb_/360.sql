SELECT t.id, t.title, cn.name AS CompanyName, ct.kind AS CompanyRole
FROM title t
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
JOIN company_type ct ON ct.id = mc.company_type_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND (cn.name LIKE '%%' OR cn.name LIKE '%%')
  AND cn.name NOT LIKE '%%'
  AND ct.kind = 'special effects companies'
  AND t.season_nr IS NOT NULL AND t.imdb_id IS NOT NULL AND t.phonetic_code IS NOT NULL AND cn.country_code = '[us]' AND cn.country_code IS NOT NULL;
