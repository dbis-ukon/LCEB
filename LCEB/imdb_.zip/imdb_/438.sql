SELECT id, title
FROM aka_title
WHERE (title LIKE '%return%' OR title LIKE '%revenge%')
  AND title NOT LIKE '%returning%'
  AND production_year > 1970
  AND episode_of_id IS NULL;
