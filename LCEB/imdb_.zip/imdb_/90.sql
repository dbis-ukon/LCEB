SELECT cn.name, COUNT(DISTINCT ci.movie_id) AS movie_count, MAX(t.production_year) AS last_year
FROM char_name cn
JOIN cast_info ci ON ci.person_id = cn.id
JOIN title t ON t.id = ci.movie_id
WHERE (cn.name LIKE '%%' OR t.title LIKE '%%')
  AND t.production_year BETWEEN 2007 AND 2009
  AND ci.nr_order <= 2
GROUP BY cn.name
ORDER BY last_year DESC;
