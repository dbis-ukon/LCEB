SELECT t.id, t.title, k.keyword, kt.kind, COUNT(DISTINCT ci.person_id) AS cast_count
FROM title t
JOIN kind_type kt ON kt.id = t.kind_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN role_type rt ON rt.id = ci.role_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND rt.role = 'miscellaneous crew'
  AND ci.role_id > 1
GROUP BY t.id, t.title, k.keyword, kt.kind
HAVING COUNT(DISTINCT ci.person_id) > 8;
