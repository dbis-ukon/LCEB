SELECT n.id, n.name
FROM name n
JOIN cast_info ci ON ci.person_id = n.id
JOIN title t ON t.id = ci.movie_id
JOIN role_type rt ON rt.id = ci.role_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND rt.role = 'costume designer'
INTERSECT
SELECT n.id, n.name
FROM name n
JOIN cast_info ci ON ci.person_id = n.id
JOIN title t ON t.id = ci.movie_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%');
