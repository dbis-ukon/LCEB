SELECT id, title
FROM title
WHERE (title LIKE '%last%' OR title LIKE '%first%')
  AND title NOT LIKE '%last chance%'
  AND production_year IS NOT NULL
  AND kind_id > 0;
