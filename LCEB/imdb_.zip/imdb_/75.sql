SELECT id, title, note
FROM aka_title
WHERE (title LIKE '%secret%' OR title LIKE '%hidden%')
  AND title NOT LIKE '%secretary%'
  AND production_year IS NOT NULL
  AND note IS NOT NULL;
