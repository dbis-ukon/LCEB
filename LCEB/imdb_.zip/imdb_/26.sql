SELECT cn.name AS CompanyName, ct.kind AS CompanyRole, COUNT(DISTINCT mc.movie_id) AS movie_count
FROM company_name cn
JOIN movie_companies mc ON mc.company_id = cn.id
JOIN company_type ct ON ct.id = mc.company_type_id
JOIN title t ON t.id = mc.movie_id
WHERE (cn.name LIKE '%%' OR cn.name LIKE '%%')
  AND (t.title LIKE '%%' OR t.title LIKE '%%')
GROUP BY cn.name, ct.kind
HAVING COUNT(DISTINCT mc.movie_id) > 0;
