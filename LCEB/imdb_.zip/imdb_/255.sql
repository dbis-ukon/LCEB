SELECT t.title, COUNT(DISTINCT k.id) AS num_keywords, MAX(t.production_year) AS last_year
FROM title t
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND k.keyword LIKE '%%'
  AND t.production_year BETWEEN 1998 AND 2008
  AND t.kind_id IN (2, 7, 1)
GROUP BY t.title
ORDER BY last_year DESC;
