SELECT id, title
FROM title
WHERE (title LIKE '%summer%' OR title LIKE '%spring%')
  AND title NOT LIKE '%springfield%'
  AND production_year BETWEEN 1980 AND 2020
  AND id < 900000;
