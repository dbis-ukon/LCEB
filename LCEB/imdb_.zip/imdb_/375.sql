SELECT t.title, akat.title AS aka_title, n.name AS actor, chn.name AS character_name,
       cn.name AS company_name, k.keyword, ct.kind AS company_type
FROM title t
JOIN aka_title akat ON t.id = akat.movie_id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN char_name chn ON ci.person_role_id = chn.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.title LIKE '%%'
  AND akat.title LIKE '%%'
  AND n.name LIKE '%%'
  AND chn.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.production_year < 1967 AND t.production_year BETWEEN 1957 AND 1990 AND t.kind_id IN (1, 4, 7) AND t.season_nr >= 1 AND ci.nr_order <= 20 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 0 AND 6 AND cn.name_pcode_sf IS NOT NULL AND cn.country_code = '[gb]' AND cn.country_code IS NOT NULL;
