SELECT id, movie_id, title, imdb_index, kind_id, production_year, phonetic_code, episode_of_id, season_nr, episode_nr, note, md5sum
FROM aka_title akat
WHERE (akat.title LIKE '%%' OR akat.title LIKE '%%' OR akat.title LIKE '%%')
  AND akat.kind_id IN (2, 1, 3)
  AND akat.md5sum IS NOT NULL;
