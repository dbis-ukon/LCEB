SELECT id, title, production_year
FROM title
WHERE (title LIKE '%night%' OR title LIKE '%day%')
  AND title NOT LIKE '%good night%'
  AND production_year IS NOT NULL
  AND id > 0;
