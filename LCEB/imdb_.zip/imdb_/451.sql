SELECT id, title, imdb_index, kind_id, production_year, imdb_id, phonetic_code, episode_of_id, season_nr, episode_nr, series_years, md5sum
FROM title t
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.production_year BETWEEN 2004 AND 2007
  AND t.kind_id = 1;
