SELECT t.id, t.title, rt.role, it.info AS info_type, mi.info, cn.name AS company_name
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_info mi ON t.id = mi.movie_id
JOIN info_type it ON mi.info_type_id = it.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE t.title LIKE '%%'
  AND t.title NOT LIKE '%%'
  AND rt.role = 'miscellaneous crew'
  AND cn.name LIKE '%%'
  AND ci.note IS NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND t.episode_nr <= 137 AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL AND t.md5sum IS NOT NULL AND cn.imdb_id > 3200 AND cn.imdb_id IS NOT NULL AND cn.name_pcode_nf IS NOT NULL;
