SELECT
    akat.movie_id,
    COUNT(DISTINCT cn.name) AS villain_roles
FROM aka_title akat
JOIN cast_info ci ON akat.movie_id = ci.movie_id
JOIN char_name cn ON ci.person_role_id = cn.id
JOIN role_type rt ON ci.role_id = rt.id
JOIN name n ON ci.person_id = n.id
WHERE (akat.title LIKE '%%' OR akat.title LIKE '%%')
  AND cn.name LIKE '%%'
  AND rt.role LIKE '%%'
  AND n.name LIKE '%%'
  AND akat.production_year BETWEEN 1982 AND 1992
GROUP BY akat.movie_id
HAVING COUNT(DISTINCT cn.name) >= 2;
