SELECT id, keyword
FROM keyword
WHERE (keyword LIKE '%holiday%' OR keyword LIKE '%christmas%')
  AND keyword NOT LIKE '%christmas tree%'
  AND id > 0
  AND phonetic_code IS NOT NULL;
