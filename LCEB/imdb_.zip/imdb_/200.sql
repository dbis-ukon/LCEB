SELECT id, keyword, phonetic_code
FROM keyword k
WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND k.id > 17460
  AND k.phonetic_code LIKE '%%';
