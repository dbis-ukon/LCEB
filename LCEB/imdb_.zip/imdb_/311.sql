SELECT t.id, t.title, cn.name AS company_name, ct.kind, mii.info AS rating_value
FROM title t
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_info_idx mii ON t.id = mii.movie_id
JOIN info_type it ON mii.info_type_id = it.id
WHERE t.title LIKE '%%'
  AND t.title LIKE '%%'
  AND cn.name LIKE '%%'
  AND it.info = 'tech info'
  AND cn.country_code IS NOT NULL AND cn.imdb_id > 1700 AND cn.imdb_id IS NOT NULL AND mc.note IS NULL AND mc.note IS NOT NULL AND t.season_nr >= 6 AND t.episode_nr <= 1365 AND t.episode_of_id IS NULL AND t.episode_of_id IS NOT NULL;
