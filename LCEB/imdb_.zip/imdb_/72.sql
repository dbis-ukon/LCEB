SELECT t1.title AS SourceTitle, t2.title AS RelatedTitle, lt.link AS LinkType, kt1.kind, kt2.kind
FROM title t1
JOIN kind_type kt1 ON kt1.id = t1.kind_id
JOIN movie_link ml ON ml.movie_id = t1.id
JOIN title t2 ON t2.id = ml.linked_movie_id
JOIN kind_type kt2 ON kt2.id = t2.kind_id
JOIN link_type lt ON lt.id = ml.link_type_id
WHERE (t1.title LIKE '%%' OR t1.title LIKE '%%')
  AND t2.title NOT LIKE '%%'
  AND lt.link = 'spin off'
  AND t1.phonetic_code IS NOT NULL AND t1.production_year > 1961 AND t1.production_year < 1988;
