SELECT t.id, t.title, mii.info AS rating_value, k.keyword, kt.kind, n.name AS actor_name
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_info_idx mii ON t.id = mii.movie_id
JOIN info_type it ON mii.info_type_id = it.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
WHERE t.title LIKE '%%'
  AND it.info = 'LD video standard'
  AND k.keyword NOT LIKE '%%'
  AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 14 AND 38 AND ci.role_id IN (2, 3, 1, 4, 10) AND t.production_year > 1915 AND t.production_year < 1913 AND t.production_year BETWEEN 1998 AND 2011 AND t.kind_id IN (3, 1, 7, 4);
