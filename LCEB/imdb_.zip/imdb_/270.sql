SELECT co.name, COUNT(DISTINCT t.id) AS movies
FROM company_name co
JOIN movie_companies mc ON mc.company_id = co.id
JOIN title t ON t.id = mc.movie_id
WHERE (co.name LIKE '%%' OR co.name LIKE '%%')
  AND (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.season_nr = 1
  AND t.production_year BETWEEN 1995 AND 2002
GROUP BY co.name
ORDER BY movies DESC;
