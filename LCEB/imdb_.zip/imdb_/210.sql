SELECT t.id, t.title, n.name, cn.name AS company
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND n.name LIKE '%%'
  AND n.name NOT LIKE '%%'
  AND cn.name LIKE '%%'
  AND cn.name NOT LIKE '%%'
  AND t.production_year BETWEEN 1998 AND 2010
  AND ci.nr_order <= 45
  AND ci.nr_order > 1
  AND mc.company_id IS NOT NULL
  AND n.id > 881446;
