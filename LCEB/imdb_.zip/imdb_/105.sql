SELECT cn.id, cn.name, cn.country_code
FROM company_name cn
JOIN movie_companies mc ON cn.id = mc.company_id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN title t ON mc.movie_id = t.id
WHERE t.title LIKE '%%'
  AND cn.name LIKE '%%'
  AND cn.imdb_id > 1400 AND cn.imdb_id IS NOT NULL AND cn.name_pcode_nf IS NOT NULL AND mc.note IS NULL AND mc.note IS NOT NULL
EXCEPT
SELECT cn.id, cn.name, cn.country_code
FROM company_name cn
JOIN movie_companies mc ON cn.id = mc.company_id
JOIN title t ON mc.movie_id = t.id
WHERE t.title LIKE '%%'
AND (t.title LIKE '%%' OR t.title LIKE '%%');
