SELECT id, name
FROM company_name
WHERE (name LIKE '%Film%' OR name LIKE '%Cinema%')
  AND name NOT LIKE '%Festival%'
  AND id > 0
  AND country_code IS NOT NULL;
