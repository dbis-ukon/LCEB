SELECT t.id, t.title, cct1.kind AS SubjectKind, cct2.kind AS StatusKind, kt.kind AS TitleKind
FROM title t
JOIN kind_type kt ON kt.id = t.kind_id
JOIN complete_cast cc ON cc.movie_id = t.id
JOIN comp_cast_type cct1 ON cct1.id = cc.subject_id
JOIN comp_cast_type cct2 ON cct2.id = cc.status_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%' or t.title LIKE '%%')
  AND cct1.kind = 'cast'
  AND kt.kind = 'movie'
  AND t.production_year < 2005 AND t.production_year BETWEEN 1986 AND 1995 AND t.episode_of_id IS NULL;
