SELECT n.id, n.name, n.imdb_id, n.name_pcode_cf,
       akat.title
FROM name n
JOIN aka_title akat ON n.imdb_id = akat.movie_id
WHERE n.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND (n.gender = 'f' OR n.imdb_id < 10000)
  AND akat.production_year BETWEEN 1991 AND 1992;
