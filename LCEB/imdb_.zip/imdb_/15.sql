SELECT id, name, gender, name_pcode_cf, imdb_id
FROM name n
WHERE (n.name LIKE '%%' OR n.name LIKE '%%' OR n.name LIKE '%%')
  AND n.gender = 'm'
  AND n.name_pcode_cf IS NOT NULL;
