SELECT id, title
FROM title
WHERE (title LIKE '%future%' OR title LIKE '%past%')
  AND title NOT LIKE '%future shock%'
  AND production_year >= 1980
  AND id BETWEEN 100 AND 999999;
