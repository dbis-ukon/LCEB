SELECT id, title, season_nr, episode_nr
FROM aka_title
WHERE (title LIKE 'the %' OR title LIKE '%story%')
  AND title NOT LIKE '%remake%'
  AND production_year BETWEEN 1980 AND 2015
  AND episode_of_id IS NULL;
