SELECT id, name
FROM char_name
WHERE (name LIKE '%Reporter%' OR name LIKE '%Journalist%')
  AND name NOT LIKE '%News Reporter%'
  AND id > 0
  AND imdb_index IS NOT NULL;
