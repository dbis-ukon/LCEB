SELECT id, name
FROM name
WHERE (name LIKE '%Robert%' OR name LIKE '%Richard%')
  AND name NOT LIKE '%Jr%'
  AND gender IS NOT NULL
  AND id > 0;
