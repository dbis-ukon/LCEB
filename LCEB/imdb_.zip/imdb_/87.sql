SELECT id, name, gender, imdb_index, imdb_id
FROM name n
WHERE n.name LIKE '%%'
  AND n.gender = 'm'
  AND n.imdb_id > 2550;
