SELECT id, name, country_code, imdb_id, name_pcode_nf, name_pcode_sf, md5sum
FROM company_name c
WHERE c.name LIKE '%%'
  AND c.country_code IN ('[gb]', '[au]', '[us]', '[ua]', '[in]')
  AND c.name_pcode_sf IS NOT NULL;
