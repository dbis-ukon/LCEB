SELECT id, name, imdb_id
FROM char_name
WHERE (name LIKE '%Mayor%' OR name LIKE '%Senator%')
  AND name NOT LIKE '%Former Mayor%'
  AND imdb_id IS NOT NULL
  AND id BETWEEN 1 AND 999999;
