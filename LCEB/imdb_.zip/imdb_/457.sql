SELECT t.id, t.title, it1.info AS Genre, k.keyword, mi_idx.info AS Rating
FROM title t
JOIN movie_info mi ON mi.movie_id = t.id
JOIN info_type it1 ON it1.id = mi.info_type_id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
JOIN movie_info_idx mi_idx ON mi_idx.movie_id = t.id
JOIN info_type it2 ON it2.id = mi_idx.info_type_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND (k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND it1.info = 'LD number of sides'
  AND it2.info = 'votes';
