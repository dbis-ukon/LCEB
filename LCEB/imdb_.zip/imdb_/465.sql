SELECT id, name
FROM company_name
WHERE (name LIKE '%DreamWorks%' OR name LIKE '%Dream%')
  AND name NOT LIKE '%Animation%'
  AND imdb_id IS NOT NULL
  AND id BETWEEN 1 AND 900000;
