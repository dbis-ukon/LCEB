SELECT id, name, name_pcode_nf, md5sum
FROM name n
WHERE n.name LIKE '%%'
  AND (n.name_pcode_cf = 'R2632' OR n.gender = 'f');
