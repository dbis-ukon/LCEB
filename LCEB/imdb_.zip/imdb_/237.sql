SELECT t.id, t.title, k.keyword, n.name, rt.role
FROM title t
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN role_type rt ON rt.id = ci.role_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND k.keyword LIKE '%%'
  AND k.keyword NOT LIKE '%%'
  AND n.name LIKE '%%'
  AND n.name NOT LIKE '%%'
  AND rt.role LIKE '%%'
  AND rt.role NOT LIKE '%%'
  AND t.production_year BETWEEN 1976 AND 2011
  AND ci.nr_order BETWEEN 1 AND 6
  AND mk.keyword_id > 231
  AND n.gender IS NOT NULL;
