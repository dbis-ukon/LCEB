-- Q2: company-centric, movie_link chain, no cast_info at all
SELECT co.name AS company_name, lt.link, t1.title AS source_title, t2.title AS linked_title,
       COUNT(*) AS link_count
FROM company_name co
JOIN movie_companies mc ON mc.company_id = co.id
JOIN title t1 ON t1.id = mc.movie_id
JOIN movie_link ml ON ml.movie_id = t1.id
JOIN link_type lt ON lt.id = ml.link_type_id
JOIN title t2 ON t2.id = ml.linked_movie_id
WHERE co.name LIKE '%%'
  AND lt.link LIKE '%%'
  AND t1.title NOT LIKE '%%'
  AND co.country_code IN ('[ph]', '[ee]', '[mx]', '[nz]', '[gr]')
  AND mc.company_type_id = 1
GROUP BY co.name, lt.link, t1.title, t2.title
ORDER BY link_count DESC;
