SELECT t.id, t.title, c.name AS company, ct.kind
FROM title t
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name c ON mc.company_id = c.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.title LIKE '%%'
  AND c.name LIKE '%%'
  AND ct.kind LIKE '%%'
  AND k.keyword LIKE '%%'
  AND mc.company_type_id = 1
  AND t.episode_nr >= 131;
