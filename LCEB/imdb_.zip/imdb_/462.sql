SELECT id, name, gender
FROM name
WHERE (name LIKE '%Peter%' OR name LIKE '%Paul%')
  AND name NOT LIKE '%Jr.%'
  AND gender IN ('m', 'f')
  AND id BETWEEN 1000 AND 800000;
