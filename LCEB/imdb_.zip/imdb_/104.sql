SELECT id, name, gender
FROM name
WHERE (name LIKE '%Sarah%' OR name LIKE '%Susan%')
  AND name NOT LIKE '%Test%'
  AND id > 0
  AND gender = 'f';
