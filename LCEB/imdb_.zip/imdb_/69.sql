SELECT t.id, t.imdb_index
FROM title t
JOIN aka_title akat ON t.id = akat.movie_id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN char_name cn ON ci.person_role_id = cn.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name co ON mc.company_id = co.id
WHERE k.keyword LIKE '%%'
  AND (t.title LIKE '%%' OR t.title LIKE '%%')
  AND n.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND co.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND t.imdb_index IS NOT NULL
  AND t.production_year >= 2012
  AND ci.role_id = 1
  AND mc.company_type_id = 1;
