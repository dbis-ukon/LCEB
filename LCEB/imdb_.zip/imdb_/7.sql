SELECT n.id, n.name, n.name_pcode_nf, n.md5sum,
       akat.title, akat.production_year
FROM name n
JOIN aka_title akat ON n.imdb_id = akat.movie_id
WHERE n.name LIKE '%%'
  AND ( akat.title LIKE '%%' OR akat.title LIKE '%%' )
  AND (n.imdb_index LIKE '%%' OR n.gender = 'm')
  AND akat.production_year >= 1951;
