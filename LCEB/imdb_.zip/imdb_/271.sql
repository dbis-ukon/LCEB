SELECT
    n.name AS actor_name,
    t.title AS movie_title,
    t.season_nr,
    t.episode_nr,
    COUNT(DISTINCT ci.movie_id) AS appearance_count
FROM name n
JOIN cast_info ci ON n.id = ci.person_id
JOIN title t ON ci.movie_id = t.id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND n.name LIKE '%%'
  AND t.season_nr >= 1
  AND t.episode_nr > 9
  AND n.gender = 'f'
GROUP BY n.name, t.title, t.season_nr, t.episode_nr
ORDER BY appearance_count DESC;
