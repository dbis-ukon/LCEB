SELECT t.title, at.title AS AlternateTitle, n.name AS ActorName, cn.name AS CompanyName
FROM title t
JOIN aka_title at ON at.movie_id = t.id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND (at.title LIKE '%%' OR at.title LIKE '%%')
  AND (n.name LIKE '%%' OR n.name LIKE '%%')
  AND (cn.name LIKE '%%' OR cn.name LIKE '%%');
