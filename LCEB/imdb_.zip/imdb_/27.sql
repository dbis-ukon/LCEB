SELECT id, title
FROM title
WHERE (title LIKE '%king%' OR title LIKE '%queen%')
  AND title NOT LIKE '%kingdom%'
  AND production_year BETWEEN 1950 AND 2020
  AND kind_id > 0;
