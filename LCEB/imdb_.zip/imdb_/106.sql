SELECT n.name AS ActorName, chn.name AS CharacterName, rt.role, t.title, cn.name AS CompanyName
FROM cast_info ci
JOIN name n ON n.id = ci.person_id
JOIN char_name chn ON chn.id = ci.person_role_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN title t ON t.id = ci.movie_id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name cn ON cn.id = mc.company_id
WHERE (n.name LIKE '%%' OR n.name LIKE '%%')
  AND (chn.name LIKE '%%' OR chn.name LIKE '%%')
  AND rt.role = 'actress'
  AND (t.title LIKE '%%' OR t.title LIKE '%%')
  AND cn.name NOT LIKE '%%';
