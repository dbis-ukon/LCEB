SELECT id, title, imdb_index, kind_id, production_year, imdb_id, phonetic_code, episode_of_id, season_nr, episode_nr, series_years, md5sum
FROM title t
WHERE t.title LIKE '%%'
  AND t.production_year >= 2008
  AND t.kind_id IN (7, 1, 2)
  AND t.md5sum IS NOT NULL;
