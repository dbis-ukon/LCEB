SELECT cn.id, cn.name, cn.imdb_index, cn.imdb_id, cn.name_pcode_nf, cn.surname_pcode, cn.md5sum,
       ci.role_id, akat.title
FROM char_name cn
JOIN cast_info ci ON cn.id = ci.person_id
JOIN aka_title akat ON ci.movie_id = akat.movie_id
WHERE (cn.name LIKE '%%' OR cn.name LIKE '%%' OR cn.name LIKE '%%')
  AND akat.title LIKE '%%'
  AND cn.name_pcode_nf = 'L25'
  AND cn.md5sum LIKE '%%'
  AND ci.nr_order <= 4
  AND akat.kind_id IN (2, 3, 1, 4);
