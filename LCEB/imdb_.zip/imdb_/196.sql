SELECT cn.id, cn.name, t.id AS movie_id, t.title, COUNT(DISTINCT ci.person_id) AS appearances
FROM char_name cn
JOIN cast_info ci ON ci.person_role_id = cn.id
JOIN title t ON ci.movie_id = t.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN aka_title akat ON t.id = akat.movie_id
WHERE (cn.name LIKE '%%' OR cn.name LIKE '%%')
  AND cn.name_pcode_nf = 'I5212'
  AND cn.md5sum IS NOT NULL
  AND t.title LIKE '%%'
  AND k.keyword NOT LIKE '%%'
  AND akat.title LIKE '%%'
  AND ci.nr_order <= 9
  AND t.production_year BETWEEN 2002 AND 2009
GROUP BY cn.id, cn.name, t.id, t.title
HAVING COUNT(DISTINCT ci.person_id) >= 2;
