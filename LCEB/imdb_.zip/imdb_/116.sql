SELECT DISTINCT a.title, cn.name AS char_name, co.name AS company_name
FROM aka_title a
INNER JOIN cast_info ci ON a.movie_id = ci.movie_id
INNER JOIN char_name cn ON ci.person_role_id = cn.id
INNER JOIN movie_companies mc ON a.movie_id = mc.movie_id
INNER JOIN company_name co ON mc.company_id = co.id
WHERE a.title LIKE '%%'
  AND cn.name LIKE '%%'
  AND co.name LIKE '%%'
  AND ci.nr_order < 10
  AND a.production_year >= 1922;
