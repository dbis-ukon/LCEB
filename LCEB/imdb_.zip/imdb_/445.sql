SELECT n.name, COUNT(DISTINCT mc.company_id) AS companies
FROM name n
JOIN char_name cn ON cn.id = n.id
JOIN cast_info ci ON ci.person_id = cn.id
JOIN movie_companies mc ON mc.movie_id = ci.movie_id
JOIN company_name co ON co.id = mc.company_id
WHERE n.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND co.country_code = '[us]'
  AND mc.note LIKE '%%'
  AND n.gender = 'm'
GROUP BY n.name
ORDER BY companies DESC;
