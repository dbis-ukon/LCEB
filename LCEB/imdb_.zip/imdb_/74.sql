SELECT t.id, t.production_year
FROM title t
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
WHERE k.keyword LIKE '%%'
  AND t.title LIKE '%%'
  AND t.production_year >= 1983
  AND ci.role_id = 1;
