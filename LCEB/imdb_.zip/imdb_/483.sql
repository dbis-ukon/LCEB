SELECT t.id, t.title, n.name AS PersonName, rt.role, chn.name AS CharacterName
FROM title t
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
JOIN role_type rt ON rt.id = ci.role_id
JOIN char_name chn ON chn.id = ci.person_role_id
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND rt.role = 'actress'
  AND (chn.name LIKE '%%' OR chn.name LIKE '%%')
  AND t.phonetic_code IS NOT NULL AND t.production_year > 2006 AND t.production_year < 2008 AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL;
