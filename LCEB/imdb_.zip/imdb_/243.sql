SELECT t.id, t.title
FROM title t
WHERE (t.title LIKE '%%' OR t.title LIKE '%%')
  AND t.production_year < 1967 AND t.production_year BETWEEN 1932 AND 2005 AND t.episode_of_id IS NULL
  AND NOT EXISTS (
      SELECT 1 FROM aka_title at WHERE at.movie_id = t.id
  )
  AND EXISTS (
      SELECT 1 FROM cast_info ci JOIN name n ON n.id = ci.person_id
      WHERE ci.movie_id = t.id AND n.name NOT LIKE '%%'
  );
