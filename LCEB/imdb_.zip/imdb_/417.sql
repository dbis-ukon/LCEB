SELECT id, keyword, phonetic_code
FROM keyword
WHERE (keyword LIKE '%love%' OR keyword LIKE '%war%')
  AND keyword NOT LIKE '%romance%'
  AND id > 0
  AND phonetic_code IS NOT NULL;
