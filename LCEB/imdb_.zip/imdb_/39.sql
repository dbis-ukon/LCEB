SELECT name, country_code, n_movies, NTILE(10) OVER (ORDER BY n_movies DESC) AS decile
FROM (
    SELECT cn.name, cn.country_code, COUNT(DISTINCT mc.movie_id) AS n_movies
    FROM company_name cn
    JOIN movie_companies mc ON cn.id = mc.company_id
    JOIN company_type ct ON mc.company_type_id = ct.id
    JOIN title t ON mc.movie_id = t.id
    JOIN kind_type kt ON t.kind_id = kt.id
    JOIN movie_keyword mk ON t.id = mk.movie_id
    JOIN keyword k ON mk.keyword_id = k.id
    WHERE cn.name LIKE '%%'
      AND t.title NOT LIKE '%%'
      AND k.keyword LIKE '%%'
      AND mc.note IS NOT NULL AND mc.company_id > 3585
    GROUP BY cn.name, cn.country_code
) c
ORDER BY n_movies DESC;
