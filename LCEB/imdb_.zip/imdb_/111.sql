SELECT id, keyword, phonetic_code
FROM keyword k
WHERE k.keyword LIKE '%%'
  AND k.keyword NOT LIKE '%%'
  AND k.phonetic_code IS NOT NULL;
