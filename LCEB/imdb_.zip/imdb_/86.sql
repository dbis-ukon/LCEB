SELECT id, keyword, phonetic_code
FROM keyword k
WHERE (k.keyword LIKE '%%' or k.keyword NOT LIKE '%%')
  AND k.id BETWEEN 11814 AND 49084
  AND k.phonetic_code IS NOT NULL;
