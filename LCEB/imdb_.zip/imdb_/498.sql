SELECT
    t.title,
    COUNT(DISTINCT ci.person_id) AS cast_count,
    COUNT(DISTINCT k.id) AS keyword_count
FROM title t
JOIN cast_info ci       ON t.id = ci.movie_id
JOIN name n             ON ci.person_id = n.id
JOIN aka_title akat       ON t.id = akat.movie_id
JOIN movie_keyword mk   ON t.id = mk.movie_id
JOIN keyword k          ON mk.keyword_id = k.id
WHERE t.production_year >= 1982
  AND ci.nr_order <= 3
  AND n.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.title LIKE '%%'
GROUP BY t.title
ORDER BY cast_count DESC;
