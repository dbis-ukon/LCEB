SELECT t.id AS title_id, t.title AS main_title, at1.title AS aka_title, n1.name AS lead_actor, n2.name AS guest_actor,
       cn1.name AS hero_character, cn2.name AS sidekick_character, k1.keyword AS main_keyword, k2.keyword AS sub_keyword,
       mi1.info AS award_info, mi2.info AS trivia_info
FROM title t
LEFT JOIN aka_title at1 ON t.id = at1.movie_id
JOIN cast_info ci1 ON t.id = ci1.movie_id
JOIN name n1 ON ci1.person_id = n1.id
JOIN cast_info ci2 ON t.id = ci2.movie_id
JOIN name n2 ON ci2.person_id = n2.id
JOIN char_name cn1 ON ci1.person_role_id = cn1.id
JOIN char_name cn2 ON ci2.person_role_id = cn2.id
JOIN movie_keyword mk1 ON t.id = mk1.movie_id
JOIN keyword k1 ON mk1.keyword_id = k1.id
JOIN movie_keyword mk2 ON t.id = mk2.movie_id
JOIN keyword k2 ON mk2.keyword_id = k2.id
LEFT JOIN movie_info mi1 ON t.id = mi1.movie_id
LEFT JOIN info_type it1 ON mi1.info_type_id = it1.id
LEFT JOIN movie_info mi2 ON t.id = mi2.movie_id
LEFT JOIN info_type it2 ON mi2.info_type_id = it2.id
WHERE t.title LIKE '%%'
  AND at1.title LIKE '%%'
  AND n1.name LIKE '%%'
  AND n2.name LIKE '%%'
  AND cn1.name LIKE '%%'
  AND cn2.name LIKE '%%'
  AND k1.keyword LIKE '%%'
  AND k2.keyword LIKE '%%'
  AND mi1.info LIKE '%%'
  AND it1.info LIKE '%%'
  AND mi2.info LIKE '%%'
  AND it2.info LIKE '%%'
  AND ci1.nr_order <= 19
  AND ci2.nr_order <= 20
  AND ci1.role_id = 2
  AND ci2.role_id = 1
  AND t.season_nr >= 3
  AND t.episode_nr >= 8;
