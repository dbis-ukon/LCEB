SELECT id, title, imdb_id
FROM title
WHERE title LIKE '%man%'
  AND title NOT LIKE '%batman%'
  AND kind_id IN (1, 2, 3)
  AND production_year > 1980;
