SELECT akat.movie_id,
       t.title,
       cn.name AS character_name,
       ci.role_id,
       c.name AS company_name,
       COUNT(DISTINCT akat.movie_id) AS num_movies
FROM aka_title akat
JOIN cast_info ci ON akat.movie_id = ci.movie_id
JOIN char_name cn ON ci.person_id = cn.id
JOIN name n ON cn.id = n.id
JOIN movie_companies mc ON akat.movie_id = mc.movie_id
JOIN company_name c ON mc.company_id = c.id
JOIN movie_keyword mk ON akat.movie_id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN title t ON akat.movie_id = t.id
WHERE cn.name LIKE '%%'
  AND n.name LIKE '%%'
  AND akat.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND c.name LIKE '%%'
  AND t.title LIKE '%%'
  AND akat.episode_nr BETWEEN 2 AND 3
GROUP BY akat.movie_id, t.title, cn.name, ci.role_id, c.name
ORDER BY num_movies DESC;
