SELECT co.name, COUNT(*) AS total_movies
FROM company_name co
JOIN movie_companies mc ON mc.company_id = co.id
JOIN title t ON t.id = mc.movie_id
WHERE (co.name LIKE '%%' or t.title LIKE '%%')
  AND t.season_nr = 1
  AND t.production_year BETWEEN 1986 AND 1999
GROUP BY co.name
ORDER BY total_movies DESC;
