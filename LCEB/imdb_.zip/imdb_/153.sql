SELECT t.id, t.title, cn.name AS character_name, rt.role, k.keyword, it.info AS info_type, mi.info AS info_value
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN char_name cn ON ci.person_role_id = cn.id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN movie_info mi ON t.id = mi.movie_id
JOIN info_type it ON mi.info_type_id = it.id
WHERE t.title LIKE '%%'
  AND t.title LIKE '%%'
  AND cn.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.series_years IS NOT NULL AND t.production_year > 1910 AND t.production_year < 2004 AND t.production_year BETWEEN 1983 AND 2008 AND ci.nr_order BETWEEN 13 AND 22 AND ci.role_id IN (2, 3, 9, 1, 4) AND ci.note IS NULL AND cn.surname_pcode IS NOT NULL AND cn.md5sum IS NOT NULL AND k.id > 12524 AND k.id BETWEEN 24122 AND 86936;
