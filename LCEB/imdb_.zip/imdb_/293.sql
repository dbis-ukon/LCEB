SELECT id, keyword, phonetic_code
FROM keyword k
WHERE (k.keyword LIKE '%%' OR k.keyword LIKE '%%' OR k.keyword LIKE '%%')
  AND k.phonetic_code IS NOT NULL
  AND k.id > 125132;
