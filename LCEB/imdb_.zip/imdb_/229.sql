SELECT cn.name, MIN(t.production_year) AS first_movie, MAX(t.production_year) AS last_movie, COUNT(DISTINCT ci.movie_id) AS movie_count
FROM char_name cn
JOIN cast_info ci ON ci.person_id = cn.id
JOIN title t ON t.id = ci.movie_id
WHERE cn.name LIKE '%%'
  AND t.title LIKE '%%'
  AND (t.season_nr BETWEEN 1 AND 1 OR t.episode_nr <= 92)
  AND t.production_year >= 2005
  AND ci.nr_order <= 10
GROUP BY cn.name
ORDER BY last_movie DESC;
