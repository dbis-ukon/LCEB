SELECT t.id, t.title, ak.title AS alternate_title, k.keyword
FROM title t
JOIN aka_title ak ON ak.movie_id = t.id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE (t.title LIKE '%%' OR ak.title LIKE '%%')
  AND t.title NOT LIKE '%%'
  AND ak.title LIKE '%%'
  AND ak.title NOT LIKE '%%'
  AND k.keyword LIKE '%%'
  AND k.keyword NOT LIKE '%%'
  AND t.production_year > 1958
  AND ak.production_year IS NOT NULL
  AND ak.production_year BETWEEN 1951 AND 1981
  AND ak.kind_id > 1
  AND mk.keyword_id > 1;
