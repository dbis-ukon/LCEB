SELECT cn.id, cn.name, cn.imdb_index, cn.imdb_id, cn.name_pcode_nf, cn.surname_pcode, cn.md5sum,
       ci.role_id, akat.title
FROM char_name cn
JOIN cast_info ci ON cn.id = ci.person_id
JOIN aka_title akat ON ci.movie_id = akat.movie_id
WHERE (akat.title LIKE '%%' OR akat.title LIKE '%%')
  AND cn.name LIKE '%%'
  AND cn.name_pcode_nf = 'G4253'
  AND cn.surname_pcode = 'G6452'
  AND ci.nr_order <= 20;
