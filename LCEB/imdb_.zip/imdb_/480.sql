SELECT t.title, kt.kind, n.name AS actor_name, co.name AS studio_name, ct.kind AS company_type, k.keyword
FROM cast_info ci
JOIN name n ON n.id = ci.person_id
JOIN title t ON t.id = ci.movie_id
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_companies mc ON mc.movie_id = t.id
JOIN company_name co ON co.id = mc.company_id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_keyword mk ON mk.movie_id = t.id
JOIN keyword k ON k.id = mk.keyword_id
WHERE t.title LIKE '%%'
  AND n.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND co.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND ci.note IS NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND co.country_code = '[br]' AND co.country_code IS NOT NULL AND co.imdb_id > 500;
