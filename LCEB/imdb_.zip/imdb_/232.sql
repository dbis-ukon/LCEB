SELECT cn1.name AS company1, cn2.name AS company2, t1.title AS movie1, t2.title AS movie2, kt1.kind AS kind1, kt2.kind AS kind2
FROM company_name cn1
JOIN company_name cn2 ON cn1.country_code = cn2.country_code AND cn1.id <> cn2.id
JOIN movie_companies mc1 ON cn1.id = mc1.company_id
JOIN title t1 ON mc1.movie_id = t1.id
JOIN kind_type kt1 ON t1.kind_id = kt1.id
JOIN movie_companies mc2 ON cn2.id = mc2.company_id
JOIN title t2 ON mc2.movie_id = t2.id
JOIN kind_type kt2 ON t2.kind_id = kt2.id
WHERE cn1.name LIKE '%%'
  AND t1.title LIKE '%%'
  AND t2.title NOT LIKE '%%'
  AND cn1.name LIKE '%%'
  AND mc1.company_id > 11245 AND mc1.company_type_id IN (2, 1) AND mc2.company_type_id IN (2, 1) AND mc2.note IS NULL;
