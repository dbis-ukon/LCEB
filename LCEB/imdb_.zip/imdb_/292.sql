SELECT id, keyword
FROM keyword
WHERE (keyword LIKE '%school%' OR keyword LIKE '%student%')
  AND keyword NOT LIKE '%high school%'
  AND id BETWEEN 100 AND 900000
  AND keyword <> '';
