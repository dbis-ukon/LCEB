SELECT n.name, COUNT(DISTINCT t.id) AS films, AVG(t.production_year) AS avg_year, COUNT(DISTINCT k.id) AS kw_count
FROM title t
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE (k.keyword LIKE '%%')
  AND k.keyword NOT LIKE '%%'
  AND (n.name LIKE '%%' OR n.name LIKE '%%')
  AND t.kind_id IN (4, 3, 7, 1)
  AND t.production_year BETWEEN 2010 AND 2010
  AND ci.nr_order <= 2
  AND n.gender = 'f'
GROUP BY n.name
HAVING COUNT(DISTINCT t.id) > 1 AND COUNT(DISTINCT k.id) >= 1
ORDER BY films DESC, avg_year;
