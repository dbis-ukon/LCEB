SELECT t.id, t.title, kt.kind, rt.role, cn.name AS company_name, k.keyword
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE (t.title LIKE '%%' OR t.title NOT LIKE '%%')
  AND kt.kind = 'tv series'
  AND k.keyword LIKE '%%'
  AND ci.nr_order <= 2 AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 3 AND 20 AND cn.imdb_id > 2600 AND cn.imdb_id IS NOT NULL AND cn.name_pcode_nf IS NOT NULL AND mc.company_type_id IN (1, 2) AND mc.note IS NULL;
