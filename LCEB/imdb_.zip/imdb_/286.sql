SELECT t.title
FROM title t
WHERE t.title LIKE '%%'
  AND t.production_year BETWEEN 1997 AND 2008
  AND t.season_nr = 3
  AND t.episode_nr <= 10007
  AND t.episode_of_id IS NOT NULL
ORDER BY t.production_year DESC;
