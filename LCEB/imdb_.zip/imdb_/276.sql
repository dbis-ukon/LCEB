SELECT name, n_movies, NTILE(5) OVER (ORDER BY n_movies DESC) AS quintile
FROM (
    SELECT n.name, COUNT(DISTINCT ci.movie_id) AS n_movies
    FROM name n
    JOIN cast_info ci ON n.id = ci.person_id
    JOIN movie_keyword mk ON ci.movie_id = mk.movie_id
    JOIN keyword k ON mk.keyword_id = k.id
    WHERE k.keyword LIKE '%%'
      AND n.gender = 'm'
      AND ci.nr_order <= 4
    GROUP BY n.name
    HAVING COUNT(DISTINCT ci.movie_id) >= 3
) sub
ORDER BY n_movies DESC;
