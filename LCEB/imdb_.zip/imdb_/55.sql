SELECT akat.movie_id, t.title, COUNT(DISTINCT cn.id) AS main_characters, c.name AS company_name
FROM aka_title akat
JOIN cast_info ci ON akat.movie_id = ci.movie_id
JOIN char_name cn ON ci.person_id = cn.id
JOIN name n ON cn.id = n.id
JOIN title t ON akat.movie_id = t.id
JOIN movie_companies mc ON akat.movie_id = mc.movie_id
JOIN company_name c ON mc.company_id = c.id
JOIN company_type ct ON mc.company_type_id = ct.id
WHERE (cn.name LIKE '%%' OR cn.name LIKE '%%')
  AND (n.name LIKE '%%' OR n.name LIKE '%%')
  AND (t.title LIKE '%%' OR t.title LIKE '%%')
  AND n.gender = 'f'
  AND ct.kind = 'distributors'
  AND akat.production_year BETWEEN 1986 AND 2008
GROUP BY akat.movie_id, t.title, c.name
ORDER BY main_characters DESC;
