SELECT id, name
FROM company_name
WHERE (name LIKE '%Universal%' OR name LIKE '%Paramount%')
  AND name NOT LIKE '%Home Video%'
  AND country_code IS NOT NULL
  AND id BETWEEN 100 AND 900000;
