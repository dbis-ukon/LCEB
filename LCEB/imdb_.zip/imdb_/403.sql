SELECT t.title, akat.title AS aka_title, n.name AS actor, chn.name AS character_name,
       cn.name AS company_name, k.keyword, ct.kind AS company_type
FROM title t
JOIN aka_title akat ON t.id = akat.movie_id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN char_name chn ON ci.person_role_id = chn.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
JOIN company_type ct ON mc.company_type_id = ct.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
WHERE t.title LIKE '%%'
  AND akat.title LIKE '%%'
  AND n.name LIKE '%%'
  AND chn.name LIKE '%%'
  AND cn.name LIKE '%%'
  AND k.keyword LIKE '%%'
  AND t.imdb_id IS NOT NULL AND t.series_years IS NOT NULL AND t.production_year > 2007 AND t.production_year < 2002 AND ci.note IS NULL AND ci.note IS NOT NULL AND ci.person_role_id IS NOT NULL AND cn.imdb_id > 3800 AND cn.imdb_id IS NOT NULL AND cn.name_pcode_nf IS NOT NULL;
