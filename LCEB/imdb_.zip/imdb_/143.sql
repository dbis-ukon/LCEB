SELECT t.id, t.title, it.info AS info_type, mi.info, n.name AS actor_name, rt.role
FROM title t
JOIN movie_info mi ON t.id = mi.movie_id
JOIN info_type it ON mi.info_type_id = it.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN name n ON ci.person_id = n.id
JOIN role_type rt ON ci.role_id = rt.id
WHERE t.title LIKE '%%'
  AND it.info = 'rentals'
  AND n.name LIKE '%%'
  AND t.md5sum IS NOT NULL AND t.phonetic_code IS NOT NULL AND t.imdb_id IS NOT NULL AND t.series_years IS NOT NULL AND ci.role_id IN (8, 1, 2, 3, 4) AND ci.note IS NULL AND ci.note IS NOT NULL AND n.imdb_id > 2750 AND n.name_pcode_nf IS NOT NULL AND n.name_pcode_cf IS NOT NULL;
