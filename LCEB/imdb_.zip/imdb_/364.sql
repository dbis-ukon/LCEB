SELECT t.id, t.title, k.keyword, kt.kind, COUNT(DISTINCT ci.person_id) AS cast_count, COUNT(DISTINCT mc.company_id) AS company_count
FROM title t
JOIN kind_type kt ON t.kind_id = kt.id
JOIN movie_keyword mk ON t.id = mk.movie_id
JOIN keyword k ON mk.keyword_id = k.id
JOIN cast_info ci ON t.id = ci.movie_id
JOIN role_type rt ON ci.role_id = rt.id
JOIN movie_companies mc ON t.id = mc.movie_id
JOIN company_name cn ON mc.company_id = cn.id
WHERE t.title LIKE '%%'
  AND k.keyword LIKE '%%'
  AND ci.nr_order IS NOT NULL AND ci.nr_order BETWEEN 0 AND 1 AND ci.role_id IN (8, 4, 9, 1, 10) AND cn.name_pcode_nf IS NOT NULL AND cn.name_pcode_sf IS NOT NULL AND cn.country_code = '[us]'
GROUP BY t.id, t.title, k.keyword, kt.kind
HAVING COUNT(DISTINCT ci.person_id) > 7;
