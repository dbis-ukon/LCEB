-- Q5: EXISTS-driven, no direct joins to keyword/company tables
SELECT t.id, t.title, kt.kind, n.name AS director_name
FROM title t
JOIN kind_type kt ON kt.id = t.kind_id
JOIN cast_info ci ON ci.movie_id = t.id
JOIN name n ON n.id = ci.person_id
WHERE t.title LIKE '%%'
  AND kt.kind IN ('tv mini series', 'tv series', 'movie', 'video game', 'tv movie')
  AND ci.role_id = 10
  AND EXISTS (
      SELECT 1 FROM movie_keyword mk JOIN keyword k ON k.id = mk.keyword_id
      WHERE mk.movie_id = t.id AND k.keyword LIKE '%%'
  )
  AND EXISTS (
      SELECT 1 FROM movie_companies mc JOIN company_name co ON co.id = mc.company_id
      WHERE mc.movie_id = t.id AND co.name LIKE '%%'
  )
  AND NOT EXISTS (
      SELECT 1 FROM movie_link ml WHERE ml.movie_id = t.id
  );
